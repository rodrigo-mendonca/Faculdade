/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arvorebinaria;
/**
 *
 * @author Rodrigo Mendonça
 */
public class ArvoreBinaria {
    public static int nValorNulo = -1; // SETA O VALOR QUE VAI REPRESENTAR A AUSENCIA DE VALOR
    public static int nTamArvores = 100;
    
    public static void main(String[] args) {
        /*
        ArvoreJFrame aForm = new ArvoreJFrame();
        aForm.setVisible(true);
        */
        
        int[] nVetor1 = {10,19,74};
        int[] nArvore1 = Criar(nVetor1);
        
        int[] nVetor2 = {5,35,74};
        int[] nArvore2 = Criar(nVetor2);
        
        int[] nComun = Comparar(nArvore1,nArvore2);
        for (int i = 0; i < nComun.length; i++) {
            if(nComun[i] != nValorNulo){System.out.println(nComun[i]);}
        }
    }
    public static int[] Criar(int[] tnVetor)
    {
        int[] nArvore = ValorNulo(new int[nTamArvores]);
        
        for (int i = 0; i < tnVetor.length; i++) {
            nArvore = Incluir(tnVetor[i],nArvore,0);
        }
        return(nArvore);
    }
    public static int[] Incluir(int tnValor,int[] tnArvore,int tnIndex)
    {
        if(tnArvore.length < tnIndex){return(tnArvore);}
        if(tnArvore[tnIndex] == nValorNulo){tnArvore[tnIndex] = tnValor;}
        else
        {
            if(tnArvore[tnIndex] > tnValor){Incluir(tnValor,tnArvore,(tnIndex*2) + 1);}
            else{Incluir(tnValor,tnArvore,(tnIndex*2) + 2);}
        }

        return(tnArvore);
    }
    public static int Buscar(int tnValor,int[] tnArvore,int tnIndex)
    {
        if(tnArvore.length < tnIndex){return(nValorNulo);}
        if(tnArvore[tnIndex] != tnValor && tnArvore[tnIndex] != nValorNulo)
        {
            if(tnValor < tnArvore[tnIndex]){return(Buscar(tnValor,tnArvore,(2 * tnIndex) + 1)) ;}
            else{return(Buscar(tnValor,tnArvore,(2 * tnIndex) + 2)) ;}
        }
	else
        {
            if(tnArvore[tnIndex] == tnValor){return(tnIndex);}
            else{return(nValorNulo);}
        }
    }
    public static int[] Comparar(int[] tnArvore1,int[] tnArvore2)
    {
        // PEGA O TAMANHO DO MENOR VETOR PARA RETORNO
        int nTam = 0,nInx = 0;
        if (tnArvore1.length > tnArvore2.length) {nTam = tnArvore2.length;}
        else{nTam = tnArvore1.length;}
        int[] nComuns = ValorNulo(new int[nTam]);
        
        // CONSULTANDO CADA ELEMENTO DA ARVORE 1 BUSCA NA ARVORE 2
        for (int i = 0; i < tnArvore1.length; i++) {
            if (Buscar(tnArvore1[i],tnArvore2,0) != nValorNulo) {
                nComuns[nInx] = tnArvore1[i];
                nInx++;
            }
        }
        return(nComuns);
    }
    public static void Fusao(int[] tnArvore1,int[] tnArvore2)
    {
        tnArvore1 = OrdenaVetor(tnArvore1);
        tnArvore2 = OrdenaVetor(tnArvore2);
        
        // O TAMANHO MAXIMO DA ARVORE FUSAO É O DOBRO DO VALOR MAXIMO DAS ARVORES
        int[] nFusao = ValorNulo(new int[nTamArvores * 2]);
        
        for (int i = 0; i < nTamArvores; i++) {
            
        }
    }
    public static int[] ValorNulo(int[] tnArvore)
    {
        for (int i = 0; i < tnArvore.length; i++) {
            tnArvore[i] = nValorNulo;
        }
        return(tnArvore);
    }
    
    public static int[] OrdenaVetor(int[] tnVetor)
    {
        int nAux = 0;
        for (int i = 0; i < tnVetor.length; i++) {
            for (int j = i + 1; j < tnVetor.length; j++) {
                if (tnVetor[i] > tnVetor[j]) {
                    nAux = tnVetor[i];
                    tnVetor[i] = tnVetor[j];
                    tnVetor[j] = nAux;
                }
            }
        }
        return(tnVetor);
    }
    public static int[] LimpaIguais(int[] tnVetor1,int[] tnVetor2)
    {
        int[] nLimpo = ValorNulo(new int[nTamArvores * 2]);
        int nInx = 0;
        
        for (int i = 0; i < tnVetor1.length; i++) {
            for (int j = 0; j < tnVetor2.length; j++) {
                if (tnVetor1[i] != tnVetor2[i]) {
                    nLimpo[nInx] = tnVetor1[i];
                    nInx++;
                }
            }
        }
        
        return(nLimpo);
    }
    public static void Remover(int[] tnArvore)
    {
    
    }
}