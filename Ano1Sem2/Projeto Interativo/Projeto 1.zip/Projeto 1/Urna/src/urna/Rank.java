/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package urna;


public class Rank {
    public int nPosicao         = 0;
    public Candidato cCandidato = null;
    public double nPercent      = 0;

    public Rank()
    {
    
    }
}