/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package facilsena;
import javax.swing.JOptionPane;

/**
 *
 * @author Jacques e Rodrigo
 */
public class Main {
   static boolean lTeste    = false; //PROPRIEDADE PARA ATIVAR O TESTE AUTOMATICO
   static int nMinVal       = 0; //MENOR NUMERO QUE PODE SER DIGITADO
   static int nMaxVal       = 7; //MAIOR NUMERO QUE PODE SER DIGITADO
   static int nNumDigi      = 4; //NUMERO DE DIGITOS QUE DEVE SER DIGITADO
   static double nPremio[]  = null; //ARMAZENA LISTA DE PREMIOS
   static int nMaxJogos     = 5; //NUMERO MAXIMO DE JOGADAS

    public static void main(String[] args) {
        nPremio = Premios(); //CARREGA LISTA DE PREMIOS
        int nContJogos  = 0; //GUARDA O NUMERO DE JOGOS FEITOS
        int nJogos[][]  = new int[nMaxJogos][nNumDigi]; //
        int nJogada[]   = new int[nNumDigi]; //
        int nCont       = 0; //VARIAVEL PARA CONTROLAR SE DEVE PARAR AS JOGADAS
        int nSorteio[]  = new int [nNumDigi]; //ARMAZENA OS NUMEROS SORTEADOS
        boolean llErro  = false; //VARIAVEL DE CONTROLE DE ERRO
        
        //REALIZA O SORTEIRO DOS NUMEROS
        for (int i= 0; i < nNumDigi; i++) {
            do {
                llErro = false;
                nSorteio[i] = (int) (Math.random() * (nMaxVal + nMinVal));
                //VERIFICA O NUMERO SORTIADO COM TODOS OS ANTERIOS PARA NÃO EXISTIR REPETIÇÃO
                for (int j = (i - 1); j >= 0; j--) {
                    if(nSorteio[i] == nSorteio[j]){llErro = true;;}
                }
            } while (llErro);
        }
        
        // CHAMA METODO DE TESTE
        if (lTeste) {
            Testar(nSorteio);
            return;
        }
        
        // FAZ A LEITURA DAS JOGADAS
        do {
            nJogada = lerJogada(nContJogos);
            System.arraycopy(nJogada, 0, nJogos[nContJogos], 0, nNumDigi);
            // VERIFICA SE NÃO EXCEDEU O NUMERO MAXIMO DE JOGADAS
            if((nContJogos + 1) == nMaxJogos){
                nCont = 1;
            }
            else{
                // PERGUNTA AO USUARIO SE QUER FAZER OUTRO JOGO
                nCont = JOptionPane.showConfirmDialog(null, "Deseja realizar outra jogada?");
            }
            // SE O USUARIO ESCOLHER 2, PARA O PROGRAMA
            if (nCont == 2) {return;}
            nContJogos++;
            // CONTINUA O LOOP SE O USUARIO QUIZER CONTINUAR JOGANDO E NÃO TIVER EXCEDIDO O MAXIMO DE JOGADAS
        } while (nCont == 0);
        
        // FAZ A CONFERENCIA DE ACERTOS E EXIBI A MSG
        sorteio(nJogos,nSorteio,nContJogos);
    }

    static int[] lerJogada(int tnK) {
        boolean llErro = false;
        do {
            // FAZ A LEITURA DA JOGADA
            String cJogada = JOptionPane.showInputDialog("Insira a jogada " + (tnK + 1) + ":");
            if (cJogada.length() == nNumDigi) {
                int[] nJogo = new int[nNumDigi];
                int i;
                for (i = 0; i < nNumDigi; i++) {
                    nJogo[i] = Character.digit(cJogada.charAt(i), 10);
                    
                    // COMPARA O NUMERO ATUAL COM TODOS OS ANTERIOS PARA NÃO TER REPETIÇÃO
                    for (int j = (i - 1); j >= 0; j--) {
                        if(nJogo[i] == nJogo[j]){llErro = true;}
                    }
                    if(llErro){break;}
                    if (nJogo[i] < nMinVal || nJogo[i] > nMaxVal) {
                        break;
                    }
                }
                // RETORNA O JOGO SE A JOGADA ESTIVER "OK"
                if (i == nNumDigi) {
                    return nJogo;
                }
            }
            // EXIBI MSG DE ERRO CASO TENHA ALGUM PROBLEMA
            JOptionPane.showMessageDialog(null, "Jogada Inválida, por favor insira novamente.\n(Não ultrapassar o limite de digitos e não repetir o mesmo numero.)");
            llErro = false;
        } while (true);
    }

    static void sorteio(int[][] tnJogada, int[] tnSorteio, int tnContJogos){
        int[] nGanhadores = new int[tnContJogos];
        int[] nResult = new int[nNumDigi + 1];
        int nAcertos = 0;
        
        // ADICIONA OS NUMEROS SORTEADOS PARA A VARIAVEL DE EXIBIÇÃO
        String cResult = "Numeros Sorteados: ";
        for (int i = 0; i < nNumDigi; i++) {
            cResult += String.valueOf(tnSorteio[i]) + " - ";
        }        
        cResult = cResult.substring(0,cResult.length() - 3); //RETIRA O ULTIMO TRAÇO
        // ADICIONA OS PREMIOS A VARIAVEL DE EXIBIÇÃO
        cResult += "\nPremiações:\n";
        for (int i = nNumDigi; i >= 0; i--) {
            if(nPremio[i] != 0){
                cResult+= String.valueOf(i) + " Acertos, " + String.valueOf(nPremio[i]) + " Reais.\n";
            }
        }
        // PARA CADA JOGADA
        for (int i = 0; i < tnContJogos; i++) {
            // VERIFICA CADA NUMERO JOGADO
            for (int j = 0; j < nNumDigi; j++) {
                // VERICA COM CADA NUMERO SORTEADO
                for (int k = 0; k < nNumDigi; k++) {
                    // SE O NUMERO FOR IGUAL SOMA MAIS UM PARA A VARIAVEL
                    if (tnJogada[(i)][j] == tnSorteio[k]) {
                        nAcertos++;
                        break;
                    }
                }
            }
            // UTILIZA O NUMERO DE ACERTOS COMO INDICE E VAI ADICIONANDO A QUANTIDADE DE VEZES QUE APAERCEU ESSA QUANTIDADE
            nResult[nAcertos]++;
            nGanhadores[i] = nAcertos; // MARCA QUANTOS ACERTOS TEVE CADA JOGADA
            nAcertos = 0;
        }
        
        double nValor = 0;
        // ADICIONA OS RESULTADOS DO SORTEIO NA VARIAVEL DE EXIBIÇÃO
        cResult+="\nResultados do sorteio:";
        for (int i = 0; i < tnContJogos; i++) {
                // GUARDA O NUMERO DE ACERTOS PARA USAR COMO INDICE DOS PREMIOS
                nAcertos = nGanhadores[i];
                // PROTEÇÃO CONTRA DIVIÇÃO POR ZERO
                if(nAcertos > 0){nValor = nPremio[nAcertos]/nResult[nAcertos];}
                // ADICIONA A VARIAVEL DE EXIBIÇÃO O NUMERO DA JOGADA E SEU PREMIO
                cResult+= "\nJogada " + String.valueOf((i + 1)) + " leva " + String.valueOf(Math.round(nValor));
                nValor = 0;
        }
        
        // EXIBI TODOS OS RESULTADOS
        JOptionPane.showMessageDialog(null, cResult);
    }
    
    public static double[] Premios()
    {
        // O NUMERO DE PREMIOS DEVE SER DE ACORDO COM O NUMERO DE DIGITOS SORTEADOS
        double nPremios[] = new double [nNumDigi + 1];
        
        // ADICIONANDO OUTRO INDICE COM VALOR ADICIONA MAIS UM PREMIO AO JOGO
        nPremios[4] = 4000;
        nPremios[3] = 1000;
        
        return(nPremios);
    
    }
    public static void Testar(int tnSorteio[])
    {
        int nContJogos = 0;
    
        //sorteio(nJogos,tnSorteio,nContJogos);
    }
}
