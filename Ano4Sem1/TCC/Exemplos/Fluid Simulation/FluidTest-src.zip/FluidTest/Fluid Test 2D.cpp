
/*
 * This program uses the fluid dynamics solver presented
 * in Jos Stam, "A Simple Fluid Solver Based on the FFT",
 * (http://www.dgp.utoronto.ca/people/stam/reality/Research/pub.html)
 * to produce a impression of swirly smoke in real-time.
 * 
 * To compile this program, you need "The Fastest Forurier 
 * Transform in the West", i.e., the fftw and rfftw libraries 
 * and header files. They can be downloaded from 
 * http://www.fftw.org.
 *
 *   --  Author: Gustav Taxen, gustavt@nada.kth.se --
 *   --      This code is in the public domain.    --
 *
 * USAGE:
 *
 * Drag with the mouse to add smoke to the fluid. This will
 * also move a "rotor" that disturbs the velocity field to
 * the mouse location.
 *
 * 'w' toggles wireframe rendering.
 * 'v' toggles rendering of velocity vectors. 
 * 'T' and 't' increases and decreases the simulation time step, 
 * respectively.
 *
 * NOTE: The parameters I've chosen for the simulation are
 * targeted at a Pentium III 850MHz laptop with a ATI Rage 
 * Mobility M4 graphics card. You may have to change them to
 * suit your machine (see below).
 *
 */

#ifdef WIN32
#include <windows.h>
#endif

#include <math.h>

#include <fftw/rfftw.h>
#include <GL/gl.h>

#include "../m_system3d/main.h"
#include "../m_foundation/main.h"
#include "../m_foundation/random.h"

/*
 * Size of the simulation grid, i.e. the number of grid
 * points are (DIM x DIM).
 *
 */
#define DIM 64
#define ARRAYSIZE (DIM * 2*(DIM/2+1))

/* 
 * Simulation time step: you may need to change this to suit
 * your particular machine speed.
 *
 */
double dt = 1.0;


int    winWidth, winHeight;
int    drawVelocities = 0;

double t = 0;

/* 
 * See Jos Stam, "A Simple Fluid Solver Based on the FFT",
 * http://www.dgp.utoronto.ca/people/stam/reality/Research/pub.html
 * for more details on the following code.
 *
 */

fftw_real u[DIM * 2*(DIM/2+1)], v[DIM * 2*(DIM/2+1)], u0[DIM * 2*(DIM/2+1)], v0[DIM * 2*(DIM/2+1)];
fftw_real rgb_rho[3][DIM * DIM], rgb_rho0[3][DIM * DIM];  /* Smoke density */
fftw_real u_u0[DIM * DIM], u_v0[DIM * DIM];  /* User-induced forces */

static rfftwnd_plan plan_rc, plan_cr;

void init_FFT(int n) {
	plan_rc = rfftw2d_create_plan(n, n, FFTW_REAL_TO_COMPLEX, FFTW_IN_PLACE);
	plan_cr = rfftw2d_create_plan(n, n, FFTW_COMPLEX_TO_REAL, FFTW_IN_PLACE);
}

#define floor(x) ((x)>=0.0?((int)(x)):(-((int)(1-(x)))))

void stable_solve ( int n, fftw_real * u, fftw_real * v, fftw_real * u0, fftw_real * v0, fftw_real visc, fftw_real dt ) {
	fftw_real x, y, x0, y0, f, r, U[2], V[2], s, t;
	int i, j, i0, j0, i1, j1;

	for ( i=0 ; i<n*n ; i++ ) {
		u[i] += dt*u0[i]; 
		u0[i] = u[i];
		
		v[i] += dt*v0[i]; 
		v0[i] = v[i];
  }    

	for ( x=0.5f/n,i=0 ; i<n ; i++,x+=1.0f/n ) {
		for ( y=0.5f/n,j=0 ; j<n ; j++,y+=1.0f/n ) {
			x0 = n*(x-dt*u0[i+n*j])-0.5f; 
			y0 = n*(y-dt*v0[i+n*j])-0.5f;
			i0 = floor(x0);
			s = x0-i0;
			i0 = (n+(i0%n))%n;
			i1 = (i0+1)%n;
			j0 = floor(y0);
			t = y0-j0;
			j0 = (n+(j0%n))%n;
			j1 = (j0+1)%n;
			u[i+n*j] = (1-s)*((1-t)*u0[i0+n*j0]+t*u0[i0+n*j1])+                        
				s *((1-t)*u0[i1+n*j0]+t*u0[i1+n*j1]);
			v[i+n*j] = (1-s)*((1-t)*v0[i0+n*j0]+t*v0[i0+n*j1])+
				s *((1-t)*v0[i1+n*j0]+t*v0[i1+n*j1]);
		}    
	} 
	
	for ( i=0 ; i<n ; i++ )
		for ( j=0 ; j<n ; j++ ) { 
			u0[i+(n+2)*j] = u[i+n*j]; 
		  v0[i+(n+2)*j] = v[i+n*j];
		}

	rfftwnd_one_real_to_complex(plan_rc,(fftw_real *)u0,(fftw_complex*)u0);
	rfftwnd_one_real_to_complex(plan_rc,(fftw_real *)v0,(fftw_complex*)v0);

	for ( i=0 ; i<=n ; i+=2 ) {
		x = 0.5f*i;
		for ( j=0 ; j<n ; j++ ) {
			y = j<=n/2 ? (fftw_real)j : (fftw_real)j-n;
			r = x*x+y*y;
			if ( r==0.0f ) continue;
			f = (fftw_real)exp(-r*dt*visc);
			U[0] = u0[i  +(n+2)*j]; V[0] = v0[i  +(n+2)*j];
			U[1] = u0[i+1+(n+2)*j]; V[1] = v0[i+1+(n+2)*j];

			u0[i  +(n+2)*j] = f*( (1-x*x/r)*U[0]     -x*y/r *V[0] );
			u0[i+1+(n+2)*j] = f*( (1-x*x/r)*U[1]     -x*y/r *V[1] );
			v0[i+  (n+2)*j] = f*(   -y*x/r *U[0] + (1-y*y/r)*V[0] );
			v0[i+1+(n+2)*j] = f*(   -y*x/r *U[1] + (1-y*y/r)*V[1] );
		}    
	}

	rfftwnd_one_complex_to_real(plan_cr,(fftw_complex *)u0,(fftw_real *)u0); 
	rfftwnd_one_complex_to_real(plan_cr,(fftw_complex *)v0,(fftw_real *)v0); 

	f = 1.0/(n*n);
 	for ( i=0 ; i<n ; i++ )
		for ( j=0 ; j<n ; j++ ) {
			u[i+n*j] = f*u0[i+(n+2)*j]; 
			v[i+n*j] = f*v0[i+(n+2)*j]; 
		}
} 


/*
 * This function diffuses matter that has been placed
 * in the velocity field. It's almost identical to the
 * velocity diffusion step in the function above. The
 * input matter densities are in rho0 and the result
 * is written into rho.
 *
 */
void diffuse_matter(int n, fftw_real *u, fftw_real *v, fftw_real *rho, fftw_real *rho0, fftw_real dt) {
	fftw_real x, y, x0, y0, s, t;
	int i, j, i0, j0, i1, j1;

	for ( x=0.5f/n,i=0 ; i<n ; i++,x+=1.0f/n ) {
		for ( y=0.5f/n,j=0 ; j<n ; j++,y+=1.0f/n ) {
			x0 = n*(x-dt*u[i+n*j])-0.5f; 
			y0 = n*(y-dt*v[i+n*j])-0.5f;
			i0 = floor(x0);
			s = x0-i0;
			i0 = (n+(i0%n))%n;
			i1 = (i0+1)%n;
			j0 = floor(y0);
			t = y0-j0;
			j0 = (n+(j0%n))%n;
			j1 = (j0+1)%n;
			rho[i+n*j] = (1-s)*((1-t)*rho0[i0+n*j0]+t*rho0[i0+n*j1])+                        
				s *((1-t)*rho0[i1+n*j0]+t*rho0[i1+n*j1]);

//			rho[i+n*j] = (1-s)*(1-t)*rho0[i0+n*j0] +
//						 (1-s)*( t )*rho0[i0+n*j1] +
//						 ( s )*(1-t)*rho0[i1+n*j0] +
//						 ( s )*( t )*rho0[i1+n*j1];
		}    
	} 
}

/*
 * Draw the fluid using triangle strips.
 *
 */
void drawField(void) {
	int        i, j, idx;
	fftw_real  wn = (fftw_real)winWidth / (fftw_real)(DIM + 1);   /* Grid element width */
	fftw_real  hn = (fftw_real)winHeight / (fftw_real)(DIM + 1);  /* Grid element height */
	double     px, py;

static float VelColorScalar = 100.f;
static float VelDrawScalar = 10.f;
static M_CVar *dflkfds[] = {
	new M_CVar(&VelColorScalar, "VelColorScalar"),
	new M_CVar(&VelDrawScalar, "VelDrawScalar"),
	NULL};

	for (j = 0; j < DIM - 1; j++) {
		glBegin(GL_TRIANGLE_STRIP);

		i = 0;
		px = wn + (fftw_real)i * wn;
		py = hn + (fftw_real)j * hn;
		idx = (j * DIM) + i;
//		glColor3f(rho[idx], rho[idx], rho[idx]);
//		glColor3f(1, rho[idx], rho[idx]);
//		glColor3f(rho[idx], VelColorScalar*u[idx], VelColorScalar*v[idx]);
		glColor3d(rgb_rho[0][idx], rgb_rho[1][idx], rgb_rho[2][idx]);
		glVertex2d(px, py);
						
		for (i = 0; i < DIM - 1; i++) {
			px = wn + (fftw_real)i * wn;
			py = hn + (fftw_real)(j + 1) * hn;
			idx = ((j + 1) * DIM) + i;
//			glColor3f(rho[idx], rho[idx], rho[idx]);
//			glColor3f(1, rho[idx], rho[idx]);
//			glColor3f(rho[idx], VelColorScalar*u[idx], VelColorScalar*v[idx]);
			glColor3d(rgb_rho[0][idx], rgb_rho[1][idx], rgb_rho[2][idx]);
			glVertex2d(px, py);

			px = wn + (fftw_real)(i + 1) * wn;
			py = hn + (fftw_real)j * hn;
			idx = (j * DIM) + (i + 1);
//			glColor3f(rho[idx], rho[idx], rho[idx]);
//			glColor3f(1, rho[idx], rho[idx]);
//			glColor3f(rho[idx], VelColorScalar*u[idx], VelColorScalar*v[idx]);
			glColor3d(rgb_rho[0][idx], rgb_rho[1][idx], rgb_rho[2][idx]);
			glVertex2d(px, py);
		}

		px = wn + (fftw_real)(DIM - 1) * wn;
		py = hn + (fftw_real)(j + 1) * hn;
		idx = ((j + 1) * DIM) + (DIM - 1);
//		glColor3f(rho[idx], rho[idx], rho[idx]);
//		glColor3f(1, rho[idx], rho[idx]);
//		glColor3f(rho[idx], VelColorScalar*u[idx], VelColorScalar*v[idx]);
		glColor3d(rgb_rho[0][idx], rgb_rho[1][idx], rgb_rho[2][idx]);
		glVertex2d(px, py);

		glEnd();
	}

	if (drawVelocities) {
		glBegin(GL_LINES);
		for (i = 0; i < DIM; i++) {
			for (j = 0; j < DIM; j++) {
				idx = (j * DIM) + i;
				glColor3d(1, 0, 0);
				glVertex2d(wn + (fftw_real)i * wn, hn + (fftw_real)j * hn);
				glVertex2d((wn + (fftw_real)i * wn) + VelDrawScalar * u[idx], (hn + (fftw_real)j * hn) + VelDrawScalar * v[idx]);
			}
		}
		glEnd();
	}
}

void reshape(int w, int h) {
// 	glViewport(0.0f, 0.0f, (GLfloat)w, (GLfloat)h);
//	glMatrixMode(GL_PROJECTION);  
//	glLoadIdentity();
//	gluOrtho2D(0.0, (GLdouble)w, 0.0, (GLdouble)h);
	winWidth = w;
	winHeight = h;
}

void init(void) {
	int i;

	init_FFT(DIM);

	for (i = 0; i < DIM * DIM; i++) {
		u[i] = v[i] = u0[i] = v0[i] = u_u0[i] = u_v0[i] = 0.0f;

		rgb_rho0[0][i] = rgb_rho0[1][i] = rgb_rho0[2][i] = 0.0f;
		rgb_rho[0][i] = rgb_rho[1][i] = rgb_rho[2][i] = 0.0f;
	}
}

#define DROP_RADIUS	0

/*
 * When the user drags with the mouse, add a force
 * that corresponds to the direction of the mouse
 * cursor movement. Also inject som new matter into
 * the field at the mouse location.
 *
 */
vector_t rgb_currentColor = {1,0,0};

void drag(float mx, float my, float dx, float dy) {
	int     xi;
	int     yi;
	float	len;
	int     X, Y;

	static M_CVar *fdsjkdsfl = new M_CVar(&rgb_currentColor, "color");

	/* Compute the array index that corresponds to the
	 * cursor location */

	xi = (int)floor((double)(DIM + 1) * mx);
	yi = (int)floor((double)(DIM + 1) * my);

	for (int yn = yi - DROP_RADIUS; yn <= yi + DROP_RADIUS; yn++)
	{
		Y = yn;
		if (Y > (DIM - 1)) {
			Y = DIM - 1;
		}
		if (Y < 0) {
			Y = 0;
		}

		for (int xn = xi - DROP_RADIUS; xn <= xi + DROP_RADIUS; xn++)
		{
			X = xn;
			if (X > (DIM - 1)) {
				X = DIM - 1;
			}
			if (X < 0) {
				X = 0;
			}

			/* Add force at the cursor location */

			len = (float)sqrt(dx * dx + dy * dy);
		  if (len != 0.0) { 
			dx *= 0.1f / len;
			dy *= 0.1f / len;
		  }
			u_u0[Y * DIM + X] += dx;
			u_v0[Y * DIM + X] += dy;

			/* Increase matter density at the cursor location */

			scalar_t scalar = 10.f * MFRand();

			rgb_rho[0][Y * DIM + X] = rgb_currentColor.x * scalar;
			rgb_rho[1][Y * DIM + X] = rgb_currentColor.y * scalar;
			rgb_rho[2][Y * DIM + X] = rgb_currentColor.z * scalar;
		}
	}
}


/*
 * Copy user-induced forces to the force vectors
 * that is sent to the solver. Also dampen forces and
 * matter density.
 *
 */
void setForces(void) {
	int i;

	static float matterDecay = 0.995f;
	static float velDecay = 0.85f;
	static M_CVar *fdjlkds[] = {
		new M_CVar(&matterDecay, "matterDecay"),
		new M_CVar(&velDecay, "velDecay"),
		NULL};

	for (i = 0; i < DIM * DIM; i++) {

		rgb_rho0[0][i] = matterDecay * rgb_rho[0][i];
		rgb_rho0[1][i] = matterDecay * rgb_rho[1][i];
		rgb_rho0[2][i] = matterDecay * rgb_rho[2][i];

		u_u0[i] *= velDecay;
		u_v0[i] *= velDecay;

		u0[i] = u_u0[i];
		v0[i] = u_v0[i];
	}
}







class Particle {
public:
	float px, py;
	int life;
	scalar_t invMass;
};

#define PARMAXLIFE	50
#define PARCOUNT	3000

Particle *par = NULL;

bool Init_ParSys(void)
{
	par = (Particle *)malloc(PARCOUNT * sizeof(Particle));
	if (!par) return false;

	for (int a = 0; a < PARCOUNT; a++)
	{
		par[a].px = MFRand() * winWidth;
		par[a].py = MFRand() * winHeight;
		par[a].life = MRand() % PARMAXLIFE;
		par[a].invMass = MFRand() * 75.f + 25.f;
	}

	return true;
}

void Update_ParSys(void)
{
	int a,x,y;
	static float lastx;
	static float lasty;

	static float massRangeMax = 75.f, massRangeMin = 25.f;
	static M_CVar *kjfds[] = {
		new M_CVar(&massRangeMax, "massRangeMax"),
		new M_CVar(&massRangeMin, "massRangeMin"),
		NULL};

	glBegin(GL_LINES);
	for (a = 0; a < PARCOUNT; a++)
	{
		x = (int)((double)DIM * par[a].px / (double)winWidth);
		y = (int)((double)DIM * par[a].py / (double)winHeight);

		if (x < 0 ||		y < 0 ||
			x >= DIM ||		y >= DIM ||
			par[a].life > PARMAXLIFE)
		{
			lastx = par[a].px = MFRand() * winWidth;
			lasty = par[a].py = MFRand() * winHeight;
			par[a].life = 0;
			par[a].invMass = MFRand() * (massRangeMax - massRangeMin) + massRangeMin;
		}
		else
		{
			int index = x + DIM * y;

			lastx = par[a].px;
			lasty = par[a].py;

			par[a].px += par[a].invMass * (float)u[index];
			par[a].py += par[a].invMass * (float)v[index];
			par[a].life++;

		}

		scalar_t color = 2.f * (scalar_t)par[a].life / (scalar_t)PARMAXLIFE;
		color = 1.f - (color - 1.f) * (color - 1.f);

		glColor3f(color,color,color);

		glVertex2f(lastx, lasty);
		glVertex2f(par[a].px, par[a].py);
	}
	glEnd();
}

void Shutdown_ParSys(void)
{
	if (par) free(par);
	par = NULL;
}







bool Init_Application3D(void)
{
	main_camera->adjustRatio = CAMERA_ADJUST_NO;
	QuatSet(&main_camera->angle, 0.5f, -0.5f, -0.5f, -0.5f);
	VectorSet(&main_camera->position, 50,50,50);
	overrideCameraKeys = true;

	main_console->SetIdleVisible(false);
	CVar_Exec("ConsoleFont ../M_Foundation/ConsoleData/font.bmp");

	new M_CVar(&dt, "dt");
	new M_CVar(&drawVelocities, "drawVelocities");

	reshape(100, 100);
	init();

	if (!Init_ParSys()) return false;

	return true;
}

void Update_Application3D(void)
{
	//if mouse...
	if (main_mouse->buttonState[0])
	{
		static float mouseForce = 10.f;
		static M_CVar *fdjksdf = new M_CVar(&mouseForce, "mouseForce");

		drag(main_mouse->mouseSX,
			main_mouse->mouseSY,
			main_mouse->moveSX * mouseForce,
			main_mouse->moveSY * mouseForce);
	}

	glDisable(GL_TEXTURE_2D);

	//idle
	static float viscousity = 0.001f;
	static M_CVar *dfjlkfds = new M_CVar(&viscousity, "viscousity");

	setForces();

	stable_solve(DIM, u, v, u0, v0, viscousity, dt);

	static int useMatter = 0;
	static M_CVar *fsld = new M_CVar(&useMatter, "useMatter");

	if (useMatter)
	{

		diffuse_matter(DIM, u, v, rgb_rho[0], rgb_rho0[0], dt);
		diffuse_matter(DIM, u, v, rgb_rho[1], rgb_rho0[1], dt);
		diffuse_matter(DIM, u, v, rgb_rho[2], rgb_rho0[2], dt);

		//display
		drawField();
	}

	t += dt;

	//keybaord
	if (main_keyboard->keystate[VkKeyScan('1')] == KBH_PRESS)	VectorSet(&rgb_currentColor, 1,0,0);
	if (main_keyboard->keystate[VkKeyScan('2')] == KBH_PRESS)	VectorSet(&rgb_currentColor, 1,1,0);
	if (main_keyboard->keystate[VkKeyScan('3')] == KBH_PRESS)	VectorSet(&rgb_currentColor, 0,1,0);
	if (main_keyboard->keystate[VkKeyScan('4')] == KBH_PRESS)	VectorSet(&rgb_currentColor, 0,1,1);
	if (main_keyboard->keystate[VkKeyScan('5')] == KBH_PRESS)	VectorSet(&rgb_currentColor, 0,0,1);
	if (main_keyboard->keystate[VkKeyScan('6')] == KBH_PRESS)	VectorSet(&rgb_currentColor, 1,0,1);

	Update_ParSys();
}

void Shutdown_Application3D(void)
{
	Shutdown_ParSys();
	rfftwnd_destroy_plan(plan_rc);
	rfftwnd_destroy_plan(plan_cr);
}