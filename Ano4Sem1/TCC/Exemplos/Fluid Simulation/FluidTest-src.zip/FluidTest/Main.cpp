// ********************************
//   Below is the original Gustav Taxen code
//  modified slightly to be extended into 3D
//  I also tweaked the display function
//   --Chris Moore
// ********************************


/*
 * This program uses the fluid dynamics solver presented
 * in Jos Stam, "A Simple Fluid Solver Based on the FFT",
 * (http://www.dgp.utoronto.ca/people/stam/reality/Research/pub.html)
 * to produce a impression of swirly smoke in real-time.
 * 
 * To compile this program, you need "The Fastest Forurier 
 * Transform in the West", i.e., the fftw and rfftw libraries 
 * and header files. They can be downloaded from 
 * http://www.fftw.org.
 *
 *   --  Author: Gustav Taxen, gustavt@nada.kth.se --
 *   --      This code is in the public domain.    --
 *
 * USAGE:
 *
 * Drag with the mouse to add smoke to the fluid. This will
 * also move a "rotor" that disturbs the velocity field to
 * the mouse location.
 *
 * 'w' toggles wireframe rendering.
 * 'v' toggles rendering of velocity vectors. 
 * 'T' and 't' increases and decreases the simulation time step, 
 * respectively.
 *
 * NOTE: The parameters I've chosen for the simulation are
 * targeted at a Pentium III 850MHz laptop with a ATI Rage 
 * Mobility M4 graphics card. You may have to change them to
 * suit your machine (see below).
 *
 */

#ifdef WIN32
#include <windows.h>
#endif

#include <math.h>

#include "fftw/rfftw.h"
#include <GL/gl.h>

#include "../m_system3d/main.h"
#include "../m_foundation/main.h"
#include "../m_foundation/random.h"

/*
 * Size of the simulation grid, i.e. the number of grid
 * points are (DIM x DIM).
 *
 */
#define DIM 16
#define ARRAYSIZE (DIM * DIM * 2*(DIM/2+1))

/* 
 * Simulation time step: you may need to change this to suit
 * your particular machine speed.
 *
 */
double dt = 0.1;

vector_t cube_min = {-50,-50,-50};
vector_t cube_max = {50,50,50};


int    drawVelocities = 0;

double t = 0;

/* 
 * See Jos Stam, "A Simple Fluid Solver Based on the FFT",
 * http://www.dgp.utoronto.ca/people/stam/reality/Research/pub.html
 * for more details on the following code.
 *
 */

fftw_real u[ARRAYSIZE], v[ARRAYSIZE], w[ARRAYSIZE];
fftw_real u0[ARRAYSIZE], v0[ARRAYSIZE], w0[ARRAYSIZE];
fftw_real rgb_rho[3][DIM*DIM*DIM], rgb_rho0[3][DIM*DIM*DIM];  /* Smoke density */
fftw_real u_u0[DIM*DIM*DIM], u_v0[DIM*DIM*DIM], u_w0[DIM*DIM*DIM];  /* User-induced forces */

static rfftwnd_plan plan_rc, plan_cr;

void init_FFT(int n) {
	plan_rc = rfftw3d_create_plan(n, n, n, FFTW_REAL_TO_COMPLEX, FFTW_IN_PLACE);
	plan_cr = rfftw3d_create_plan(n, n, n, FFTW_COMPLEX_TO_REAL, FFTW_IN_PLACE);
}

//#define FFT(s,u)\
//	if(s==1) rfftwnd_one_real_to_complex(plan_rc,(fftw_real *)u,(fftw_complex*)u);\
//	else rfftwnd_one_complex_to_real(plan_cr,(fftw_complex *)u,(fftw_real *)u)

#define floor(x) ((x)>=0.0?((int)(x)):(-((int)(1-(x)))))

void stable_solve (
	int n,
	fftw_real * u, fftw_real * v, fftw_real * w,
	fftw_real * u0, fftw_real * v0, fftw_real * w0,
	fftw_real visc, fftw_real dt
) {
	fftw_real x, y, z;
	fftw_real x0, y0, z0;
	fftw_real f, r;
	fftw_real U[2], V[2], W[2];
	fftw_real s, t, q;
 
	int e, i, j, k;
	int i0, j0, k0;
	int i1, j1, k1;

	e = n*n*n;
	for ( i=0 ; i < e ; i++ )
	{
		u[i] += dt*u0[i];	u0[i] = u[i];
		v[i] += dt*v0[i];	v0[i] = v[i];
		w[i] += dt*w0[i];	w0[i] = w[i];
	}    

	e = 0;
	for ( z=0.5f/n,k=0 ; k<n ; k++,z+=1.0f/n )
	{
		for ( y=0.5f/n,j=0 ; j<n ; j++,y+=1.0f/n )
		{
			for ( x=0.5f/n,i=0 ; i<n ; i++,x+=1.0f/n )
			{

				x0 = n*(x-dt*u0[e])-0.5f; 
				y0 = n*(y-dt*v0[e])-0.5f;
				z0 = n*(z-dt*w0[e])-0.5f;

#if 1
				i0 = floor(x0);
				s = x0-i0;
				i0 = (n+(i0%n))%n;
				i1 = (i0+1)%n;

				j0 = floor(y0);
				t = y0-j0;
				j0 = (n+(j0%n))%n;
				j1 = (j0+1)%n;

				k0 = floor(z0);
				q = z0-k0;
				k0 = (n+(k0%n))%n;
				k1 = (k0+1)%n;
#else
				i0 = floor(x0);
				s = x0-i0;
				i1 = i0+1;

				j0 = floor(y0);
				t = y0-j0;
				j1 = j0+1;

				k0 = floor(z0);
				q = z0-k0;
				k1 = k0+1;

				if (k0 < 0 || k0 >= n ||
					j0 < 0 || j0 >= n ||
					i0 < 0 || i0 >= n ||
					k1 < 0 || k1 >= n ||
					j1 < 0 || j1 >= n ||
					i1 < 0 || i1 >= n)
				{
					u[e] = v[e] = w[e] = 0;
					e++;
					continue;
				}
#endif
				u[e] =
					(1-q)*(1-s)*(1-t)*u0[i0+n*(j0+n*k0)] +
					(1-q)*(1-s)*( t )*u0[i0+n*(j1+n*k0)] +
					(1-q)*( s )*(1-t)*u0[i1+n*(j0+n*k0)] +
					(1-q)*( s )*( t )*u0[i1+n*(j1+n*k0)] +
					( q )*(1-s)*(1-t)*u0[i0+n*(j0+n*k1)] +
					( q )*(1-s)*( t )*u0[i0+n*(j1+n*k1)] +
					( q )*( s )*(1-t)*u0[i1+n*(j0+n*k1)] +
					( q )*( s )*( t )*u0[i1+n*(j1+n*k1)];

				v[e] =
					(1-q)*(1-s)*(1-t)*v0[i0+n*(j0+n*k0)] +
					(1-q)*(1-s)*( t )*v0[i0+n*(j1+n*k0)] +
					(1-q)*( s )*(1-t)*v0[i1+n*(j0+n*k0)] +
					(1-q)*( s )*( t )*v0[i1+n*(j1+n*k0)] +
					( q )*(1-s)*(1-t)*v0[i0+n*(j0+n*k1)] +
					( q )*(1-s)*( t )*v0[i0+n*(j1+n*k1)] +
					( q )*( s )*(1-t)*v0[i1+n*(j0+n*k1)] +
					( q )*( s )*( t )*v0[i1+n*(j1+n*k1)];

				w[e] =
					(1-q)*(1-s)*(1-t)*w0[i0+n*(j0+n*k0)] +
					(1-q)*(1-s)*( t )*w0[i0+n*(j1+n*k0)] +
					(1-q)*( s )*(1-t)*w0[i1+n*(j0+n*k0)] +
					(1-q)*( s )*( t )*w0[i1+n*(j1+n*k0)] +
					( q )*(1-s)*(1-t)*w0[i0+n*(j0+n*k1)] +
					( q )*(1-s)*( t )*w0[i0+n*(j1+n*k1)] +
					( q )*( s )*(1-t)*w0[i1+n*(j0+n*k1)] +
					( q )*( s )*( t )*w0[i1+n*(j1+n*k1)];

				e++;
			}
		}    
	} 

	e = 0;
	for (k = 0; k < n; k++) {
		for (j = 0; j < n ; j++) {
			for (i = 0; i < n; i++) {
				u0[i + (n+2)*(j + n*k)] = u[e]; 
				v0[i + (n+2)*(j + n*k)] = v[e];
				w0[i + (n+2)*(j + n*k)] = w[e];
				e++;
			}
		}
	}

	rfftwnd_one_real_to_complex(plan_rc,(fftw_real *)u0,(fftw_complex*)u0);
	rfftwnd_one_real_to_complex(plan_rc,(fftw_real *)v0,(fftw_complex*)v0);
	rfftwnd_one_real_to_complex(plan_rc,(fftw_real *)w0,(fftw_complex*)w0);


	for ( k=0 ; k<n ; k++ ) {
		z = (k <= n/2) ? (fftw_real)k : (fftw_real)k-n;
		for ( j=0 ; j<n ; j++ ) {
			y = 0.5f * j;
			for ( i=0 ; i<=n ; i+=2 ) {
				x = 0.5f * i;

				//calc index
				e = i + (n + 2)*(j + n * k);

				r = x*x + y*y + z*z;

				if ( r==0.0f ) continue;

				f = (fftw_real)exp(-r*dt*visc);

				U[0] = u0[e];	V[0] = v0[e];	W[0] = w0[e];
				U[1] = u0[e+1];	V[1] = v0[e+1];	W[1] = w0[e+1];

				u0[e]	= f*( (1-x*x/r)*U[0]     -x*y/r *V[0]     -x*z/r *W[0] );
				u0[e+1] = f*( (1-x*x/r)*U[1]     -x*y/r *V[1]     -x*z/r *W[1] );

				v0[e]	= f*(   -y*x/r *U[0] + (1-y*y/r)*V[0]     -y*z/r *W[0] );
				v0[e+1] = f*(   -y*x/r *U[1] + (1-y*y/r)*V[1]     -y*z/r *W[1] );

				w0[e]	= f*(   -z*x/r *U[0]     -z*y/r *V[0] + (1-z*z/r)*W[0] );
				w0[e+1]	= f*(   -z*x/r *U[1]     -z*y/r *V[1] + (1-z*z/r)*W[1] );
			}
		}    
	}

	rfftwnd_one_complex_to_real(plan_cr,(fftw_complex *)u0,(fftw_real *)u0);
	rfftwnd_one_complex_to_real(plan_cr,(fftw_complex *)v0,(fftw_real *)v0);
	rfftwnd_one_complex_to_real(plan_cr,(fftw_complex *)w0,(fftw_real *)w0);

	f = 1.0/(n*n*n);
	e = 0;
	for (k = 0; k < n; k++)
	{
		for ( j = 0 ; j < n ; j++ )
		{
 			for ( i = 0 ; i < n ; i++ )
			{
				u[e] = f*u0[i+(n+2)*(j+n*k)]; 
				v[e] = f*v0[i+(n+2)*(j+n*k)]; 
				w[e] = f*w0[i+(n+2)*(j+n*k)]; 
				e++;
			}
		}
	}
} 


/*
 * This function diffuses matter that has been placed
 * in the velocity field. It's almost identical to the
 * velocity diffusion step in the function above. The
 * input matter densities are in rho0 and the result
 * is written into rho.
 *
 */
void diffuse_matter(
	int n,
	fftw_real *u, fftw_real *v, fftw_real *w,
	fftw_real *rho, fftw_real *rho0, fftw_real dt
) {
//	fftw_real x, y, z;
//	fftw_real x0, y0, z0;
//	fftw_real s, t, q;
//	int i, j, i0, j0, i1, j1;

	fftw_real x, y, z;
	fftw_real x0, y0, z0;
	fftw_real s, t, q;

	int e=0, i, j, k;
	int i0, j0, k0;
	int i1, j1, k1;


	for ( z=0.5f/n,k=0 ; k<n ; k++,z+=1.0f/n )
	{
		for ( y=0.5f/n,j=0 ; j<n ; j++,y+=1.0f/n )
		{
			for ( x=0.5f/n,i=0 ; i<n ; i++,x+=1.0f/n )
			{
				x0 = n*(x-dt*u[e])-0.5f; 
				y0 = n*(y-dt*v[e])-0.5f;
				z0 = n*(z-dt*w[e])-0.5f;

#if 1
				i0 = floor(x0);	s = x0-i0;	i0 = (n+(i0%n))%n;	i1 = (i0+1)%n;
				j0 = floor(y0);	t = y0-j0;	j0 = (n+(j0%n))%n;	j1 = (j0+1)%n;
				k0 = floor(z0); q = z0-k0;	k0 = (n+(k0%n))%n;	k1 = (k0+1)%n;
#else
				i0 = floor(x0);
				s = x0 - i0;
				i1 = i0 + 1;
				j0 = floor(y0);
				t = y0 - j0;
				j1 = j0 + 1;
				k0 = floor(z0);
				q = z0 - k0;
				k1 = k0 + 1;

				if (k0 < 0 || k0 >= n ||
					j0 < 0 || j0 >= n ||
					i0 < 0 || i0 >= n ||
					k1 < 0 || k1 >= n ||
					j1 < 0 || j1 >= n ||
					i1 < 0 || i1 >= n)
				{
					rho[e] = 0;
					e++;
					continue;
				}
#endif
				rho[e] =
					(1-q)*(1-s)*(1-t)*rho0[i0+n*(j0+n*k0)] +
					(1-q)*(1-s)*( t )*rho0[i0+n*(j1+n*k0)] +
					(1-q)*( s )*(1-t)*rho0[i1+n*(j0+n*k0)] +
					(1-q)*( s )*( t )*rho0[i1+n*(j1+n*k0)] +
					( q )*(1-s)*(1-t)*rho0[i0+n*(j0+n*k1)] +
					( q )*(1-s)*( t )*rho0[i0+n*(j1+n*k1)] +
					( q )*( s )*(1-t)*rho0[i1+n*(j0+n*k1)] +
					( q )*( s )*( t )*rho0[i1+n*(j1+n*k1)];

				e++;
			}
		}    
	} 
}

/*
 * Draw the fluid using triangle strips.
 *
 */
void drawField(void) {

	int        i, j, k, idx;
	static float VelColorScalar = 100.f;
	static float VelDrawScalar = 10.f;
	static CVarw *dflkfds[] = {
		new CVarw(&VelColorScalar, "VelColorScalar"),
		new CVarw(&VelDrawScalar, "VelDrawScalar"),
	};

#if 0
	fftw_real  wn = (fftw_real)winWidth / (fftw_real)(DIM + 1);   /* Grid element width */
	fftw_real  hn = (fftw_real)winHeight / (fftw_real)(DIM + 1);  /* Grid element height */
	double     px, py;

	for (j = 0; j < DIM - 1; j++) {
		glBegin(GL_TRIANGLE_STRIP);

		i = 0;
		px = wn + (fftw_real)i * wn;
		py = hn + (fftw_real)j * hn;
		idx = (j * DIM) + i;
//		glColor3f(rho[idx], rho[idx], rho[idx]);
//		glColor3f(1, rho[idx], rho[idx]);
//		glColor3f(rho[idx], VelColorScalar*u[idx], VelColorScalar*v[idx]);
		glColor3f(rgb_rho[0][idx], rgb_rho[1][idx], rgb_rho[2][idx]);
		glVertex2f(px, py);
						
		for (i = 0; i < DIM - 1; i++) {
			px = wn + (fftw_real)i * wn;
			py = hn + (fftw_real)(j + 1) * hn;
			idx = ((j + 1) * DIM) + i;
//			glColor3f(rho[idx], rho[idx], rho[idx]);
//			glColor3f(1, rho[idx], rho[idx]);
//			glColor3f(rho[idx], VelColorScalar*u[idx], VelColorScalar*v[idx]);
			glColor3f(rgb_rho[0][idx], rgb_rho[1][idx], rgb_rho[2][idx]);
			glVertex2f(px, py);

			px = wn + (fftw_real)(i + 1) * wn;
			py = hn + (fftw_real)j * hn;
			idx = (j * DIM) + (i + 1);
//			glColor3f(rho[idx], rho[idx], rho[idx]);
//			glColor3f(1, rho[idx], rho[idx]);
//			glColor3f(rho[idx], VelColorScalar*u[idx], VelColorScalar*v[idx]);
			glColor3f(rgb_rho[0][idx], rgb_rho[1][idx], rgb_rho[2][idx]);
			glVertex2f(px, py);
		}

		px = wn + (fftw_real)(DIM - 1) * wn;
		py = hn + (fftw_real)(j + 1) * hn;
		idx = ((j + 1) * DIM) + (DIM - 1);
//		glColor3f(rho[idx], rho[idx], rho[idx]);
//		glColor3f(1, rho[idx], rho[idx]);
//		glColor3f(rho[idx], VelColorScalar*u[idx], VelColorScalar*v[idx]);
		glColor3f(rgb_rho[0][idx], rgb_rho[1][idx], rgb_rho[2][idx]);
		glVertex2f(px, py);

		glEnd();
	}

#endif

	if (drawVelocities)
	{
		static vector_t elem, src;
		elem.x = (cube_max.x - cube_min.x) / (scalar_t)(DIM + 1);
		elem.y = (cube_max.y - cube_min.y) / (scalar_t)(DIM + 1);
		elem.z = (cube_max.z - cube_min.z) / (scalar_t)(DIM + 1);

		glBegin(GL_LINES);

		for (i = 0; i < DIM; i++) {
			for (j = 0; j < DIM; j++) {
				for (k = 0; k < DIM; k++) {

					idx = i + ((j + k * DIM) * DIM);
					
//					glColor3f(1, 0, 0);
					glColor3f(
						rgb_rho[0][idx],
						rgb_rho[1][idx],
						rgb_rho[2][idx]);

					src.x = (scalar_t)(i+1) * elem.x + cube_min.x;
					src.y = (scalar_t)(j+1) * elem.x + cube_min.y;
					src.z = (scalar_t)(k+1) * elem.x + cube_min.z;
					
					glVertex3fv(src.v);
					
					glVertex3f(
						src.x + VelDrawScalar * (scalar_t)u[idx],
						src.y + VelDrawScalar * (scalar_t)v[idx],
						src.z + VelDrawScalar * (scalar_t)w[idx]);
				}
			}
		}
		glEnd();
	}

}

void init(void) {
	int i;

	init_FFT(DIM);

	for (i = 0; i < DIM * DIM * DIM; i++)
	{
		u[i] = v[i] = w[i] = 0;
		u0[i] = v0[i] = w0[i] = 0;
		u_u0[i] = u_v0[i] = u_w0[i] = 0.0f;

		rgb_rho0[0][i] = rgb_rho0[1][i] = rgb_rho0[2][i] = 0.0f;
		rgb_rho[0][i] = rgb_rho[1][i] = rgb_rho[2][i] = 0.0f;
	}
}

bool MyBoxLineIntersect(
	const box_t *box,
	const vector_t *pos,
	const vector_t *dir,
	vector_t *res)
{
	bool collided = false;
	vector_t intersect;
	float bestfrac = 1;
	for (int dim = 0; dim < 3; dim++) {
		if (!dir->v[dim]) continue;
		for (int side = 0; side < 2; side++) {
			float fraction = (box->vec[side].v[dim] - pos->v[dim]) / dir->v[dim];
			if (fraction < 0 || fraction > bestfrac) continue;
			VectorMultAdd(pos, dir, fraction, &intersect);
			int dnot = (dim + 1) % 3;
			if (intersect.v[dnot] < box->min.v[dnot] || intersect.v[dnot] > box->max.v[dnot]) continue;
			dnot = (dnot + 1) % 3;
			if (intersect.v[dnot] < box->min.v[dnot] || intersect.v[dnot] > box->max.v[dnot]) continue;
			bestfrac = fraction;
			memcpy(res, &intersect, sizeof(vector_t));
			collided = true;
		}
	}
	return collided;
}


/*
 * When the user drags with the mouse, add a force
 * that corresponds to the direction of the mouse
 * cursor movement. Also inject som new matter into
 * the field at the mouse location.
 *
 */
vector_t rgb_currentColor = {1,0,0};

#define DROPRAD	1

vector_t lastDropIntersect;

void drag(float mx, float my, float dx, float dy) {

	//vector_t src = mouseLine.pos;
	vector_t dir;
	vector_t intersect;

	VectorScale(&main_camera->mouseLine.dir, (main_camera->zfar / main_camera->znear), &dir);
	//dir = main_camera->mouseLine.dir * (main_camera->zfar / main_camera->znear);

	box_t worldBox;
	worldBox.min = cube_min;
	worldBox.max = cube_max;

	if (MyBoxLineIntersect(&worldBox, &main_camera->mouseLine.pos, &dir, &intersect))
	{
		lastDropIntersect = intersect;

//		VectorScale(&intersect, 0.9f, &intersect);

		int x = (int)((DIM-1) * (intersect.x - cube_min.x) / (cube_max.x - cube_min.x));
		int y = (int)((DIM-1) * (intersect.y - cube_min.y) / (cube_max.y - cube_min.y));
		int z = (int)((DIM-1) * (intersect.z - cube_min.z) / (cube_max.z - cube_min.z));

		if (x < 0) x = 0;
		if (y < 0) y = 0;
		if (z < 0) z = 0;
		if (x >= DIM-1) x = DIM - 2;
		if (y >= DIM-1) y = DIM - 2;
		if (z >= DIM-1) z = DIM - 2;

		int index = x + DIM * (y + DIM * z);

		vector_t del;
//		VectorMultAdd(&cubeSize, &intersect, -2.f, &del);
		VectorScale(&intersect, -1.f, &del);
		VectorUnit(&del, &del);
		//del = (cubeSize * 0.5f) - intersect;
		//equiv of "del = cubeSize - 2.f * intersect;"
		//del.Normalize();

		u_u0[index] += del.x * 0.1f;
		u_v0[index] += del.y * 0.1f;
		u_w0[index] += del.z * 0.1f;

		/* Increase matter density at the cursor location */

		static const scalar_t scalar = 10.f;

		rgb_rho[0][index] = rgb_currentColor.x * scalar;
		rgb_rho[1][index] = rgb_currentColor.y * scalar;
		rgb_rho[2][index] = rgb_currentColor.z * scalar;

	}
}


/*
 * Copy user-induced forces to the force vectors
 * that is sent to the solver. Also dampen forces and
 * matter density.
 *
 */
void setForces(void) {
	int i;

	static float matterDecay = 0.995f;
	static float velDecay = 0.85f;
	static CVarw *fdjlkds[] = {
		new CVarw(&matterDecay, "matterDecay"),
		new CVarw(&velDecay, "velDecay"),
		NULL};

	for (i = 0; i < DIM * DIM * DIM; i++) {

		rgb_rho0[0][i] = matterDecay * rgb_rho[0][i];
		rgb_rho0[1][i] = matterDecay * rgb_rho[1][i];
		rgb_rho0[2][i] = matterDecay * rgb_rho[2][i];

		u_u0[i] *= velDecay;
		u_v0[i] *= velDecay;
		u_w0[i] *= velDecay;

		u0[i] = u_u0[i];
		v0[i] = u_v0[i];
		w0[i] = u_w0[i];
	}
}

// ********************************
//   below is the interface between my input / framework and Gustav Taxen's code:
// ********************************

#define PARCOUNT	5000
#define PARMAXLIFE	100
#define PARHISTORY	100

class Particle {
public:
	vector_t pos;
	int life;
	scalar_t invMass;

	vector_t hist[PARHISTORY];	//w-component will be the 'used?' flag.  
	int hist_size;			//i could just use the life var ...
};

Particle *par = NULL;

bool Init_ParSys(void)
{
	par = (Particle *)malloc(PARCOUNT * sizeof(Particle));
	if (!par) return false;

	for (int a = 0; a < PARCOUNT; a++)
	{
		VectorSet(&par[a].pos,
			MFRand() * (cube_max.x - cube_min.x) + cube_min.x,
			MFRand() * (cube_max.y - cube_min.y) + cube_min.y,
			MFRand() * (cube_max.z - cube_min.z) + cube_min.z);
		par[a].life = MRand() % PARMAXLIFE;
		par[a].invMass = MFRand() * 75.f + 25.f;

		memset(par[a].hist, 0, sizeof(par[a].hist));
		par[a].hist_size = 0;
	}

	return true;
}

void Update_ParSys(void)
{
	int a,x,y,z;
	static vector_t last;

	static int use_particles = 1;
	static float massRangeMax = 75.f, massRangeMin = 25.f;
	static CVarw *kjfds[] = {
		new CVarw(&massRangeMax,	"massRangeMax"),
		new CVarw(&massRangeMin,	"massRangeMin"),
		new CVarw(&use_particles,	"use_particles"),
	};

	if (!use_particles) return;

	for (a = 0; a < PARCOUNT; a++)
	{
		par[a].hist_size++;	//make room for the new insertion
		if (par[a].hist_size > PARHISTORY) par[a].hist_size = PARHISTORY;	//cap out the max
		//before updating the position, copy the old pos into the history buffer
		for (int j = par[a].hist_size-1; j > 0; j--) {
			par[a].hist[j] = par[a].hist[j-1];
		}
		par[a].hist[0] = par[a].pos;

		x = (int)((double)DIM * (par[a].pos.x - cube_min.x) / (double)(cube_max.x - cube_min.x));
		y = (int)((double)DIM * (par[a].pos.y - cube_min.y) / (double)(cube_max.y - cube_min.y));
		z = (int)((double)DIM * (par[a].pos.z - cube_min.z) / (double)(cube_max.z - cube_min.z));

		if (x < 0 ||		y < 0 ||		z < 0 ||
			x >= DIM ||		y >= DIM ||		z >= DIM ||
			par[a].life > PARMAXLIFE)
		{
			VectorSet(&last,
				MFRand() * (cube_max.x - cube_min.x) + cube_min.x,
				MFRand() * (cube_max.y - cube_min.y) + cube_min.y,
				MFRand() * (cube_max.z - cube_min.z) + cube_min.z);
			VectorCopy(&last, &par[a].pos);
			par[a].life = 0;
			par[a].invMass = MFRand() * (massRangeMax - massRangeMin) + massRangeMin;
			memset(par[a].hist, 0, sizeof(par[a].hist));
			par[a].hist_size = 0;
		}
		else
		{
			int index = x + DIM * (y + DIM * z);

			last = par[a].pos;

			par[a].pos.x += par[a].invMass * (float)u[index];
			par[a].pos.y += par[a].invMass * (float)v[index];
			par[a].pos.z += par[a].invMass * (float)w[index];

			par[a].life++;
		}

		scalar_t color = 2.f * (scalar_t)par[a].life / (scalar_t)PARMAXLIFE;
		color = 1.f - (color - 1.f) * (color - 1.f);
		glColor3f(color,color,color);

		glBegin(GL_LINE_STRIP);
		glVertex3fv(par[a].pos.v);
		for (j = 0; j < par[a].hist_size; j++) {
			glVertex3fv(par[a].hist[j].v);
		}
//		glVertex3fv(last.v);
		glEnd();
	}
}

void Shutdown_ParSys(void)
{
	if (par) free(par);
	par = NULL;
}


bool Init_Application3D(void)
{
	QuatSet(&main_camera->angle, 0.5f, -0.5f, -0.5f, -0.5f);
	VectorSet(&main_camera->position, 50,50,50);
	CVar_Exec("ConsoleFont font.bmp");
	CVar_Exec("Console idlevis 0");
	overrideCameraKeys = true;

	new CVarw(&dt, "dt");
	new CVarw(&drawVelocities, "drawVelocities");

	init();

	if (!Init_ParSys()) return false;

	return true;
}

void Update_Application3D(void)
{
	//if mouse...
	if (main_mouse->buttonState[0])
	{
		static float mouseForce = 10.f;
		static CVarw *fdjksdf = new CVarw(&mouseForce, "mouseForce");

		drag(main_mouse->mouseSX,
			main_mouse->mouseSY,
			main_mouse->moveSX * mouseForce,
			main_mouse->moveSY * mouseForce);
	}

	glDisable(GL_TEXTURE_2D);

	//idle
	static float viscousity = 0.001f;
	static CVarw *dfjlkfds = new CVarw(&viscousity, "viscousity");

	setForces();

	stable_solve(DIM, u, v, w, u0, v0, w0, viscousity, dt);

	static int useMatter = 0;
	static CVarw *fsld = new CVarw(&useMatter, "useMatter");
	if (useMatter)
	{
		diffuse_matter(DIM, u, v, w, rgb_rho[0], rgb_rho0[0], dt);
		diffuse_matter(DIM, u, v, w, rgb_rho[1], rgb_rho0[1], dt);
		diffuse_matter(DIM, u, v, w, rgb_rho[2], rgb_rho0[2], dt);
		//display
		drawField();
	}

	Update_ParSys();

	glBegin(GL_LINES);
	glColor3f(1,0,0);
	glVertex3f(lastDropIntersect.x+5,lastDropIntersect.y,lastDropIntersect.z);
	glVertex3f(lastDropIntersect.x-5,lastDropIntersect.y,lastDropIntersect.z);
	glColor3f(0,1,0);
	glVertex3f(lastDropIntersect.x,lastDropIntersect.y+5,lastDropIntersect.z);
	glVertex3f(lastDropIntersect.x,lastDropIntersect.y-5,lastDropIntersect.z);
	glColor3f(0,0,1);
	glVertex3f(lastDropIntersect.x,lastDropIntersect.y,lastDropIntersect.z+5);
	glVertex3f(lastDropIntersect.x,lastDropIntersect.y,lastDropIntersect.z-5);
	glEnd();

	t += dt;

	//keybaord
	if (main_keyboard->keystate[VkKeyScan('1')] == KBH_PRESS)	VectorSet(&rgb_currentColor, 1,0,0);
	if (main_keyboard->keystate[VkKeyScan('2')] == KBH_PRESS)	VectorSet(&rgb_currentColor, 1,1,0);
	if (main_keyboard->keystate[VkKeyScan('3')] == KBH_PRESS)	VectorSet(&rgb_currentColor, 0,1,0);
	if (main_keyboard->keystate[VkKeyScan('4')] == KBH_PRESS)	VectorSet(&rgb_currentColor, 0,1,1);
	if (main_keyboard->keystate[VkKeyScan('5')] == KBH_PRESS)	VectorSet(&rgb_currentColor, 0,0,1);
	if (main_keyboard->keystate[VkKeyScan('6')] == KBH_PRESS)	VectorSet(&rgb_currentColor, 1,0,1);
}

void Shutdown_Application3D(void)
{
	Shutdown_ParSys();

	rfftwnd_destroy_plan(plan_rc);
	rfftwnd_destroy_plan(plan_cr);
}