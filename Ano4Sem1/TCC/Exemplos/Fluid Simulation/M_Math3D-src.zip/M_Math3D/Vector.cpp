/*

    File: Vector.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include <math.h>
#include "vector.h"

void VectorSet(vector_t *vres, scalar_t x, scalar_t y, scalar_t z)
{
	vres->x = x;
	vres->y = y;
	vres->z = z;
}

void VectorCopy(const vector_t *v, vector_t *vres)
{
	vres->x = v->x;
	vres->y = v->y;
	vres->z = v->z;
}

void VectorAdd(const vector_t *a, const vector_t *b, vector_t *vres)
{
	vres->x = a->x + b->x;
	vres->y = a->y + b->y;
	vres->z = a->z + b->z;
}

void VectorSub(const vector_t *a, const vector_t *b, vector_t *vres)
{
	vres->x = a->x - b->x;
	vres->y = a->y - b->y;
	vres->z = a->z - b->z;
}

scalar_t VectorDot(const vector_t *a, const vector_t *b)
{
	return (a->x * b->x + a->y * b->y + a->z * b->z);
}

void VectorScale(const vector_t *a, const scalar_t s, vector_t *vres)
{
	vres->x = a->x * s;
	vres->y = a->y * s;
	vres->z = a->z * s;
}

void VectorScaleElem(const vector_t *a, const vector_t *b, vector_t *vres)
{
	vres->x = a->x * b->x;
	vres->y = a->y * b->y;
	vres->z = a->z * b->z;
}

void VectorMultAdd(const vector_t *a, const vector_t *b, const scalar_t s, vector_t *vres)
{
	vres->x = a->x + s * b->x;
	vres->y = a->y + s * b->y;
	vres->z = a->z + s * b->z;
}

void VectorCross(const vector_t *a, const vector_t *b, vector_t *vres)
{
	vector_t v;
	v.x = a->y * b->z - a->z * b->y;
	v.y = a->z * b->x - a->x * b->z;
	v.z = a->x * b->y - a->y * b->x;
	VectorCopy(&v, vres);
}

scalar_t VectorLength(const vector_t *v)
{
	return (scalar_t)sqrt(VectorLengthSq(v));
}

scalar_t VectorLengthSq(const vector_t *v)
{
	return VectorDot(v,v);
}

scalar_t VectorDist(const vector_t *a, const vector_t *b)
{
	return (scalar_t)sqrt(VectorDistSq(a,b));
}

scalar_t VectorDistSq(const vector_t *a, const vector_t *b)
{
	vector_t del;
	VectorSub(a,b,&del);
	return VectorLengthSq(&del);
}

void VectorUnit(const vector_t *v, vector_t *vres)
{
	scalar_t length = VectorLength(v);
	if (length) VectorScale(v, 1.f / length, vres);
}

scalar_t VectorScalarTripleProduct(
	const vector_t *v1, const vector_t *v2, const vector_t *v3)
{
	//do this with determinants
	//please
	vector_t reg;
	VectorCross(v1,v2,&reg);
	return VectorDot(&reg,v3);
}


//calc the normal of the plane based upon the three vectors
//and store it in the current vector
void VectorPlaneUnitNormal(const vector_t *v1, const vector_t *v2, const vector_t *v3, vector_t *vres)
{
	vector_t del1, del2;

	VectorSub(v1, v2, &del1);
	VectorSub(v3, v2, &del2);
	VectorCross(&del1, &del2, vres);
	VectorUnit(vres, vres);
}

void VectorPlaneNormal(const vector_t *v1, const vector_t *v2, const vector_t *v3, vector_t *vres)
{
	vector_t del1, del2;

	VectorSub(v1, v2, &del1);
	VectorSub(v3, v2, &del2);
	VectorCross(&del1, &del2, vres);
}

void VectorLerp(const vector_t *start, const vector_t *end, scalar_t coeff, vector_t *vres) {
//two-mul method
//	scalar_t one_minus_coeff = 1.f - coeff;
//	vres->x = start->x * one_minus_coeff + end->x * coeff;
//	vres->y = start->y * one_minus_coeff + end->y * coeff;
//	vres->z = start->z * one_minus_coeff + end->z * coeff;
//one-mul method
	vres->x = start->x + (end->x - start->x) * coeff;
	vres->y = start->y + (end->y - start->y) * coeff;
	vres->z = start->z + (end->z - start->z) * coeff;
}

void SCDif(const vector_t *v1,	const vector_t *v2,
		   const vector_t *n1,	const vector_t *n2,
		   const vector_t *vcenter,
		   vector_t *vm,	vector_t *nm)
{
	vector_t d1, d2;

	VectorSub(v1, vcenter, &d1);
	VectorSub(v2, vcenter, &d2);
	VectorAdd(&d1, &d2, &d1);
	VectorScale(&d1, 0.5f, &d1);

	//calc d1 = ((v1 - vcenter) + (v2 - vcenter)) * 0.5f

	VectorAdd(n1, n2, nm);
	VectorUnit(nm, nm);

	//calc nm = unit(n1 + n2)

	VectorScale(&d1, 1.f / VectorDot(nm, n1), vm);
	VectorAdd(vm, vcenter, vm);

	//calc vm = dl / (nm dot n1) + vcenter

	//vm is now the spherically interpolated midpoint of v1 and v2
	//nm is now the surface normal vector at point vm
}

/*
#include "geometry.h"		//pray for mojo . . . and his compiler

void SCDif(const Vector *v1, const Vector *v2, const Vector *n1, const Vector *n2,
		   Vector *vm, Vector *nm)
{
	//now how to determine vcenter...
	Line l1; l1.pos = *v1; l1.dir = *n1;
	Line l2; l2.pos = *v2; l2.dir = *n2;
	Vector param = ClosestPointParameter(l1, l2);
	Vector vcenter = ((l1.pos + l1.dir * param.x) + (l2.pos + l2.dir * param.y)) * 0.5;

	SCDif (v1, v2, n1, n2, &vcenter, vm, nm);
}
*/

int Collision_SphereTrace(
	scalar_t timestep,		//timestep
	scalar_t *col_time,		//collision time - array of two variables - to return
	const vector_t *p1,			//position at time zero of sphere 1
	const vector_t *v1,			//velocity of sphere 1
	scalar_t r1,			//radius of sphere 1
	const vector_t *p2,			//position of sphere 2
	scalar_t r2)			//radius of sphere 2
{
	col_time[0] = 0;
	col_time[1] = timestep;

	//calculate the 'a' coefficient of the quadratic formula
	scalar_t a = VectorLengthSq(v1);

	//modify 'a' to work well with other equations later down the line.
	a += a;

	//calculate the difference of position vectors - to be used later
	vector_t dx;
	VectorSub(p1, p2, &dx);

	//calculate the minimum distance that can be between two objects
	scalar_t touchingDist = r1 + r2;

	//calculate the 'c' coefficient of the quadratic formula
	scalar_t c = VectorLengthSq(&dx) - touchingDist * touchingDist;

	//	if (c < 0) then the objects are initially sticking and collision is 'true'
	if (c < 0) return CST_STUCK;

	//if (a == 0) then we have no velocity
	//	and if we've made it this far then we have already failed the 'initially stuck objects test'
	//	therefore there cannot be a collision
	if (!a) return CST_FREE;

	//calculate the 'b' coefficient of the quadratic formula
	scalar_t b = VectorDot(v1, &dx) * 2;

	//calculate the inside of the square root of the quadratic
	scalar_t d = b * b - 2 * a * c;

	//if there are no real roots then we have no collision
	if (d < 0) return CST_FREE;	//NO SPHERE COLLISION

	//sqrt'ize it
	d = (scalar_t)sqrt(d);

	//create an array containing our two possible time collisions
	int tc = 0;

	//calculate the first
	col_time[0] = (-b + d) / a;

	//if it lies within our timestep then increment 'tc' and continue onward
	if (col_time[0] >= 0 && col_time[0] <= timestep) tc++;

	//calculate the next
	col_time[tc] = (-b - d) / a;

	//if it lies within our timestep then increment 'tc' and continue onward
	if (col_time[tc] >= 0 && col_time[tc] <= timestep) tc++;

	switch (tc)
	{
	case 2:

		//if there were two collisions then sort them into the correct order - col_time[0] first and col_time[1] next
		if (col_time[1] < col_time[0])
		{
			scalar_t swap = col_time[0];
			col_time[0] = col_time[1];
			col_time[1] = swap;
		}
		//continue on to report a collision

	case 1:
		return CST_COLLIDE;

	case 0:
		//if no timesteps were found (ie 'tc' was never incremented) then we have no collisions
		return CST_FREE;		//FREE
	}

//	Error("Collision_SphereTrace(): This Shouldn't Have Happened");

	return -1;
}
