/*

    File: Vector.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#ifndef MATH3D_VECTOR_H
#define MATH3D_VECTOR_H

//  x    y    z
//v[0] v[1] v[2]

#ifdef M_MATH3D_SCALAR_DOUBLE
typedef double scalar_t;
#else
typedef float scalar_t;
#endif

#ifndef M_PI
#define M_PI            3.14159265358979323846
#endif

typedef struct vector_s {
public:
	union {
		scalar_t v[3];
		struct {
			scalar_t x,y,z;
		};
	};
} vector_t;

void		VectorSet(vector_t *vres, scalar_t x, scalar_t y, scalar_t z);
void		VectorCopy(const vector_t *v, vector_t *vres);


//basic math functions
void		VectorAdd(const vector_t *a, const vector_t *b, vector_t *vres);
void		VectorSub(const vector_t *a, const vector_t *b, vector_t *vres);
scalar_t	VectorDot(const vector_t *a, const vector_t *b);
void		VectorScale(const vector_t *a, const scalar_t s, vector_t *vres);
void		VectorMultAdd(const vector_t *a, const vector_t *b, const scalar_t s, vector_t *vres);
void		VectorScaleElem(const vector_t *a, const vector_t *b, vector_t *vres);
void		VectorCross(const vector_t *a, const vector_t *b, vector_t *vres);
scalar_t	VectorLength(const vector_t *v);
scalar_t	VectorLengthSq(const vector_t *v);
scalar_t	VectorDist(const vector_t *a, const vector_t *b);
scalar_t	VectorDistSq(const vector_t *a, const vector_t *b);
void		VectorUnit(const vector_t *v, vector_t *vres);

//useful mathematic functions		- scalar triple product - (v1 cross v2) dot v3
scalar_t	VectorScalarTripleProduct(const vector_t *v1, const vector_t *v2, const vector_t *v3);

	//calc the normal of the plane based upon the three vectors
	//and store it in the current vector
void		VectorPlaneUnitNormal(const vector_t *v1, const vector_t *v2, const vector_t *v3, vector_t *vres);
void		VectorPlaneNormal(const vector_t *v1, const vector_t *v2, const vector_t *v3, vector_t *vres);
	//linear interpolate from 'start' to 'end' based upon the percentage 'coeff'
void		VectorLerp(const vector_t *start, const vector_t *end, scalar_t coeff, vector_t *vres);

//spherical central differencing (i dont think its working correctly)
void SCDif(
	const vector_t *v1, const vector_t *v2,
	const vector_t *n1, const vector_t *n2,
	const vector_t *vcenter,
	vector_t *vm,		vector_t *nm);

/*
void SCDif(
	const vector_t *v1, const vector_t *v2,
	const vector_t *n1, const vector_t *n2,
	const vector_t *vm, const vector_t *nm,
	vector_t *vres);
*/

	//sphere trace movement.  this really needs to go somewhere else.
#define CST_FREE	0
#define CST_STUCK	1
#define CST_COLLIDE	2

int Collision_SphereTrace(
	scalar_t timestep,
	scalar_t *col_time,
	const vector_t *p1,
	const vector_t *v1,
	scalar_t r1,
	const vector_t *p2,
	scalar_t r2);

inline vector_t operator+(const vector_t &a, const vector_t &b) {
	vector_t c;
	c.x = a.x + b.x;
	c.y = a.y + b.y;
	c.z = a.z + b.z;
	return c;
}

inline vector_t operator+=(vector_t &a, const vector_t &b) {
	a.x += b.x;
	a.y += b.y;
	a.z += b.z;
	return a;
}

inline vector_t operator-(const vector_t &a, const vector_t &b) {
	vector_t c;
	c.x = a.x - b.x;
	c.y = a.y - b.y;
	c.z = a.z - b.z;
	return c;
}

inline vector_t operator-(const vector_t &a) {
	vector_t c;
	c.x = -a.x;
	c.y = -a.y;
	c.z = -a.z;
	return c;
}

inline vector_t operator-=(vector_t &a, const vector_t &b) {
	a.x -= b.x;
	a.y -= b.y;
	a.z -= b.z;
	return a;
}

inline vector_t operator*(const vector_t &a, const vector_t &b) {
	vector_t c;
	c.x = a.y * b.z - a.z * b.y;
	c.y = a.z * b.x - a.x * b.z;
	c.z = a.x * b.y - a.y * b.x;
	return c;
}

inline scalar_t operator%(const vector_t &a, const vector_t &b) {
	return a.x * b.x + a.y * b.y + a.z * b.z;
}

inline vector_t operator*(const vector_t &a, scalar_t b) {
	vector_t ret;
	VectorScale(&a, b, &ret);
	return ret;
}

inline vector_t operator*(scalar_t b, const vector_t &a) {
	vector_t c;
	c.x = a.x * b;
	c.y = a.y * b;
	c.z = a.z * b;
	return c;
}

inline vector_t operator*=(vector_t &a, scalar_t b) {
	a.x *= b;
	a.y *= b;
	a.z *= b;
	return a;
}

inline vector_t vectorSet(scalar_t vx, scalar_t vy, scalar_t vz) {
	vector_t ret;
	ret.x = vx;
	ret.y = vy;
	ret.z = vz;
	return ret;
}

#endif