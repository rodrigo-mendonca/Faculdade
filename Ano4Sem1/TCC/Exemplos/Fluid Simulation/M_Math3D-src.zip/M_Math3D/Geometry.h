/*

    File: Geometry.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#ifndef MATH3D_PLANE_H
#define MATH3D_PLANE_H

#include "vector.h"
#include "quat.h"

typedef struct plane_s {
	union {
		struct {
			vector_t normal;
			scalar_t dist_neg;
		};
		scalar_t eq[4];
	};
} plane_t;

typedef struct line_s {
	vector_t pos;
	vector_t dir;
} line_t;

typedef struct box_s {
	union{
		struct {
			vector_t min,max;
		};
		vector_t vec[2];
	};
} box_t;

//PLANE FUNCTIONS

//copies a source plane to a dest plane
void PlaneCopy(const plane_t *p, plane_t *pres);

//constructs a plane from a point vector and a normal vector
void PlaneConstruct(const vector_t *pos, const vector_t *normal, plane_t *pres);

//directly sets the coefficients of the plane
void PlaneSet(plane_t *p, const scalar_t a, const scalar_t b, const scalar_t c, const scalar_t d);

//creates a plane equation based upon the passed plane
void PlaneCalcEq(const plane_t *plane, double *output);

//scales the position and normal of the plane / renormalizes normal
void PlaneScale(const plane_t *plane, const vector_t *scale, plane_t *pres);

//rotates a plane around the origin by quat 'rotation'
void PlaneRotate(const plane_t *plane, const quat_t *rotation, plane_t *pres);

//translates the plane by an offset of 'offset'
void PlaneTranslate(const plane_t *plane, const vector_t *offset, plane_t *pres);

//returns the point on the plane closest to <0 0 0>
void PlanePoint(const plane_t *p, vector_t *vres);

//returns the distance from the vector v to the plane
scalar_t PlaneVectorDistance(const plane_t *plane, const vector_t *v);

//calculates the point on the plane closest to 'v' and returns the vector value
void PlaneVectorClosestPoint(const plane_t *plane, const vector_t *v, vector_t *vres);

//calculates the position of where a line will intersect this plane
//store the intersection vector in vout
//NO LONGER returns the fraction of the line
void		PlaneLineIntersect(const plane_t *plane, const line_t *line, vector_t *vres);

//calculates the fraction of the line's dir from its position to the intersection of the plane
scalar_t	LineIntersectFraction(const plane_t *plane, const line_t *lin);

//LINE FUNCTIONS

//returns the distance between closest point on the given line and the given vector
scalar_t LineVectorDistance(const line_t *l, const vector_t *v);

//fills the line with the line intersection of the two planes
void		PlaneIntersect(const plane_t *p1, const plane_t *p2, line_t *lres);
//if the two planes do not intersect then the line dir will be equal to zero

//returns the closest point on line0 to line1
void		LineLineClosestPoint(const line_t *line0, const line_t *line1, vector_t *vres);

//returns two scalars containing the parameter of line0 in the x component
//and the parameter of line1 in the y component such that
//|(line0.pos + line0.dir * ClosestPointParamter.x) - (line1.pos + line1.dir * ClosestPointParamter.y)|
//is a minimum.
void		LineLineClosestPointParameter(const line_t *line0, const line_t *line1, scalar_t *param0, scalar_t *param1);

//spherically subdivides two vertex+normals to create a midpoint vertex+normal
void		SphericalSubdiv(const line_t *line0, const line_t *line1, line_t *lres);

//spherically subdivides two vertex+normals to create a midpoint vertex+normal
void		SphericalSubdiv(const line_t *line0, const line_t *line1, const vector_t *center, line_t *lres);

//BOX FUNCTIONS

void		BoxStretch(box_t *box, const vector_t *s_min, const vector_t *s_max);
void		BoxStretch(box_t *box, const box_t *other);
void		BoxStretch(box_t *box, const vector_t *v);

scalar_t	BoxLength(const box_t *box);
void		BoxCenter(const box_t *box, vector_t *vres);
bool		BoxContains(const box_t *box, const vector_t *v);
bool		BoxContains(const box_t *box, const box_t *other);
bool		BoxIntersects(const box_t *box, const box_t *other);

bool		CheckBoxLineIntersect(const box_t *box, const vector_t *src, const vector_t *delta);
bool		CheckBoxLineIntersect(const box_t *box, const line_t *l);
scalar_t	CheckBoxBoxIntersect(const box_t *box, const box_t *other, const vector_t *del, vector_t *vres_collision);

bool		BoxLineIntersect(const box_t *box, const vector_t *src, const vector_t *delta, vector_t *out);

//im sure this one will work.
bool BoxBox_Intersection(
	//this bounds
	const box_t *this_bbox,
	//other bounds
	const box_t *other_bbox,
	//movement
	const vector_t *delta,
	//return
	int *collision_side,
	scalar_t *steptime);

void		BoxCalcVtxs(const box_t *box, vector_t *vtxs);
void		BoxCalcPlanes(const box_t *box, plane_t *p);


#endif