/*

    File: Geometry.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include "geometry.h"

#include <math.h>

// *******************************************************
//	*					PLANE FUNCTIONS					*
// *******************************************************

void PlaneCopy(const plane_t *p, plane_t *pres)
{
	pres->eq[0] = p->eq[0];
	pres->eq[1] = p->eq[1];
	pres->eq[2] = p->eq[2];
	pres->eq[3] = p->eq[3];
}

void PlaneConstruct(const vector_t *pos, const vector_t *normal, plane_t *pres)
{
	pres->eq[0] = normal->x;
	pres->eq[1] = normal->y;
	pres->eq[2] = normal->z;
	pres->eq[3] = -VectorDot(normal, pos);
}

void PlaneSet(plane_t *p, const scalar_t a, const scalar_t b, const scalar_t c, const scalar_t d)
{
	p->eq[0] = a;
	p->eq[1] = b;
	p->eq[2] = c;
	p->eq[3] = d;
}

void PlaneCalcEq(const plane_t *plane, double *output)
{
//	output[0] = plane->normal.x;
//	output[1] = plane->normal.y;
//	output[2] = plane->normal.z;
//	output[3] = -VectorDot(&plane->normal, &plane->pos);

	output[0] = (double)plane->eq[0];
	output[1] = (double)plane->eq[1];
	output[2] = (double)plane->eq[2];
	output[3] = (double)plane->eq[3];
}


void PlaneScale(const plane_t *plane, const vector_t *scale, plane_t *pres) {

#if 0	//i think i did the math wrong
	pres->normal.x = plane->normal.x * scale->x;
	pres->normal.y = plane->normal.y * scale->y;
	pres->normal.z = plane->normal.z * scale->z;
	scalar_t mag = VectorLengthSq(&pres->normal);
	if (mag) {
		mag = (scalar_t)sqrt(mag);
		pres->dist_neg = plane->dist_neg * mag;
		mag = 1.f / mag;
		pres->normal.x *= mag;
		pres->normal.y *= mag;
		pres->normal.z *= mag;
	} else {
		pres->dist_neg = 0;
	}
#else	//i think this math is right
	pres->normal.x = scale->x ? plane->normal.x / scale->x : 0.f;
	pres->normal.y = scale->y ? plane->normal.y / scale->y : 0.f;
	pres->normal.z = scale->z ? plane->normal.z / scale->z : 0.f;
	scalar_t mag = VectorLengthSq(&pres->normal);
	if (mag) {
		mag = (scalar_t)sqrt(mag);
		mag = 1.f / mag;
		pres->dist_neg = plane->dist_neg * mag;
		pres->normal.x *= mag;
		pres->normal.y *= mag;
		pres->normal.z *= mag;
	} else {
		pres->dist_neg = 0;
	}
#endif
}

void PlaneRotate(const plane_t *plane, const quat_t *rotation, plane_t *pres)
{
	QuatRotateVector(&plane->normal, rotation, &pres->normal);
}

void PlaneTranslate(const plane_t *plane, const vector_t *offset, plane_t *pres) {
	pres->normal = plane->normal;
	pres->dist_neg = plane->dist_neg - VectorDot(&pres->normal, offset);
}

void PlanePoint(const plane_t *p, vector_t *vres) {
	vres->x = -p->normal.x * p->dist_neg;
	vres->y = -p->normal.y * p->dist_neg;
	vres->z = -p->normal.z * p->dist_neg;
}

scalar_t PlaneVectorDistance(const plane_t *plane, const vector_t *v)
{
//	vector_t delta;
//	VectorSub(v, &plane->pos, &delta);
//	return VectorDot(&plane->normal, &delta);

//	delta = v + p_normal * p_dist_neg
//	dist = p_normal . delta
//	dist = p_normal . (v + p_normal * p_dist_neg)
//	dist = p_normal . v + p_normal . p_normal * p_dist_neg)
//	dist = p_normal . v + |p_normal|^2 * p_dist_neg
//	dist = p_normal . v + p_dist_neg

	return (VectorDot(&plane->normal, v) + plane->dist_neg);
}

void PlaneVectorClosestPoint(const plane_t *plane, const vector_t *v, vector_t *vres)
{
	vector_t delta;
	VectorScale(&plane->normal, PlaneVectorDistance(plane, v), &delta);
	VectorSub(v, &delta, vres);
}

void PlaneLineIntersect(const plane_t *plane, const line_t *line, vector_t *vres)
{
	vector_t tmp;
	scalar_t fraction = LineIntersectFraction(plane, line);

	VectorScale(&line->dir, fraction, &tmp);
	VectorAdd(&tmp, &line->pos, vres);
}

scalar_t LineIntersectFraction(const plane_t *plane, const line_t *line)
{
	scalar_t src_dist = PlaneVectorDistance(plane, &line->pos);

	vector_t dest;
	VectorAdd(&line->pos, &line->dir, &dest);

	scalar_t dest_dist = PlaneVectorDistance(plane, &dest);
	return src_dist / (src_dist - dest_dist);
}

// *******************************************************
//	*					LINE FUNCTIONS					*
// *******************************************************

scalar_t LineVectorDistance(const line_t *l, const vector_t *v)
{
	vector_t reg;
	VectorSub(v, &l->pos, &reg);
	VectorCross(&reg, &l->dir, &reg);
	return VectorLength(&reg) / VectorLength(&l->dir);
}

void PlanePlaneIntersect(const plane_t *p1, const plane_t *p2, line_t *lres)
{
	vector_t ret_dir;

	//the line dir is the cross of the two normals
	VectorCross(&p1->normal, &p2->normal, &ret_dir);
	//keep 'em unit vectors - just for kicks
	VectorUnit(&ret_dir, &ret_dir);

	//the line pos is any point where the planes intersect
	//to find where a point where the two planes intersect
	//create a line from plane p1's origin to plane p2's origin
	//project the line onto plane p1
	//and trace it to intersect p2

	line_t line_del;

	//store lres->pos
	PlanePoint(p1, &line_del.pos);
	VectorCross(&ret_dir, &p1->normal, &line_del.dir);
//	VectorUnit(&line_del.dir, &line_del.dir);
	PlaneLineIntersect(p2, &line_del, &lres->pos);

	//store lres->dir
	VectorCopy(&ret_dir, &lres->dir);
}

void LineLineClosestPoint(const line_t *line0, const line_t *line1, vector_t *vres)
{
	vector_t normal;
	plane_t p;

	VectorCross(&line0->dir, &line1->dir, &normal);
	VectorCross(&normal, &line0->dir, &normal);

	PlaneConstruct(&line0->pos, &normal, &p);
	PlaneLineIntersect(&p, line1, vres);
}

void LineLineClosestPointParameter(
	const line_t *line0,
	const line_t *line1,
	scalar_t *param0,
	scalar_t *param1)
{
	vector_t del;
	VectorSub(&line0->pos, &line1->pos, &del);

	scalar_t A = VectorDot(&line0->dir, &line0->dir);
	scalar_t B = VectorDot(&line0->dir, &line1->dir);
	scalar_t C = VectorDot(&line1->dir, &line1->dir);
	scalar_t D = VectorDot(&line0->dir, &del);
	scalar_t F = VectorDot(&line1->dir, &del);

	scalar_t denom = A*C - B*B;
	if (!denom)
	{
		*param0 = 0;
		*param1 = 0;
		return;
	}

	*param0 = (B*F - C*D) / denom;
	*param1 = (A*F - B*D) / denom;
}

void SphericalSubdiv(const line_t *line0, const line_t *line1, line_t *lres)
{
	//calc the closest point on line0 to line1 and on line1 to line 0 - and average
	vector_t p0, p1;

	LineLineClosestPoint(line0, line1, &p0);
	LineLineClosestPoint(line1, line0, &p1);
	
	VectorAdd(&p0, &p1, &p0);
	VectorScale(&p0, 0.5f, &p0);

	SphericalSubdiv(line0, line1, &p0, lres);
}

void SphericalSubdiv(const line_t *line0, const line_t *line1, const vector_t *center, line_t *lres)
{
	line_t result;

	//calc offset from the center
	vector_t d0, d1;
	
	VectorSub(&line0->pos, center, &d0);
	VectorSub(&line1->pos, center, &d1);

	VectorAdd(&d0, &d1, &result.dir);
	VectorScale(&result.dir, 0.5f, &result.dir);

	scalar_t halfcosine = (scalar_t)sqrt(1.f + 0.5*(VectorDot(&d0, &d1) / (VectorLength(&d0) * VectorLength(&d1))) );

//	VectorScale(&result.dir, 1.f / halfcosine, &result.pos);
//	VectorAdd(&result.pos, center, &result.pos);
	VectorMultAdd(center, &result.dir, 1.f / halfcosine, &result.pos);

	VectorCopy(&result.pos, &lres->pos);
	VectorCopy(&result.dir, &lres->dir);
}

// *******************************************************
//	*			AXIS-ALIGNED BOX FUNCTIONS				*
// *******************************************************

void BoxStretch(box_t *box, const vector_t *s_min, const vector_t *s_max)
{
	for (int n = 0; n < 3; n++)
	{
		if (s_min->v[n] < box->min.v[n]) box->min.v[n] = s_min->v[n];
		if (s_max->v[n] > box->max.v[n]) box->max.v[n] = s_max->v[n];
	}
}

void BoxStretch(box_t *box, const box_t *other)
{
	BoxStretch(box, &other->min, &other->max);
}

void BoxStretch(box_t *box, const vector_t *v)
{
	BoxStretch(box, v, v);
}


scalar_t BoxLength(const box_t *box)
{
	vector_t del;
	VectorSub(&box->max, &box->min, &del);
	return VectorLength(&del);
}

void BoxCenter(const box_t *box, vector_t *vres)
{
	VectorAdd(&box->max, &box->min, vres);
	VectorScale(vres, 0.5f, vres);
}

bool BoxContains(const box_t *box, const vector_t *v)
{
	return (v->x >= box->min.x &&
			v->x <= box->max.x &&
			v->y >= box->min.y &&
			v->y <= box->max.y &&
			v->z >= box->min.z &&
			v->z <= box->max.z);
}

bool BoxContains(const box_t *box, const box_t *other)
{
	return (other->min.x >= box->min.x &&
			other->max.x <= box->max.x &&
			other->min.y >= box->min.y &&
			other->max.y <= box->max.y &&
			other->min.z >= box->min.z &&
			other->max.z <= box->max.z);
}

bool BoxIntersects(const box_t *box, const box_t *other)
{
	return ((box->min.x < other->max.x) &&
			(box->min.y < other->max.y) &&
			(box->min.z < other->max.z) &&
			(box->max.x > other->min.x) &&
			(box->max.y > other->min.y) &&
			(box->max.z > other->min.z));
}

bool CheckBoxLineIntersect(const box_t *box, const vector_t *src, const vector_t *delta)
{
	vector_t intersect;
	int v, d, di, dii;

	for (v = 0; v < 2; v++)
	{
		for (d = 0; d < 3; d++)
		{
			di = (d + 1) % 3;
			dii = (di + 1) % 3;

			if (delta->v[d])
			{
				scalar_t frac = (scalar_t)(box->vec[v].v[d] - src->v[d]) / (scalar_t)delta->v[d];
				if (frac < 0 || frac > 1) continue;
				VectorScale(delta, frac, &intersect);
				VectorAdd(&intersect, src, &intersect);
			}
			else
			{
				VectorCopy(src, &intersect);
			}

			if (intersect.v[di] >= box->min.v[di] &&
				intersect.v[di] <= box->max.v[di] &&
				intersect.v[dii] >= box->min.v[dii] &&
				intersect.v[dii] <= box->max.v[dii])
					return true;
		}
	}
	return false;
}

bool CheckBoxLineIntersect(const box_t *box, const line_t *l)
{
	return CheckBoxLineIntersect(box, &l->pos, &l->dir);
}


scalar_t CheckBoxBoxIntersect(
	const box_t *box,
	const box_t *other,
	const vector_t *del,
	vector_t *vres_collision)
{
	/*
	vector_t del = main_ent->velocity.v[v];
	for v = all three axii
		if (del.v[v] > 0)
			d = distance from main_ent->maxbbox.max.v[v] to e->maxbbox.min.v[v]
		else if (del.v[v] < 0)
			d = distance from main_ent->maxbbox.min.v[v] to e->maxbbox.max.v[v]
		f = d / del.v[v]		//fraction of movement to intersection
		if (f < 0 || f > 1) continue	//make sure we're not travelling beyond velocity vector
		increment box position by scaled velocity
		check for box intersection crossing on other two dimensions vi, vii
		if intersection found
			set intersection vector to the colliding vertex on your box [vi,vii]
			set movement fraction to 'f'
			scale del by 'f'
	*/

	int dim, di, dii;
	scalar_t dist, frac;
	box_t newcheck;
	int src_id, dest_id;
	vector_t mod_del, del_scale, intersection;
	scalar_t f_di, f_dii;
	scalar_t res_frac = 1.f;

	VectorCopy(del, &mod_del);

	for (dim = 0; dim < 3; dim++)
	{
		if (mod_del.v[dim] == 0) continue;

		for (src_id = 0; src_id < 2; src_id++)
		{
			dest_id = !src_id;
		
/*
if (del.v[dim] > 0)
{
	src_id = 1;
	dest_id = 0;
}
else//if (del.v[dim] < 0) 
{
	src_id = 0;
	dest_id = 1;
}
*/
			dist = (scalar_t)(other->vec[dest_id].v[dim] - box->vec[src_id].v[dim]);
			frac = dist / (scalar_t)mod_del.v[dim];
			if (frac < 0 || frac > 1) continue;		//no intersection found along del line segment

			VectorScale(&mod_del, frac, &del_scale);
			VectorAdd(&box->min, &del_scale, &newcheck.min);
			VectorAdd(&box->max, &del_scale, &newcheck.max);

			di = (dim+1)%3;
			dii = (dim+2)%3;

			//if intersection is found
			if ((newcheck.min.v[di] < other->max.v[di]) &&
				(newcheck.max.v[di] > other->min.v[di]) &&
				(newcheck.min.v[dii] < other->max.v[dii]) &&
				(newcheck.max.v[dii] > other->min.v[dii]))
			{
				//grab the box corner of src
				if (newcheck.min.v[di] > other->min.v[di] && newcheck.min.v[di] < other->max.v[di])
					f_di = newcheck.min.v[di];
				else if (newcheck.max.v[di] > other->min.v[di] && newcheck.max.v[di] < other->max.v[di])
					f_di = newcheck.max.v[di];
				else
					f_di = other->min.v[di];	//any vertex of other - doesnt matter
				
				if (newcheck.min.v[dii] > other->min.v[dii] && newcheck.min.v[dii] < other->max.v[dii])
					f_dii = newcheck.min.v[dii];
				else if (newcheck.max.v[dii] > other->min.v[dii] && newcheck.max.v[dii] < other->max.v[dii])
					f_dii = newcheck.max.v[dii];
				else
					f_dii = other->min.v[dii];

				//corner min.v[di], min.v[dii]
				intersection.v[dim] = newcheck.vec[src_id].v[dim];	//apply this to 
				intersection.v[di] = f_di;
				intersection.v[dii] = f_dii;

				VectorCopy(&del_scale, &mod_del);
				res_frac *= frac;
			}
		}
	}

	if (res_frac < 1.f) VectorCopy(&intersection, vres_collision);

	return res_frac;
}


bool BoxBox_Intersection(
	//this bounds
	const box_t *this_bbox,
	//other bounds
	const box_t *other_bbox,
	//movement
	const vector_t *delta,
	//return
	int *collision_side,
	scalar_t *steptime)
{

	bool collided = false;
	scalar_t del, mid_min, mid_max;

	for (int dim = 0; dim < 3; dim++) {
		if (delta->v[dim]) {
			if (delta->v[dim] > 0)	//test + side of player to - side of map
				del = other_bbox->min.v[dim] - this_bbox->max.v[dim];
			else				//test - side of player to + side of map
				del = other_bbox->max.v[dim] - this_bbox->min.v[dim];

			//divide by player_vx so we get del in range of [0,steptime]
			//whereas dividing by movement_x would be in range [0,1]
			del /= delta->v[dim];
			//if we have valid movement
			if (del > 0 && del < *steptime)
			{
				bool found = true;

				for (int j = 0; j < 2; j++) {
					int d2 = (dim + j + 1) % 3;
					//test and see if, after moving 'del' fraction,
					//if the opposing dimensions align...
					mid_min = this_bbox->min.v[d2] + delta->v[d2] * del;
					mid_max = this_bbox->max.v[d2] + delta->v[d2] * del;

					//test <min,max> to <ymin,ymax>
					if (mid_min > other_bbox->max.v[d2] || mid_max < other_bbox->min.v[d2]) {
						found = false;
						break;
					}
				}

				if (found) {
					//COLLISION!l!@:lk@!#
					*steptime = del;
					*collision_side = dim + (delta->v[dim] > 0) * 3; //returns the side of 'e'

//					main_console->Print("collision\n");
					collided = true;
				}
			}
		}
	}

	return collided;
}


bool BoxLineIntersect(const box_t *box, const vector_t *src, const vector_t *delta, vector_t *out)
{
	vector_t intersect;
	int v, d, di, dii;

	for (v = 0; v < 2; v++)
	{
		for (d = 0; d < 3; d++)
		{
			di = (d + 1) % 3;
			dii = (di + 1) % 3;

			if (delta->v[d])
			{
				scalar_t frac = (scalar_t)(box->vec[v].v[d] - src->v[d]) / (scalar_t)delta->v[d];
				if (frac < 0 || frac > 1) continue;
				VectorScale(delta, frac, &intersect);
				VectorAdd(&intersect, src, &intersect);
			}
			else
			{
				VectorCopy(src, &intersect);
			}

			if (intersect.v[di] >= box->min.v[di] && intersect.v[di] <= box->max.v[di] &&
				intersect.v[dii] >= box->min.v[dii] && intersect.v[dii] <= box->max.v[dii])
			{
				VectorCopy(&intersect, out);
				return true;
			}
		}
	}
	VectorCopy(&intersect, out);
	return false;
}


void BoxCalcVtxs(const box_t *box, vector_t *vtx)
{
	VectorSet(&vtx[0], box->min.x, box->min.y, box->min.z);
	VectorSet(&vtx[1], box->min.x, box->min.y, box->max.z);
	VectorSet(&vtx[2], box->min.x, box->max.y, box->min.z);
	VectorSet(&vtx[3], box->min.x, box->max.y, box->max.z);
	VectorSet(&vtx[4], box->max.x, box->min.y, box->min.z);
	VectorSet(&vtx[5], box->max.x, box->min.y, box->max.z);
	VectorSet(&vtx[6], box->max.x, box->max.y, box->min.z);
	VectorSet(&vtx[7], box->max.x, box->max.y, box->max.z);
}

void BoxCalcPlanes(const box_t *box, plane_t *p)
{
//	VectorCopy(&box->min, &p[0].pos);	VectorSet(&p[0].normal, -1,0,0);
//	VectorCopy(&box->min, &p[1].pos);	VectorSet(&p[1].normal, 0,-1,0);
//	VectorCopy(&box->min, &p[2].pos);	VectorSet(&p[2].normal, 0,0,-1);
//	VectorCopy(&box->min, &p[3].pos);	VectorSet(&p[3].normal, 1,0,0);
//	VectorCopy(&box->min, &p[4].pos);	VectorSet(&p[4].normal, 0,1,0);
//	VectorCopy(&box->min, &p[5].pos);	VectorSet(&p[5].normal, 0,0,1);

	PlaneSet(&p[0], -1,0,0, box->min.x);
	PlaneSet(&p[1], 0,-1,0, box->min.y);
	PlaneSet(&p[2], 0,0,-1, box->min.z);
	PlaneSet(&p[3], 1,0,0, -box->min.x);
	PlaneSet(&p[4], 0,1,0, -box->min.y);
	PlaneSet(&p[5], 0,0,1, -box->min.z);
}