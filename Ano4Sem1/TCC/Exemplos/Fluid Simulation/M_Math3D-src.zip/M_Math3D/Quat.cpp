/*

    File: Quat.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include "quat.h"
#include <math.h>

void QuatSet(quat_t *qres, scalar_t x, scalar_t y, scalar_t z, scalar_t w)
{
	qres->x = x;
	qres->y = y;
	qres->z = z;
	qres->w = w;
}

void QuatCopy(const quat_t *q, quat_t *qres)
{
	qres->x = q->x;
	qres->y = q->y;
	qres->z = q->z;
	qres->w = q->w;
}

void QuatAdd(const quat_t *a, const quat_t *b, quat_t *qres)
{
	qres->x = a->x + b->x;
	qres->y = a->y + b->y;
	qres->z = a->z + b->z;
	qres->w = a->w + b->w;
}

void QuatScale(const quat_t *q, const scalar_t s, quat_t *qres)
{
	qres->x = q->x * s;
	qres->y = q->y * s;
	qres->z = q->z * s;
	qres->w = q->w * s;
}

void QuatMul(const quat_t *q, const quat_t *r, quat_t *qres)
{
	scalar_t a,b,c,d,e,f,g,h;

	a = (q->w + q->x)*(r->w + r->x);
	b = (q->z - q->y)*(r->y - r->z);
	c = (q->x - q->w)*(r->y + r->z);
	d = (q->y + q->z)*(r->x - r->w);
	e = (q->x + q->z)*(r->x + r->y);
	f = (q->x - q->z)*(r->x - r->y);
	g = (q->w + q->y)*(r->w - r->z);
	h = (q->w - q->y)*(r->w + r->z);

	qres->x = a - ((scalar_t)0.5)*( e + f + g + h);
	qres->y = -c + ((scalar_t)0.5)*( e - f + g - h);
	qres->z = -d + ((scalar_t)0.5)*( e - f - g + h);
	qres->w = b + ((scalar_t)0.5)*(-e - f + g + h);
}

scalar_t QuatDot(const quat_t *a, const quat_t *b)
{
	return (a->x * b->x + a->y * b->y + a->z * b->z + a->w * b->w);
}

scalar_t QuatNormal(const quat_t *q)
{
	return QuatDot(q,q);
}

scalar_t QuatLength(const quat_t *q)
{
	return (scalar_t)sqrt(QuatNormal(q));
}

void QuatUnit(const quat_t *q, quat_t *qres)
{
	scalar_t length = QuatLength(q);
	if (length) QuatScale(q, 1.f / length, qres);
}

	//quaternion conversion functions
void QuatToAngleAxis(const quat_t *q, quat_t *qres)
{
	scalar_t cosom = q->w;
	if (cosom < -1) cosom = -1;
	if (cosom > 1) cosom = 1;

	scalar_t halfangle = (scalar_t)acos(cosom);
	scalar_t scale = (scalar_t)sin(halfangle);

	if (!scale)
	{
		qres->x = 0;
		qres->y = 0;
		qres->z = 1;
		qres->w = 0;
	}
	else
	{
		scale = (scalar_t)1.f / scale;
		qres->x = q->x * scale;
		qres->y = q->y * scale;
		qres->z = q->z * scale;
		qres->w = halfangle * 360.f / (scalar_t)M_PI;
	}
}

void AngleAxisToQuat(const quat_t *q, quat_t *qres)
{
	scalar_t halfangle = q->w * (scalar_t )M_PI / 360.0f;
	scalar_t scale = (scalar_t)sin(halfangle);

	qres->x = q->x * scale;
	qres->y = q->y * scale;
	qres->z = q->z * scale;
	qres->w = (scalar_t)cos(halfangle);
}

void AngleAxisToQuat(const scalar_t x, const scalar_t y, const scalar_t z, const scalar_t w, quat_t *qres)
{
	scalar_t halfangle = w * (scalar_t )M_PI / 360.0f;
	scalar_t scale = (scalar_t)sin(halfangle);

	qres->x = x * scale;
	qres->y = y * scale;
	qres->z = z * scale;
	qres->w = (scalar_t)cos(halfangle);
}

void QuatVectorDifference(
	const vector_t *src,
	const vector_t *dst,
	const scalar_t angleScale,
	quat_t *qres)
{
	vector_t axis;

	VectorCross(src, dst, &axis);
	scalar_t cosom = VectorDot(src, dst);

	if (cosom < -1) cosom = -1;
	if (cosom > 1) cosom = 1;

	scalar_t halfangle = (scalar_t)acos(cosom) * 0.5f * angleScale;
	scalar_t sinom = (scalar_t)sin(halfangle);

	VectorUnit(&axis, &axis);

	VectorScale(&axis, sinom, &qres->vec);
	qres->w = (scalar_t)cos(halfangle);
}

void QuatConj(const quat_t *q, quat_t *qres)
{
	qres->x = -q->x;
	qres->y = -q->y;
	qres->z = -q->z;
	qres->w = q->w;
}

void QuatLerp(const quat_t *from, const quat_t *to, const scalar_t s, quat_t *qres)
{
	scalar_t one_minus_s = 1.f - s;
	qres->x = from->x * one_minus_s + to->x * s;
	qres->y = from->y * one_minus_s + to->y * s;
	qres->z = from->z * one_minus_s + to->z * s;
	qres->w = from->w * one_minus_s + to->w * s;
}

void QuatLerp(const quat_t *from, const quat_t *to, const scalar_t from_s, const scalar_t to_s, quat_t *qres)
{
	qres->x = from->x * from_s + to->x * to_s;
	qres->y = from->y * from_s + to->y * to_s;
	qres->z = from->z * from_s + to->z * to_s;
	qres->w = from->w * from_s + to->w * to_s;
}

void QuatSlerp(const quat_t *from, const quat_t *to, const scalar_t t, quat_t *qres)
{
	double omega, cosom, sinom, scale0, scale1;
	quat_t to1;

	cosom = QuatDot(from, to);

	if (cosom < 0.0)
	{
		cosom = -cosom;
		to1.x = -to->x;
		to1.y = -to->y;
		to1.z = -to->z;
		to1.w = -to->w;
	}
	else
	{
		to1.x = to->x;
		to1.y = to->y;
		to1.z = to->z;
		to1.w = to->w;
	}

	//therefore cosom always ranges from 0 to 1, and omega always ranges from -180 to 180 degrees

	if (cosom < 0.99999)	//SLERPing
	{
		omega = acos(cosom);
		sinom = sin(omega);
		scale0 = sin((1.0 - t) * omega) / sinom;
		scale1 = sin(t * omega) / sinom;
	}
	else					//LERPing
	{
		scale0 = 1.0 - t;
		scale1 = t;
	}

	QuatLerp(from, &to1, (scalar_t)scale0, (scalar_t)scale1, qres);
}

void QuatRotateVector(const vector_t *v, const quat_t *q, vector_t *vres)
{
/*
	quat_t product, pure_v, conj_q;

	QuatSet(&pure_v, v->x, v->y, v->z, 0);
	QuatConj(q, &conj_q);

	QuatMul(q, &pure_v, &product);
	QuatMul(&product, &conj_q, &product);

	vres->x = product.x;
	vres->y = product.y;
	vres->z = product.z;
*/
//a' = a(w^2 + x^2 + y^2 + z^2)
//b' = b((w^2 - y^2) + (x^2 - z^2)) + 2(c(xy - wz) + d(xz + wy))
//c' = c((w^2 - x^2) + (y^2 - z^2)) + 2(d(yz - wx) + b(xy + wz))
//d' = d((w^2 - y^2) - (x^2 - z^2)) + 2(b(xz - wy) + c(yz + wx))

//a' = a(w^2 + x^2 + y^2 + z^2)
//b' = b(w2y2 + x2z2) + 2(c(xy - wz) + d(xz + wy))
//c' = c(w2x2 + y2z2) + 2(d(yz - wx) + b(xy + wz))
//d' = d(w2y2 - x2z2) + 2(b(xz - wy) + c(yz + wx))

	scalar_t w2x2 = (q->w + q->x) * (q->w - q->x);
	scalar_t w2y2 = (q->w + q->y) * (q->w - q->y);
	scalar_t x2z2 = (q->x + q->z) * (q->x - q->z);
	scalar_t y2z2 = (q->y + q->z) * (q->y - q->z);



	scalar_t  res_x = v->x * (w2y2 + x2z2) + 2.f*(v->y * (q->x * q->y - q->w * q->z) + v->z * (q->x * q->z + q->w * q->y));
	scalar_t  res_y = v->y * (w2x2 + y2z2) + 2.f*(v->z * (q->y * q->z - q->w * q->x) + v->x * (q->x * q->y + q->w * q->z));
			vres->z = v->z * (w2y2 - x2z2) + 2.f*(v->x * (q->x * q->z - q->w * q->y) + v->y * (q->y * q->z + q->w * q->x));
			vres->y = res_y;
			vres->x = res_x;
}

void QuatProjectXAxis(const quat_t *q, vector_t *vres)
{
	scalar_t x = (scalar_t)1.0 - (scalar_t)2.0 * (q->y * q->y + q->z * q->z);
	scalar_t y = (scalar_t)2.0 * (q->x * q->y + q->z * q->w);
	scalar_t z = (scalar_t)2.0 * (q->x * q->z - q->w * q->y);

	vres->x = x;
	vres->y = y;
	vres->z = z;
}

void QuatProjectYAxis(const quat_t *q, vector_t *vres)
{
	scalar_t x = (scalar_t)2.0 * (q->x * q->y - q->w * q->z);
	scalar_t y = (scalar_t)1.0 - (scalar_t)2.0 * (q->x * q->x + q->z * q->z);
	scalar_t z = (scalar_t)2.0 * (q->y * q->z + q->w * q->x);

	vres->x = x;
	vres->y = y;
	vres->z = z;
}

void QuatProjectZAxis(const quat_t *q, vector_t *vres)
{
	scalar_t x = (scalar_t)2.0 * (q->x * q->z + q->w * q->y);
	scalar_t y = (scalar_t)2.0 * (q->y * q->z - q->w * q->x);
	scalar_t z = (scalar_t)1.0 - (scalar_t)2.0 * (q->x * q->x + q->y * q->y);

	vres->x = x;
	vres->y = y;
	vres->z = z;
}

void QuatIntegrate(const quat_t *angle, const vector_t *axis, const scalar_t dt, quat_t *qres)
{
	quat_t reg;
	//qres = angle + (Quat(axis) * angle) * 0.5f * time;
	VectorCopy(axis, &reg.vec);
	reg.w = 0;
	QuatMul(&reg, angle, &reg);
	QuatScale(&reg, 0.5f * dt, &reg);
	QuatAdd(angle, &reg, qres);
	//qres.Normalize();
	QuatUnit(qres, qres);
}

quat_t quatExp(const vector_t &a) {
	quat_t qres;
	scalar_t length = VectorLength(&a);
	if (length > 0) {
		VectorScale(&a, (scalar_t)sin(length) / length, &qres.vec);
		qres.w = (scalar_t)cos(length);
	} else {
		QuatSet(&qres, 0, 0, 0, 1);
	}
	return qres;
}

vector_t quatLog(const quat_t &a) {
	vector_t vres;
	scalar_t length = VectorLength(&a.vec);
	scalar_t theta = (scalar_t)atan(length / a.w);
	VectorScale(&a.vec, theta / length, &vres);
	return vres;
}

/*
Quat::Quat()
{
	x = y = z = 0;
	w = 1;
}

Quat::Quat(const Scalar vx, const Scalar vy, const Scalar vz, const Scalar vw)
{
	x = vx; y = vy; z = vz; w = vw;
}

Quat::Quat(const Vector &v)	//constructs it from a vector with w=0
{
	x = v.x; y = v.y; z = v.z; w = 0;
}

Quat::Quat(const Vector &v, const Scalar vw)
{
	x = v.x; y = v.y; z = v.z; w = vw;
}


void Quat::operator+=(const Quat &r)
{
	x += r.x;
	y += r.y;
	z += r.z;
	w += r.w;
}

void Quat::operator*=(const Scalar s)
{
	x *= s; 
	y *= s; 
	z *= s; 
	w *= s;
}

void Quat::operator*=(const Quat &r)
{
	Scalar a,b,c,d,e,f,g,h;

	a = (w + x)*(r.w + r.x);
	b = (z - y)*(r.y - r.z);
	c = (x - w)*(r.y + r.z);
	d = (y + z)*(r.x - r.w);
	e = (x + z)*(r.x + r.y);
	f = (x - z)*(r.x - r.y);
	g = (w + y)*(r.w - r.z);
	h = (w - y)*(r.w + r.z);

	x =  a - ((Scalar)0.5)*( e + f + g + h);
	y = -c + ((Scalar)0.5)*( e - f + g - h);
	z = -d + ((Scalar)0.5)*( e - f - g + h);
	w =  b + ((Scalar)0.5)*(-e - f + g + h);
}

void Quat::operator/=(const Scalar s)
{
	x /= s;
	y /= s;
	z /= s;
	w /= s;
}

Quat operator*(const Quat &q, const Scalar s)
{
	return Quat(q.x * s, q.y * s, q.z * s, q.w * s);
}

Quat operator*(const Quat &q, const Quat &r)
{
	Scalar a,b,c,d,e,f,g,h;

	a = (q.w + q.x)*(r.w + r.x);
	b = (q.z - q.y)*(r.y - r.z);
	c = (q.x - q.w)*(r.y + r.z);
	d = (q.y + q.z)*(r.x - r.w);
	e = (q.x + q.z)*(r.x + r.y);
	f = (q.x - q.z)*(r.x - r.y);
	g = (q.w + q.y)*(r.w - r.z);
	h = (q.w - q.y)*(r.w + r.z);

	return Quat( a - ((Scalar)0.5)*( e + f + g + h),
				-c + ((Scalar)0.5)*( e - f + g - h),
				-d + ((Scalar)0.5)*( e - f - g + h),
				 b + ((Scalar)0.5)*(-e - f + g + h));
}

Quat operator/(const Quat &q, const Scalar s)
{
	return Quat(q.x / s, q.y / s, q.z / s, q.w / s);
}

Quat operator+(const Quat &q, const Quat &r)
{
	return Quat(q.x + r.x, q.y + r.y, q.z + r.z, q.w + r.w);
}

Quat operator-(const Quat &q)
{
	return Quat(-q.x, -q.y, -q.z, -q.w);
}

Scalar operator%(const Quat &q, const Quat &r)
{
	return (q.w*r.w + q.x*r.x + q.y*r.y + q.z*r.z);
}


Vector RotateVector(const Vector &v, const Quat &q)
{
	Quat product = (q * Quat(v)) * Conjugate(q);
	return *(product.AxisVector());
}

QuatToMatrix code:
	v[0][0] = (Scalar)1.0 - (Scalar)2.0 * (q.y * q.y + q.z * q.z);
	v[0][1] = (Scalar)2.0 * (q.x * q.y + q.z * q.w);
	v[0][2] = (Scalar)2.0 * (q.x * q.z - q.w * q.y);

	v[1][0] = (Scalar)2.0 * (q.x * q.y - q.w * q.z);
	v[1][1] = (Scalar)1.0 - (Scalar)2.0 * (q.x * q.x + q.z * q.z);
	v[1][2] = (Scalar)2.0 * (q.y * q.z + q.w * q.x);

	v[2][0] = (Scalar)2.0 * (q.x * q.z + q.w * q.y);
	v[2][1] = (Scalar)2.0 * (q.y * q.z - q.w * q.x);
	v[2][2] = (Scalar)1.0 - (Scalar)2.0 * (q.x * q.x + q.y * q.y);
*/
