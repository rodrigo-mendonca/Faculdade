/*

    File: Quat.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#ifndef MATH3D_QUAT_H
#define MATH3D_QUAT_H

//{[x,   y,   z],  w}
//v[0],v[1],v[2],v[3]

#include "vector.h"

typedef struct quat_s {
	union {
		scalar_t v[4];
		struct {
			union {
				vector_t vec;
				struct {
					scalar_t x,y,z,w;
				};
			};
		};
	};
} quat_t;

void		QuatSet(quat_t *qres, scalar_t x, scalar_t y, scalar_t z, scalar_t w);
void		QuatCopy(const quat_t *q, quat_t *qres);

	//basic math functions
void		QuatAdd(const quat_t *a, const quat_t *b, quat_t *qres);
void		QuatScale(const quat_t *q, const scalar_t s, quat_t *qres);
void		QuatMul(const quat_t *a, const quat_t *b, quat_t *qres);
scalar_t	QuatDot(const quat_t *a, const quat_t *b);

	//length functions
scalar_t	QuatNormal(const quat_t *q);
scalar_t	QuatLength(const quat_t *q);
void		QuatUnit(const quat_t *q, quat_t *qres);

void		QuatToAngleAxis(const quat_t *q, quat_t *qres);
void		AngleAxisToQuat(const scalar_t x, const scalar_t y, const scalar_t z, const scalar_t w, quat_t *qres);
void		AngleAxisToQuat(const quat_t *q, quat_t *qres);
void		QuatVectorDifference(const vector_t *src, const vector_t *dst, const scalar_t angleScale, quat_t *qres);

void		QuatConj(const quat_t *q, quat_t *qres);
void		QuatLerp(const quat_t *from, const quat_t *to, const scalar_t s, quat_t *qres);
void		QuatLerp(const quat_t *from, const quat_t *to, const scalar_t from_s, const scalar_t to_s, quat_t *qres);
void		QuatSlerp(const quat_t *from, const quat_t *to, const scalar_t t, quat_t *qres);

void		QuatRotateVector(const vector_t *v, const quat_t *q, vector_t *vres);

void		QuatProjectXAxis(const quat_t *q, vector_t *vres);
void		QuatProjectYAxis(const quat_t *q, vector_t *vres);
void		QuatProjectZAxis(const quat_t *q, vector_t *vres);

void		QuatIntegrate(const quat_t *src, const vector_t *axis, const scalar_t dt, quat_t *qres);

inline quat_t quatSet(scalar_t x, scalar_t y, scalar_t z, scalar_t w) {
	quat_t q;
	QuatSet(&q, x,y,z,w);
	return q;
}

inline quat_t angleAxisToQuat(scalar_t x, scalar_t y, scalar_t z, scalar_t w) {
	quat_t q;
	AngleAxisToQuat(x,y,z,w,&q);
	return q;
}


inline quat_t operator*(const quat_t &a, const quat_t &b) {
	quat_t qres;
	QuatMul(&a, &b, &qres);
	return qres;
}

inline quat_t operator*(const quat_t &a, scalar_t b) {
	quat_t q;
	q.x = a.x * b;
	q.y = a.y * b;
	q.z = a.z * b;
	q.w = a.w * b;
	return q;
}

inline quat_t operator/(const quat_t &a, scalar_t b) {
	quat_t q;
	b = 1.f / b;
	q.x = a.x * b;
	q.y = a.y * b;
	q.z = a.z * b;
	q.w = a.w * b;
	return q;
}

inline quat_t quatConj(const quat_t &a) {
	quat_t qres;
	QuatConj(&a, &qres);
	return qres;
}

quat_t quatExp(const vector_t &a);

vector_t quatLog(const quat_t &a);

inline quat_t quatUnit(const quat_t &a) {
	scalar_t len = QuatLength(&a);
	return len ? a / len : a;
}

#endif