/*

    File: Matrix.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include "matrix.h"

/*
Matrix IdentityMatrix(Vector(1,0,0), Vector(0,1,0), Vector(0,0,1));
Matrix ZeroMatrix(Vector(0,0,0), Vector(0,0,0), Vector(0,0,0));

Matrix::Matrix()
{
	v[0][0] = v[1][0] = v[2][0] = 0;
	v[0][1] = v[1][1] = v[2][1] = 0;
	v[0][2] = v[1][2] = v[2][2] = 0;
}

Matrix::Matrix(const Vector &x, const Vector &y, const Vector &z)
{
	v[0][0] = x.x;	v[1][0] = y.x;	v[2][0] = z.x;
	v[0][1] = x.y;	v[1][1] = y.y;	v[2][1] = z.y;
	v[0][2] = x.z;	v[1][2] = y.z;	v[2][2] = z.z;
}

Matrix::Matrix(const Quat &q)
{
	//OPTOMIZE ME!!

	v[0][0] = (Scalar)1.0 - (Scalar)2.0 * (q.y * q.y + q.z * q.z);
	v[0][1] = (Scalar)2.0 * (q.x * q.y + q.z * q.w);
	v[0][2] = (Scalar)2.0 * (q.x * q.z - q.w * q.y);

	v[1][0] = (Scalar)2.0 * (q.x * q.y - q.w * q.z);
	v[1][1] = (Scalar)1.0 - (Scalar)2.0 * (q.x * q.x + q.z * q.z);
	v[1][2] = (Scalar)2.0 * (q.y * q.z + q.w * q.x);

	v[2][0] = (Scalar)2.0 * (q.x * q.z + q.w * q.y);
	v[2][1] = (Scalar)2.0 * (q.y * q.z - q.w * q.x);
	v[2][2] = (Scalar)1.0 - (Scalar)2.0 * (q.x * q.x + q.y * q.y);

}

Matrix::Matrix(	const Scalar xx, const Scalar yx, const Scalar zx,
				const Scalar xy, const Scalar yy, const Scalar zy,
				const Scalar xz, const Scalar yz, const Scalar zz)
{
	v[0][0] = xx;	v[1][0] = yx;	v[2][0] = zx;
	v[0][1] = xy;	v[1][1] = yy;	v[2][1] = zy;
	v[0][2] = xz;	v[1][2] = yz;	v[2][2] = zz;
}

//conversion
Vector *Matrix::XAxis(void) {return (Vector *)(&v[0][0]);}
Vector *Matrix::YAxis(void) {return (Vector *)(&v[1][0]);}
Vector *Matrix::ZAxis(void) {return (Vector *)(&v[2][0]);}

void Matrix::operator+=(const Matrix &a)
{
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			v[i][j] += a.v[i][j];
}

void Matrix::operator*=(const Scalar s)
{
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			v[i][j] *= s;
}

//check
Vector operator*(const Matrix &a, const Vector &b)
{
	return Vector (	a.v[0][0]*b.x + a.v[1][0]*b.y + a.v[2][0]*b.z,
					a.v[0][1]*b.x + a.v[1][1]*b.y + a.v[2][1]*b.z,
					a.v[0][2]*b.x + a.v[1][2]*b.y + a.v[2][2]*b.z);
}

Matrix operator*(const Matrix &a, const Matrix &b)
{
	static Matrix r;
	Scalar v;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			v = 0;
			for (int k = 0; k < 3; k++)
			{
				v += a.v[k][i] * b.v[j][k];
			}
			r.v[j][i] = v;
		}
	}
	return r;
}

Matrix operator*(const Matrix &a, const Scalar &b)
{
	static Matrix r;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			r.v[i][j] = a.v[i][j] * b;
	return r;
}

Matrix operator/(const Matrix &a, const Scalar &b)
{
	static Matrix r;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			r.v[i][j] = a.v[i][j] / b;
	return r;
}
*/

void MatrixSet(matrix_t *mres,
	const scalar_t xx, const scalar_t yx, const scalar_t zx,
	const scalar_t xy, const scalar_t yy, const scalar_t zy,
	const scalar_t xz, const scalar_t yz, const scalar_t zz)
{
	mres->v[0][0] = xx;	mres->v[1][0] = yx;	mres->v[2][0] = zx;
	mres->v[0][1] = xy;	mres->v[1][1] = yy;	mres->v[2][1] = zy;
	mres->v[0][2] = xz;	mres->v[1][2] = yz;	mres->v[2][2] = zz;
}

#include <string.h>
void MatrixCopy(const matrix_t *src, matrix_t *mres)
{
	memcpy(mres, src, sizeof(matrix_t));
}

void MatrixAdd(const matrix_t *m, const matrix_t *n, matrix_t *mres)
{
	int i,j;
	for (i = 0; i < 3; i++) 
		for (j = 0; j < 3; j++)
			mres->v[i][j] = m->v[i][j] + n->v[i][j];
}

void MatrixSub(const matrix_t *m, const matrix_t *n, matrix_t *mres)
{
	int i,j;
	for (i = 0; i < 3; i++) 
		for (j = 0; j < 3; j++)
			mres->v[i][j] = m->v[i][j] - n->v[i][j];
}

void MatrixMul(const matrix_t *m, const vector_t *v, vector_t *vres)
{
	scalar_t x =	m->v[0][0]*v->x + m->v[1][0]*v->y + m->v[2][0]*v->z;
	scalar_t y =	m->v[0][1]*v->x + m->v[1][1]*v->y + m->v[2][1]*v->z;
	vres->z =		m->v[0][2]*v->x + m->v[1][2]*v->y + m->v[2][2]*v->z;
	vres->y = y;
	vres->x = x;
}

void MatrixMul(const matrix_t *a, const matrix_t *b, matrix_t *mres)
{
	matrix_t r;
	scalar_t v;

	//cik = aij * bjk

	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			v = 0;
			for (int k = 0; k < 3; k++)
			{
				v += a->v[k][i] * b->v[j][k];
			}
			r.v[j][i] = v;
		}
	}

	MatrixCopy(&r, mres);
}

void MatrixMul(const matrix_t *m, scalar_t s, matrix_t *mres)
{
	int i,j;
	for (i = 0; i < 3; i++)
		for (j = 0; j < 3; j++)
			mres->v[i][j] = m->v[i][j] * s;
}

void MatrixTMul(const matrix_t *m, const vector_t *v, vector_t *vres)
{
	scalar_t x =	m->v[0][0]*v->x + m->v[0][1]*v->y + m->v[0][2]*v->z;
	scalar_t y =	m->v[1][0]*v->x + m->v[1][1]*v->y + m->v[1][2]*v->z;
	vres->z =		m->v[2][0]*v->x + m->v[2][1]*v->y + m->v[2][2]*v->z;
	vres->y = y;
	vres->x = x;
}

void QuatToMatrix(const quat_t *q, matrix_t *mres)
{
	mres->v[0][0] = (scalar_t)1.0 - (scalar_t)2.0 * (q->y * q->y + q->z * q->z);
	mres->v[0][1] = (scalar_t)2.0 * (q->x * q->y + q->z * q->w);
	mres->v[0][2] = (scalar_t)2.0 * (q->x * q->z - q->w * q->y);

	mres->v[1][0] = (scalar_t)2.0 * (q->x * q->y - q->w * q->z);
	mres->v[1][1] = (scalar_t)1.0 - (scalar_t)2.0 * (q->x * q->x + q->z * q->z);
	mres->v[1][2] = (scalar_t)2.0 * (q->y * q->z + q->w * q->x);

	mres->v[2][0] = (scalar_t)2.0 * (q->x * q->z + q->w * q->y);
	mres->v[2][1] = (scalar_t)2.0 * (q->y * q->z - q->w * q->x);
	mres->v[2][2] = (scalar_t)1.0 - (scalar_t)2.0 * (q->x * q->x + q->y * q->y);
}

//also known as the skew-symmetric matrix
void MatrixStar(const vector_t *v, matrix_t *mres)
{
	MatrixSet(mres,
		0,		-v->z,	v->y,
		v->z,	0,		-v->x,
		-v->y,	v->x,	0);
}

void MatrixTranspose(const matrix_t *a, matrix_t *mres)
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j <= i; j++)
		{
			if (j == i)
			{
				mres->v[i][j] = a->v[i][j];
			}
			else
			{
				scalar_t swap = a->v[i][j];
				mres->v[i][j] = a->v[j][i];
				mres->v[j][i] = swap;
			}
		}
	}
}

//what is this for anyways?
void MatrixAdjoint(const matrix_t *a, matrix_t *mres)
{
	matrix_t r;
	for (int i = 0; i < 3; i++)
	{
		int i2 = (i + 1) % 3;
		for (int j = 0; j < 3; j++)
		{
			int j2 = (j + 1) % 3;
			r.v[i][j] = a->v[i][j] * a->v[i2][j2] - a->v[i][j2] * a->v[i2][j];
		}
	}

	MatrixCopy(&r, mres);
}

scalar_t MatrixDeterminant(const matrix_t *a)
{
	return (a->v[0][0] * (a->v[1][1] * a->v[2][2] - a->v[2][1] * a->v[1][2]) +
			a->v[1][0] * (a->v[2][1] * a->v[0][2] - a->v[0][1] * a->v[2][2]) +
			a->v[2][0] * (a->v[0][1] * a->v[1][2] - a->v[1][1] * a->v[0][2]));
}

void MatrixInverse(const matrix_t *a, matrix_t *mres)
{
	/*
		//original method
	Scalar det = Determinant(a);
	if (det == 0) return Matrix(a);			//error - matrix has a determinant of zero
	return AdjointMatrix(a) / det;
	*/
	
		//new method
		//do det on our own so we have access to the intermediate calc'd vars

	scalar_t a00 = a->v[1][1] * a->v[2][2] - a->v[1][2] * a->v[2][1];
	scalar_t a10 = a->v[2][1] * a->v[0][2] - a->v[2][2] * a->v[0][1];
	scalar_t a20 = a->v[0][1] * a->v[1][2] - a->v[0][2] * a->v[1][1];
	scalar_t det = a->v[0][0] * a00 + a->v[1][0] * a10 + a->v[2][0] * a20;
	if (!det)
	{
		MatrixCopy(a, mres);
		return;
	}

	matrix_t r;

	r.v[0][0] = a00 / det;
	r.v[1][0] = a10 / det;
	r.v[2][0] = a20 / det;
	for (int i = 0; i < 3; i++)
	{
		int i2 = (i + 1) % 3;
		for (int j = 1; j < 3; j++)
		{
			int j2 = (j + 1) % 3;
			r.v[i][j] = a->v[i][j] * a->v[i2][j2] - a->v[i][j2] * a->v[i2][j];
		}
	}

	MatrixCopy(&r, mres);
}

void MatrixScale(const vector_t *a, matrix_t *mres)
{
	MatrixSet(mres,
		a->x,	0,		0,
		0,		a->y,	0,
		0,		0,		a->z);
}

#include <math.h>

void MatrixRotation(scalar_t theta, scalar_t x, scalar_t y, scalar_t z, matrix_t *mres)
{
	scalar_t c = (scalar_t)cos(theta);
	scalar_t s = (scalar_t)sin(theta);
	scalar_t t = 1.f - c;

	//check this
	MatrixSet(mres,
		t*x*x + c,		t*y*x + s*z,	t*z*x - s*y,
		t*x*y - s*z,	t*y*y + c,		t*z*y + s*x,
		t*x*z + s*y,	t*y*z - s*x,	t*z*z + c);
}

bool MatrixSolveCramer(const matrix_t *a, const vector_t *b, vector_t *res)
{
	vector_t x;
	scalar_t det = MatrixDeterminant(a);

	//det(A) = det(A^T), therefore the scalar triple product of A = det(A)
	// = det(A^T) = the scalar triple product of A^T

	if (!det) return false;

	x.x = VectorScalarTripleProduct(b, &a->vec[1], &a->vec[2]) / det;
	x.y = VectorScalarTripleProduct(&a->vec[0], b, &a->vec[2]) / det;
	x.z = VectorScalarTripleProduct(&a->vec[0], &a->vec[1], b) / det;

	memcpy(res, &x, sizeof(vector_t));

	return true;
}

#if 0
bool MatrixSolveHouseholder(const matrix_t *a, const vector_t *b, vector_t *res)
{
	//k = 0
	//x = [a->v[0][0]]
	//	  [a->v[0][1]]
	//    [a->v[0][2]]
	scalar_t x[3];
	scalar_t lenx = 0;
	for (int i = 0; i < 3; i++) {
		x[i] = a->v[0][i];
		lenx += x[i] * x[i];
	}
	lenx = sqrt(lenx);
	//							[1]
	//v = sign(x[0]) * len(x) * [0] + x
	//							[0]
	scalar_t signx0 = x[0] < 0 ? -1 : 1;
	scalar_t v[3];
	v[0] = signx0 * lenx + x[0];
	scalar_t lenv = v[0] * v[0];
	for (i = 1; i < 3; i++) {
		v[i] = x[i];
		lenv += v[i] * v[i];
	}
	lenv = sqrt(lenv);
	//v = v / len(v)
	for (i = 0; i < 3; i++) {
		v[i] /= lenv;
	}

	//calc -2v*star(v)*A
	scalar_t mat[3][3];	/*col,row*/
	for (i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			mat[i][j] = 0;
			for (int k = 0; k < 3; k++) {
				mat[i][j] += -2.f * (v[k] * v[i]) * a->v[j][k]
			}
		}
	}

	//add to A
	for (i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			a->v[i][j] += mat[i][j];
		}
	}


	//k = 1
	//x = [a->v[1][1]]
	//	  [a->v[1][2]]
	lenx = 0;
	for (i = 0; i < 2; i++) {
		x[i] = a->v[1][1+i];
		lenx += x[i] * x[i];
	}
	lenx = sqrt(lenx);
	//v = sign(x[0]) * len(x) * [1] + x
	//							[0]
	signx0 = x[0] < 0 ? -1 : 1;
	v[0] = signx0 * lenx + x[0];
	lenv = v[0] * v[0];
	v[1] = x[1]; lenv += v[1] * v[1];
	lenv = sqrt(lenv);
	//v = v / len(v)
	v[0] /= lenv;
	v[1] /= lenv;

	//calc -2v*star(v)*A
	for (i = 0; i < 2; i++) {
		for (int j = 0; j < 2; j++) {
			mat[i][j] = 0;
			for (int k = 0; k < 2; k++) {
				mat[i][j] += -2.f * (v[k] * v[i]) * a->v[j+1][k+1]
			}
		}
	}

	//add to A
	for (i = 0; i < 2; i++) {
		for (int j = 0; j < 2; j++) {
			a->v[i+1][j+1] += mat[i][j];
		}
	}

	//k = 2
	//x = [a->v[2][2]]
	x[0] = a->v[2][2];
	lenx = x[0] < 0 ? -x[0] : x[0];
	//v = sign(x[0]) * len(x) * [1] + x
	signx0 = x[0] < 0 ? -1 : 1;
	v[0] = signx0 * lenx + x[0];
	lenv = v[0] < 0 ? -v[0] : v[0];
	//v = v / len(v)
	v[0] /= lenv;

	//calc -2v*star(v)*A
	mat[0][0] += -2.f * v[0] * v[0] * a->v[2][2]

	//add to A
	a->v[2][2] += mat[0][0];
}
#endif

bool MatrixSolveQP(matrix_t a, vector_t b, vector_t *x) {
	int i,j,k;
	//Ax = b
	//if there is no solution for b then find a b' within colspace(A) and solve for x
	//b' = proj_w(b)
	//Ax = b
	//AtAx = Atb
	//x = (At*A)-1*At*b

	//first print ax=b:

	//row reduce...
	const int width = 3;
	const int height = 3;

	//scan down the diagonal... (its a square matrix =)
	for (i = 0; i < width; i++) {

		//first set a[i,i] to 1
		//do so by scaling the i'th row
		scalar_t s = a.v[i][i];
		if (s == 0) {
			//swapping needed
			return false;
		} else {
			//scale the row - set a '1' in the diagonal
			s = (scalar_t)1.0 / s;
			//since were making an upper diagonal matrix, just start at 'i' (all else will be zeros)
			for (k = i; k < width; k++) {
				a.v[k][i] *= s;
			}
			//and dont forget to manip the 'b'
			b.v[i] *= s;
		}

		//now cycle down the height below i and zero all columns
		for (j = i+1; j < height; j++) {
			//row j = row j - row i * a[j,i]
			s = a.v[i][j];//i'th element in the row
			//since were making an upper diagonal matrix, just start at 'i' (all else will be zeros)
			for (k = i; k < width; k++) {
				a.v[k][j] -= a.v[k][i] * s;
			}
			//and dont forget about bob
			b.v[i] -= b.v[i] * s;
		}

	}

	for (i = width-1; i >= 0; i--) {
		
		//start with the solution in 'b'
		x->v[i] = b.v[i];

		//backwards substitute all previously calculated 'x's
		for (j = i+1; j < width; j++) {
			x->v[i] -= a.v[j][i] * x->v[j];
		}

		//scale by diagonal (should be '1' anyways)
		if (a.v[i][i]) {
			x->v[i] /= a.v[i][i];
		}
	}

	return true;
}
