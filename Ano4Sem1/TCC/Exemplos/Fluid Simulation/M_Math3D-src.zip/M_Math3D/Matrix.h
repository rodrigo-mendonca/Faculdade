/*

    File: Matrix.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#ifndef MATH3D_MATRIX_H
#define MATH3D_MATRIX_H

#include "vector.h"
#include "quat.h"

/*
matricies were stored

[0][3][6]		[00][10][20]
[1][4][7]		[01][11][21]
[2][5][8]		[02][12][22]

and vectors

[|][|][|]
[x][y][z]
[|][|][|]
*/

typedef struct matrix_s {
	union {
		scalar_t v[3][3];
		vector_t vec[3];
	};
} matrix_t;

/*
public:
	Matrix();
	Matrix(const Vector &x, const Vector &y, const Vector &z);		//these vectors make up the 3 rows in the matrix
	Matrix(const Quat &q);
	Matrix(const Scalar xx, const Scalar yx, const Scalar zx,
		   const Scalar xy, const Scalar yy, const Scalar zy,
		   const Scalar xz, const Scalar yz, const Scalar zz);

	void operator+=(const Matrix &a);
	void operator*=(const Scalar s);

	friend Vector operator*(const Matrix &a, const Vector &b);
	friend Matrix operator*(const Matrix &a, const Matrix &b);
	friend Matrix operator*(const Matrix &a, const Scalar &b);
	friend Matrix operator/(const Matrix &a, const Scalar &b);
*/

void		MatrixSet(matrix_t *mres,
				const scalar_t xx, const scalar_t yx, const scalar_t zx,
				const scalar_t xy, const scalar_t yy, const scalar_t zy,
				const scalar_t xz, const scalar_t yz, const scalar_t zz);
void		MatrixCopy(const matrix_t *src, matrix_t *mres);

void		MatrixAdd(const matrix_t *m, const matrix_t *n, matrix_t *mres);
void		MatrixSub(const matrix_t *m, const matrix_t *n, matrix_t *mres);

void		MatrixMul(const matrix_t *m, const vector_t *v, vector_t *vres);
void		MatrixMul(const matrix_t *m, const matrix_t *n, matrix_t *mres);
void		MatrixMul(const matrix_t *m, scalar_t s, matrix_t *mres);
void		MatrixTMul(const matrix_t *m, const vector_t *v, vector_t *vres);

void		QuatToMatrix(const quat_t *q, matrix_t *mres);

void		MatrixStar(const vector_t *v, matrix_t *mres);
void		MatrixTranspose(const matrix_t *a, matrix_t *mres);
void		MatrixAdjoint(const matrix_t *a, matrix_t *mres);
scalar_t	MatrixDeterminant(const matrix_t *a);
void		MatrixInverse(const matrix_t *a, matrix_t *mres);
void		MatrixScale(const vector_t *a, matrix_t *mres);
void		MatrixRotation(scalar_t theta, scalar_t x, scalar_t y, scalar_t z, matrix_t *mres);

//returns nonzero if a solution was found, zero if none was
bool		MatrixSolveCramer(const matrix_t *a, const vector_t *b, vector_t *res);
//bool		MatrixSolveHouseholder(const matrix_t *a, const vector_t *b, vector_t *res);
bool		MatrixSolveQP(matrix_t a, vector_t b, vector_t *x);

inline matrix_t	operator *(const matrix_t &a, const matrix_t &b) {
	matrix_t r;
	MatrixMul(&a,&b,&r);
	return r;
}

inline vector_t	operator *(const matrix_t &a, const vector_t &b) {
	vector_t r;
	MatrixMul(&a,&b,&r);
	return r;
}

#endif