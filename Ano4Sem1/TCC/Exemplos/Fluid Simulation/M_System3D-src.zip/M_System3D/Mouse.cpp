/*

    File: Mouse.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include "mouse.h"

#include <windows.h>
#include "main.h"

void M_MouseHandler::Reset(void)
{
	memset(this,0,sizeof(M_MouseHandler));
}


void M_MouseHandler::Update(void)
{
	static POINT current_pos;

	GetCursorPos (&current_pos);
	ScreenToClient(main_display->displayWnd, &current_pos);

	int width = main_display->displayWidth;
	int height = main_display->displayHeight;

	float iw = 1.f / (float)width;
	float ih = 1.f / (float)height;

	current_pos.y = height - current_pos.y - 1;

	moveX = current_pos.x - mouseX;
	moveY = current_pos.y - mouseY;

	mouseX = current_pos.x;
	mouseY = current_pos.y;
		
	mouseSX = (float)mouseX * iw;
	mouseSY = (float)mouseY * ih;

	moveSX = (float)moveX * iw;
	moveSY = (float)moveY * ih;

	dz = dzLast;
	dzLast = 0;

	//is this safe? (newschool)
	for (int i = 0; i < 3; i++)
	{
		if (buttonPress[i])	//key down
		{
			if (buttonPressLast[i])		//it is pressed and has been presssed
				buttonState[i] = MH_DOWN;
			else					//is being pressed but has not been before
				buttonState[i] = MH_PRESS;
		}
		else			//key up
		{
			if (buttonPressLast[i])		//is being released and was being pressed
				buttonState[i] = MH_RELEASE;
			else					//is up and has been up
				buttonState[i] = MH_UP;
		}
	}

	//update new state
	memcpy(buttonPressLast, buttonPress, sizeof(buttonPress));
}


//this function can only be called by main_display
//therefore in order for this to be called, lets assume main_display is up and running
void M_MouseHandler::SetState(
	bool lbutton,
	bool rbutton,
	bool mbutton,
	int nx, int ny, short dz)
{
/*
	int width = main_display->GetWidth();
	int height = main_display->GetHeight();

	float iw = 1.f / (float)width;
	float ih = 1.f / (float)height;

	ny = height - ny - 1;
*/

	//accumulate delta Z rotations.  clear upon update
	dzLast += dz;

	// ********** UPDATE BUTTON STATE ********** 
	int buttonPressNew[3] = {lbutton, rbutton, mbutton};

#if defined(OLDSCHOOL)
	for (int i = 0; i < 3; i++)
	{
		if (buttonPressNew[i])	//key down
		{
			if (buttonPress[i])		//it is pressed and has been presssed
				buttonState[i] = MH_DOWN;
			else					//is being pressed but has not been before
				buttonState[i] = MH_PRESS;
		}
		else			//key up
		{
			if (buttonPress[i])		//is being released and was being pressed
				buttonState[i] = MH_RELEASE;
			else					//is up and has been up
				buttonState[i] = MH_UP;
		}
	}
#endif

	//update new state
	memcpy(buttonPress, buttonPressNew, sizeof(buttonPressNew));

	// ********** UPDATE POSITION STATE ********** 
/*
	moveX = nx - x;
	moveY = ny - y;

	x = nx;
	y = ny;
		
	sx = (float)x * iw;
	sy = (float)y * ih;

	moveSX = (float)moveX * iw;
	moveSY = (float)moveY * ih;
*/
}
