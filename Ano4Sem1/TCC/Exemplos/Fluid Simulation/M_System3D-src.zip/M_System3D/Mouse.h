/*

    File: Mouse.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#if !defined(M_SYSTEM3D_MOUSE_H)
#define M_SYSTEM3D_MOUSE_H

#define MH_UP		0
#define MH_DOWN		1
#define MH_PRESS	2
#define MH_RELEASE	3

class M_MouseHandler {
public:
	M_MouseHandler() {Reset();}
	void Reset(void);

	//system layer call
	void Update(void);

	//windows message call
	void SetState(bool lbutton, bool rbutton, bool mbutton, int x, int y, short dz);

	//and all the stats...
	int buttonState[3];

	int buttonPress[3];
	int buttonPressLast[3];

	int mouseX, mouseY, moveX, moveY;
	float mouseSX, mouseSY, moveSX, moveSY;
	int dz, dzLast;
};

#endif