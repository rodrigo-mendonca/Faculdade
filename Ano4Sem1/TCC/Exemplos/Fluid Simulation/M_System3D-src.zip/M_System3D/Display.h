/*

    File: Display.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#ifndef SYSTEM3D_DISPLAY_H
#define SYSTEM3D_DISPLAY_H

#include "oglh.h"
#include "keyboard.h"
#include "mouse.h"
#include "cdaudio.h"

class M_Display {
public:
	//construction
	M_Display();
	bool Init(void);	

	//destruction
	~M_Display();
	void Kill(void);

	//clear screen
	void Clear(void);
	//swap buffers
	void Update(void);

	void SetKeyboardHandler(M_KeyboardHandler *kbdH);
	void SetMouseHandler(M_MouseHandler *mouseH);
	void SetCDAudio(M_CDAudio *cdAudio);

	void SetViewport(int w, int h);
	void ResetViewport(void);

	bool HasExtension(const char *ext);

	//the display window - created upon Init, destroyed upon Kill
	HWND	displayWnd;
	RECT	displayRect;
	POINT	displayCenter;
	int		displayWidth, displayHeight;

	bool SetFullscreen(bool fs, int width, int height, int bitsPerPixel);

	//flags set-able by everything else
	//default color=on, depth=on, stencil=off
	bool	clearColor;
	bool	clearDepth;
	bool	clearStencil;

	void	(*menuSelectCallback)(UINT uItem, UINT fuFlags, HMENU hmenu);
	bool	(*commandCallback)(WORD wNotifyCode, WORD wID, HWND hwndCtl);
	bool	(*messageCallback)(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

private:

	bool			fullscreen;
	DEVMODE			devmodeBackup;

	//the opengl handler
	OpenGLHandler	oglh;

};

#endif