/*

    File: CDAudio.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include <windows.h>
#include <mmsystem.h>

#include "cdaudio.h"
#include "main.h"		//relies on main_display for methods Play, Pause, and Resume
#include "error.h"

#define CDSTATE_STOP	0
#define CDSTATE_PLAY	1
#define	CDSTATE_PAUSE	2

void M_CDAudio::Reset(void)
{
	//whether the M_CDAudio object initalized correctly
	active = false;

	//whether there is a valid CD in the player
	cdValid = false;

	//the current state of the CD player - either CDSTATE_STOP, CDSTATE_PLAY, or CDSTATE_PAUSE
	state = CDSTATE_STOP;

	//if set, the CD player will play through track endings
	playThrough = false;

	//the current device ID
	wDeviceID = 0;

	//the number of tracks on the current audio CD
	trackCount = 0;

	//the current track playing
	currentTrack = 0;
}

bool M_CDAudio::Init(void)
{
	DWORD	dwReturn;
	MCI_OPEN_PARMS	mciOpenParms;
    MCI_SET_PARMS	mciSetParms;

	mciOpenParms.lpstrDeviceType = "cdaudio";

	dwReturn = mciSendCommand(0, MCI_OPEN, MCI_OPEN_TYPE | MCI_OPEN_SHAREABLE, (DWORD) (LPVOID) &mciOpenParms);
	
	if (dwReturn)
	{
		//main_console->Print("CDAudio_Init: MCI_OPEN failed (%i)\n", dwReturn);
		return false;
	}

	wDeviceID = mciOpenParms.wDeviceID;

    mciSetParms.dwTimeFormat = MCI_FORMAT_TMSF;
    if (dwReturn = mciSendCommand(wDeviceID, MCI_SET, MCI_SET_TIME_FORMAT, (DWORD)(LPVOID) &mciSetParms))
    {
		//main_console->Print("MCI_SET_TIME_FORMAT failed (%i)\n", dwReturn);
        mciSendCommand(wDeviceID, MCI_CLOSE, 0, (DWORD)NULL);
		return false;
    }

	active = true;

	GetInfo();

//	if (!cdValid) main_console->Print("CDAudio_Init: No CD in player.\n");

	//main_console->Print("CD Audio Initialized\n");

	return true;
}

void M_CDAudio::Kill(void)
{
	if (!active) return;

	//stop the current session
	Stop();

	if (mciSendCommand(wDeviceID, MCI_CLOSE, MCI_WAIT, (DWORD)NULL))
	{
		//main_console->("CDAudio_Shutdown: MCI_CLOSE failed\n");
	}

	Reset();
}

		//gets ready state / # of tracks
void M_CDAudio::GetInfo(void)
{
	DWORD				dwReturn;
	MCI_STATUS_PARMS	mciStatusParms;


	cdValid = false;

	mciStatusParms.dwItem = MCI_STATUS_READY;
    dwReturn = mciSendCommand(wDeviceID, MCI_STATUS, MCI_STATUS_ITEM | MCI_WAIT, (DWORD) (LPVOID) &mciStatusParms);
	if (dwReturn)
	{
		//main_console->Print("CDAudio: drive ready test - get status failed\n");
		return;
	}
	if (!mciStatusParms.dwReturn)
	{
		//main_console->Print("CDAudio: drive not ready\n");
		return;
	}

	mciStatusParms.dwItem = MCI_STATUS_NUMBER_OF_TRACKS;
    dwReturn = mciSendCommand(wDeviceID, MCI_STATUS, MCI_STATUS_ITEM | MCI_WAIT, (DWORD) (LPVOID) &mciStatusParms);
	if (dwReturn)
	{
		//main_console->Print("CDAudio: get tracks - status failed\n");
		return;
	}
	if (mciStatusParms.dwReturn < 1)
	{
		//main_console->Print("CDAudio: no music tracks\n");
		return;
	}

	cdValid = true;
	trackCount = mciStatusParms.dwReturn;

	return;
}

	//plays the specified track
bool M_CDAudio::Play(int track)
{
	DWORD				dwReturn, fdwCommand;
    MCI_PLAY_PARMS		mciPlayParms;
	MCI_STATUS_PARMS	mciStatusParms;

	if (!active) return false;

	if (!cdValid)
	{
		//double check the current CD drive
		GetInfo();

		if (!cdValid) return false;
	}

	//make sure track is within track range
	if (track < 1 || track > trackCount)
	{
		//main_console->Print("CDAudio: Bad track number %u.\n", track);
		return false;
	}

	// test track type / get track length
	mciStatusParms.dwItem = MCI_CDA_STATUS_TYPE_TRACK;
	mciStatusParms.dwTrack = track;
    dwReturn = mciSendCommand(wDeviceID, MCI_STATUS, MCI_STATUS_ITEM | MCI_TRACK | MCI_WAIT, (DWORD) (LPVOID) &mciStatusParms);
	if (dwReturn)
	{
		//main_console->Print("MCI_STATUS failed (%i)\n", dwReturn);
		return false;
	}
	if (mciStatusParms.dwReturn != MCI_CDA_TRACK_AUDIO)
	{
		//main_console->Print("CDAudio: track %i is not audio\n", track);
		return false;
	}

	fdwCommand = MCI_NOTIFY;

	switch (state)
	{
	case CDSTATE_STOP:
		fdwCommand |= MCI_FROM;
		mciPlayParms.dwFrom = MCI_MAKE_TMSF(track, 0, 0, 0);
		break;
	case CDSTATE_PLAY:
		Stop();
		fdwCommand |= MCI_FROM;
		mciPlayParms.dwFrom = MCI_MAKE_TMSF(track, 0, 0, 0);
		break;
//	case CDSTATE_PAUSE:
	default:
		break;
	}

	if (!playThrough)
	{
		fdwCommand |= MCI_TO;

		// get the length of the track to be played
		mciStatusParms.dwItem = MCI_STATUS_LENGTH;
		mciStatusParms.dwTrack = track;
		dwReturn = mciSendCommand(wDeviceID, MCI_STATUS, MCI_STATUS_ITEM | MCI_TRACK | MCI_WAIT, (DWORD) (LPVOID) &mciStatusParms);
		if (dwReturn)
		{
			//main_console->Print("MCI_STATUS failed (%i)\n", dwReturn);
			return false;
		}

		mciPlayParms.dwTo = (mciStatusParms.dwReturn << 8) | track;
	}

	mciPlayParms.dwCallback = (DWORD)main_display->displayWnd;
    dwReturn = mciSendCommand(wDeviceID, MCI_PLAY, fdwCommand, (DWORD)(LPVOID) &mciPlayParms);
	if (dwReturn)
	{
		//main_console->Print("CDAudio: MCI_PLAY failed (%i)\n", dwReturn);
		return false;
	}

	currentTrack = track;

	state = CDSTATE_PLAY;

	return true;
}

	//pauses player
void M_CDAudio::Pause(void)
{
	DWORD				dwReturn;
	MCI_GENERIC_PARMS	mciGenericParms;

	if (!active) return;

	if (state != CDSTATE_PLAY) return;

	mciGenericParms.dwCallback = (DWORD)main_display->displayWnd;
    if (dwReturn = mciSendCommand(wDeviceID, MCI_PAUSE, 0, (DWORD)(LPVOID) &mciGenericParms))
	{
		//main_console->Print("MCI_PAUSE failed (%i)", dwReturn);
	}

	state = CDSTATE_PAUSE;
}

	//stops playing
void M_CDAudio::Stop(void)
{
	DWORD	dwReturn;

	if (!active) return;

	if (state != CDSTATE_PLAY) return;		//and pause?


    if (dwReturn = mciSendCommand(wDeviceID, MCI_STOP, 0, (DWORD)NULL))
	{
		//main_console->Print("MCI_STOP failed (%i)", dwReturn);
	}

	state = CDSTATE_STOP;
}

	//ejects cd
void M_CDAudio::Eject(void)
{
	DWORD	dwReturn;

	if (state == CDSTATE_PLAY)
		Stop();

    if (dwReturn = mciSendCommand(wDeviceID, MCI_SET, MCI_SET_DOOR_OPEN, (DWORD)NULL))
	{
		//main_console->Print("MCI_SET_DOOR_OPEN failed (%i)\n", dwReturn);
	}

	cdValid = false;
}

	//closes the cd tray door
void M_CDAudio::Close(void)
{
	DWORD	dwReturn;

    if (dwReturn = mciSendCommand(wDeviceID, MCI_SET, MCI_SET_DOOR_CLOSED, (DWORD)NULL))
	{
		//main_console->Print("MCI_SET_DOOR_CLOSED failed (%i)\n", dwReturn);
	}
}

void M_CDAudio::PlayMode(bool thru)
{
	playThrough = thru;

	//TODO - if we are currently playing then remove the MCI_TO aspect
}

int M_CDAudio::SendMessage(unsigned int message, unsigned int device)
{
	//Error("MM_MCINOTIFY: message %x device %x", message, device);

	if (device != wDeviceID) return 1;

	switch (message)
	{
		case MCI_NOTIFY_SUCCESSFUL:

			//why is it that this message only comes through after
			// the CD has ended *AND* I move the current window?

			//Error("MCI_NOTIFY_SUCCESSFUL");

			if (state == CDSTATE_PLAY)
				state = CDSTATE_STOP;

			break;

			//issued upon Stop(), Pause()
		case MCI_NOTIFY_ABORTED:
			//Error("MCI_NOTIFY_ABORTED");
			break;

		case MCI_NOTIFY_SUPERSEDED:
			//Error("MCI_NOTIFY_SUPERSEDED");
			break;

		case MCI_NOTIFY_FAILURE:

			//main_console->Print("MCI_NOTIFY_FAILURE\n");
			//Error("MCI_NOTIFY_FAILURE");

			Stop();
			cdValid = false;
			break;

		default:
			//Error("Unexpected MM_MCINOTIFY type (%i)\n", message);
			return 1;
	}

	return 0;
}

#include <dbt.h>

void M_CDAudio::DeviceChange(unsigned int event, unsigned int data)
{
	//only process load/unload of a CD
	if (event != DBT_DEVICEREMOVECOMPLETE &&
		event != DBT_DEVICEARRIVAL) return;

	DEV_BROADCAST_HDR	*pdbch = (DEV_BROADCAST_HDR *)data;

	//only process volume drives
	if (pdbch->dbch_devicetype != DBT_DEVTYP_VOLUME) return;

	DEV_BROADCAST_VOLUME *pdbcv = (DEV_BROADCAST_VOLUME *)data;
	
	//only process media drives
	if (pdbcv->dbcv_flags != DBTF_MEDIA) return;

	char szDrive[4];

	// pdbcv->unitmask contains the drive bits
	for (unsigned int i = 0; !(pdbcv->dbcv_unitmask & (1 << i)); i++);

	wsprintf(szDrive, "%c:\\", 'A'+i);			

	//only process CDROMs
	if (GetDriveType(szDrive) != DRIVE_CDROM) return;

	//get the new drive state info
	GetInfo();

/*
	if (event == DBT_DEVICEREMOVECOMPLETE)
	{
		device has been removed
	}
	else //if (Event == DBT_DEVICEARRIVAL)
	{
		device has been inserted
	}
*/
}