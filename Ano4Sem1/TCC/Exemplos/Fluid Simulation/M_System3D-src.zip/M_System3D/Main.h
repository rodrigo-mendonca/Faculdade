/*

    File: Main.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#ifndef SYSTEM3D_MAIN_H
#define SYSTEM3D_MAIN_H

#include "display.h"
#include "keyboard.h"
#include "mouse.h"
#include "timer.h"
#include "cdaudio.h"
#include "audio.h"

//the objects you have control over
extern M_Display			*main_display;
extern M_KeyboardHandler	*main_keyboard;
extern M_MouseHandler		*main_mouse;
extern M_Timer				*main_timer;
extern M_CDAudio			*main_cdaudio;
extern M_Audio				*main_audio;

//what to do if you want out
void RequestExit(void);

//external must-be-defined functions
extern bool Init_Foundation(void);
extern void Update_Foundation(void);
extern void Shutdown_Foundation(void);

#endif