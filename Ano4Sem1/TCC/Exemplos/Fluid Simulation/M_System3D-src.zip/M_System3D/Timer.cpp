/*

    File: Timer.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include <windows.h>
#include "timer.h"
#include "error.h"

M_Timer::M_Timer()
{
	//query performance frequency
	LARGE_INTEGER PerformanceFreqLI;
	if (!QueryPerformanceFrequency (&PerformanceFreqLI))
		Error ("unable to read Performance Counter Frequency");

	unsigned int lowpart = (unsigned int)PerformanceFreqLI.LowPart;
	unsigned int highpart = (unsigned int)PerformanceFreqLI.HighPart;
	performanceCounterLowShift = 0;

	while (highpart || (lowpart > 2000000.0))
	{
		performanceCounterLowShift++;
		lowpart >>= 1;
		lowpart |= (highpart & 1) << 31;
		highpart >>= 1;
	}

	performanceFreq = 1.0 / (double)lowpart;

	//init class vars
	currentSys3DTime = 0;

	recLastTime = false;

	active = true;

}

double M_Timer::GetTime()
{
	if (!active) return 0;

	LARGE_INTEGER PerformanceCount;
	QueryPerformanceCounter (&PerformanceCount);

	unsigned int thisTime;

	thisTime = ((unsigned int)PerformanceCount.LowPart >> performanceCounterLowShift) |
			   ((unsigned int)PerformanceCount.HighPart << (32 - performanceCounterLowShift));

	if (!recLastTime)
	{
		lastTime = thisTime;
		recLastTime = true;
	}
	else
	{
		if (thisTime <= lastTime)	//keep from resetting current time on turnover
		{
			lastTime = thisTime;
		}
		else
		{
			unsigned int deltaTime = thisTime - lastTime;
			lastTime = thisTime;

			double deltaFloatTime = (double)deltaTime * performanceFreq;

			currentSys3DTime += deltaFloatTime;
		}
	}

	return currentSys3DTime;
}