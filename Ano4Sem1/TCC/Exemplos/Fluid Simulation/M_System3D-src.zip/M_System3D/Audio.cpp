/*

    File: Audio.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include "audio.h"
#ifdef USE_AL
#include "amp11lib/amp11lib.h"
#endif

//typedef struct sfx_s {
//	char name[MAX_PATH_LEN];
//	void *data;
//} sfx_t;

bool M_Audio::Init(void)
{
#ifdef USE_AL
	alInitLibrary();
#endif

//	stat = SNDDMA_InitDirect();
//	if (stat != SIS_SUCCESS) return false;
	
//	SND_InitScaletable();

//	sfx_array = (sfx_t *)malloc(MAX_SFX * sizeof(sfx_t));
//	sfx_array_count = 0;

	//load system sounds

//	S_StopAllSounds(true);

/*
	SNDDMA_Init
	{
		SNDDMA_InitWav
		{
		}
	}
	S_InitScaletable
	S_StopAllSounds
*/
	return true;
}

void M_Audio::Kill(void)
{
#ifdef USE_AL
	//free all here
	alEndLibrary();
#endif
	Reset();
}

#include <windows.h>
void M_Audio::Play(const char *ass)
{
	PlaySound(ass, NULL,
		SND_FILENAME | SND_ASYNC | SND_NODEFAULT | SND_NOSTOP | SND_NOWAIT );
}

void M_Audio::Reset(void)
{
	//zero obj here
}