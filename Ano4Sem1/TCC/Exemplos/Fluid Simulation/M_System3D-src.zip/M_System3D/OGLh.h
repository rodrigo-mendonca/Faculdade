/*

    File: OGLh.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#ifndef SYSTEM3D_OGLH_H
#define SYSTEM3D_OGLH_H

#include <windows.h>

class OpenGLHandler {

public:

	OpenGLHandler();
	bool Init(HWND hWnd, bool dbuf);

	~OpenGLHandler();
	void Kill(void);

	void Clear(bool color, bool depth, bool stencil);
	void Update(void);

	void ResetViewport(void);
	void SetViewport(int w, int h);

	int Width(void);
	int Height(void);

	bool HasExtension(const char *ext);

private:

	bool active;
	bool doublebuffered;

	HDC hDC;
	HGLRC hRC;
	HWND hWindow;

	int width, height;
};

#endif