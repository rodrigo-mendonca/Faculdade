/*

    File: CDAudio.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#if !defined(M_SYSTEM3D_CDAUDIO_H)
#define M_SYSTEM3D_CDAUDIO_H

class M_CDAudio {

public:
	M_CDAudio() {Reset();}
	~M_CDAudio() {Kill();}

private:
	void	Reset(void);

public:
//construct / destruct
	bool	Init(void);
	void	Kill(void);

//public
	bool	Play(int track);	//plays the specified track
	void	Stop(void);			//stops playing
	void	Pause(void);		//pauses player
	void	Eject(void);		//ejects cd
	void	Close(void);		//closes the cd tray door
	void	GetInfo(void);		//gets ready state / # of tracks

	void	PlayMode(bool thru);//sets whether or not the CD player should play through / stop at track endings

//shell
	int		CurrentTrack(void)	{return cdValid ? currentTrack : 0;}
	int		TrackCount(void)	{return cdValid ? trackCount : 0;}
	bool	CDValid(void)		{return cdValid;}

//stupid windows.
	int		SendMessage(unsigned int message, unsigned int device);
	void	DeviceChange(unsigned int event, unsigned int data);

private:
	bool			active;			//whether the M_CDAudio object initalized correctly
	bool			cdValid;		//whether there is a valid CD in the player
	int				state;			//the current state of the CD player - either STOP, PLAY, or PAUSE
	bool			playThrough;	//whether the CD player will play through to next tracks
	unsigned int	wDeviceID;		//cd player device ID
	int				trackCount;		//the number of tracks on the current audio CD
	int				currentTrack;	//the current track playing
};

#endif