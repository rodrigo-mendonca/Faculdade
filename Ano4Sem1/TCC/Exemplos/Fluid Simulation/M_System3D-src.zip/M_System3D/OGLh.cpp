/*

    File: OGLh.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include "oglh.h"
#include "error.h"

#include <windows.h>
#include <gl/gl.h>

// ************************* CONSTRUCTOR  *************************

OpenGLHandler::OpenGLHandler()
{
	active = false;
	hDC = NULL;
	hRC = NULL;
	hWindow = NULL;
	doublebuffered = false;

	width = 1;
	height = 1;
}

// ************************* DESTRUCTOR   *************************

OpenGLHandler::~OpenGLHandler()
{
	Kill();
}

// ******************************* OPENGL HANDLER *******************************

bool OpenGLHandler::Init(HWND hWnd, bool dbuf)
{
	PIXELFORMATDESCRIPTOR pfd;
	int pf;

	hWindow = hWnd;
	doublebuffered = dbuf;

	if ((hDC = GetDC(hWindow))==NULL)
	{
		Error("OpenGLHandler::Init() : GetDC() failed");
		return false;
	}

	//clear the structure
	memset(&pfd, 0, sizeof(pfd));

	//get the current pixel format
	int iPixelFormat = GetPixelFormat(hDC); 

	//and get its description
	DescribePixelFormat(hDC, iPixelFormat, sizeof(PIXELFORMATDESCRIPTOR), &pfd); 

	//modify its description accordingly:
	pfd.nSize		= sizeof(pfd);
	pfd.nVersion	= 1;
	
	pfd.dwFlags		= PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL;
	if (doublebuffered) pfd.dwFlags |= PFD_DOUBLEBUFFER;

	pfd.iPixelType	= PFD_TYPE_RGBA;
	pfd.iLayerType	= PFD_MAIN_PLANE;

	//FIXME: stencil RW stutters like mad when run in 16 bit color - not HW accelerated? whats up?
	pfd.cColorBits = 32;
	pfd.cAlphaBits = 8;
	pfd.cStencilBits = 16;

	//find the best fit pixel format to set it to
	if ((pf = ChoosePixelFormat(hDC, &pfd)) == 0)
	{
		Error("OpenGLHandler::Init() : ChoosePixelFormat() failed");
		return false;
	}

	//and set it accordingly
	if (SetPixelFormat(hDC, pf, &pfd) == false)
	{
		Error("OpenGLHandler::Init() : SetPixelFormat() failed");
		return false;
	}


	//make the GL RC
	if ((hRC = wglCreateContext(hDC))==NULL)
	{
		Error("OpenGLHandler::Init() : wglCreateContext() failed");
		return false;
	}

	//and make it the current RC
	if (wglMakeCurrent(hDC, hRC)==false)
	{
		Error("OpenGLHandler::Init() : wglMakeCurrent() failed");
		return false;
	}

	active = true;

	ResetViewport();

	return true;
}

void OpenGLHandler::Kill(void)
{
	if (!active) return;

	wglMakeCurrent(NULL, NULL);
	ReleaseDC(hWindow, hDC);
	wglDeleteContext(hRC);

	active = false;
}

void OpenGLHandler::Clear(bool color, bool depth, bool stencil)
{
	int bits = 0;
	if (color) bits |= GL_COLOR_BUFFER_BIT;
	if (depth) bits |= GL_DEPTH_BUFFER_BIT;
	if (stencil) bits |= GL_STENCIL_BUFFER_BIT;
	glClear(bits);
}

void OpenGLHandler::Update(void)
{
	if (!active) return;
	if (doublebuffered) SwapBuffers(hDC);
	else 				glFlush();
}

int OpenGLHandler::Width(void)	{return width;}
int OpenGLHandler::Height(void)	{return height;}

bool OpenGLHandler::HasExtension(const char *ext)
{
	int len = strlen(ext);
	char *gl_ext;

	for (gl_ext = (char *)glGetString(GL_EXTENSIONS); *gl_ext; gl_ext++)
		if (!memcmp(gl_ext, ext, len))
			return true;

	return false;
}

void OpenGLHandler::ResetViewport(void)
{
	RECT winRect;
	if (!active) return;
	if (!GetClientRect(hWindow, &winRect)) return;
	SetViewport(winRect.right, winRect.bottom);
}


void OpenGLHandler::SetViewport(int w, int h)
{
	width = w;
	height = h;
	glViewport(0, 0, width, height);
}
