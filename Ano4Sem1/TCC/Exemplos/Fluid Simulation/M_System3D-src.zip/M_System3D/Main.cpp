/*

    File: Main.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include <windows.h>

#include "main.h"
#include "error.h"

M_Display *main_display = NULL;
M_KeyboardHandler *main_keyboard = NULL;
M_MouseHandler *main_mouse = NULL;
M_Timer *main_timer = NULL;
M_CDAudio *main_cdaudio = NULL;
M_Audio *main_audio = NULL;

extern bool Init_Foundation(void);
extern void Update_Foundation(void);
extern void Shutdown_Foundation(void);

static int requestExit = 0;
void RequestExit(void)	{	requestExit = 1;}

bool Init_System3D(void)
{
	//create the timer
	main_timer = new M_Timer();
	if (!main_timer)
	{
		Error("Failed to create timer object");
		return false;
	}

	//create the keyboard handler
	main_keyboard = new M_KeyboardHandler();
	if (!main_keyboard)
	{
		Error("Failed to create keyboard handler object");
		return false;
	}

	//create the mouse handler
	main_mouse = new M_MouseHandler();
	if (!main_mouse)
	{
		Error("Failed to create mouse handler object");
		return false;
	}

	//create the cd audio handler
	main_cdaudio = new M_CDAudio();
	if (!main_cdaudio)
	{
		Error("Failed to create CD Audio object");
		return false;
	}
	//attempt to init the CD player.  if init fails then continue on
	main_cdaudio->Init();

	main_audio = new M_Audio();
	if (main_audio && !main_audio->Init())
	{
		delete main_audio;
		main_audio = NULL;
	}
	if (!main_audio)
	{
		Error("Failed to create audio object");
		return false;
	}

	//create the display - window and OpenGL context
	main_display = new M_Display();
	if (main_display && !main_display->Init())
	{
		delete main_display;
		main_display = NULL;
	}
	if (!main_display)
	{
		Error("Failed to create display object");
		return false;
	}

	//clear the display.
	main_display->Clear();

	//what does display have to do with the keyboard?
	//well, since im using the WM_KEYUP/DOWN messages to get keyboard input
	//input is going to be trapped via window
	//and main_display contains the main display window.
	//so there.
	//of course - this means we have to kill the keyboard handler only after we kill the window
	main_display->SetKeyboardHandler(main_keyboard);
	main_display->SetMouseHandler(main_mouse);
	main_display->SetCDAudio(main_cdaudio);

	//external call
	if (!Init_Foundation())
	{
		Error("Foundation level failed to initialize");
		return false;
	}

	return true;
}

void Update_System3D(void)
{
	//pre-update
	main_mouse->Update();
	main_keyboard->PreUpdate();
	main_display->Clear();

	//external call
	Update_Foundation();

	//post-update
	main_display->Update();
	main_keyboard->PostUpdate();
}

void Shutdown_System3D(void)
{
	//external call
	Shutdown_Foundation();

	//and shutdown
	if (main_display)	{delete main_display;	main_display = NULL;	}
	if (main_audio)		{delete main_audio;		main_audio = NULL;		}
	if (main_cdaudio)	{delete main_cdaudio;	main_cdaudio = NULL;	}
	if (main_mouse)		{delete main_mouse;		main_mouse = NULL;		}
	if (main_keyboard)	{delete main_keyboard;	main_keyboard = NULL;	}
	if (main_timer)		{delete main_timer;		main_timer = NULL;		}
}


//the one and only:
int APIENTRY WinMain(HINSTANCE hCurrentInst, HINSTANCE hPreviousInst, LPSTR lpszCmdLine, int nCmdShow)
{
    MSG msg;				/* message */
	HWND hWnd = NULL;

	if (!Init_System3D())
	{
		Shutdown_System3D();
		return 1;
	}

	//as long as we are getting input through one and only one HWnd
	if (main_display) hWnd = main_display->displayWnd;

	while (!requestExit) {
/* oldschool
		while(PeekMessage(&msg, hWnd, 0, 0, PM_NOREMOVE)) {
			if(GetMessage(&msg, hWnd, 0, 0)) {
				TranslateMessage(&msg);
				DispatchMessage(&msg);
		    } else {
				goto quit; // This 'goto' was in the sample code
			}
		}
		Update_System3D();
newschool */
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
			if (msg.message == WM_QUIT) break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		} else {
			Update_System3D();
		}
	}

//quit:
	Shutdown_System3D();

    return msg.wParam;
}
