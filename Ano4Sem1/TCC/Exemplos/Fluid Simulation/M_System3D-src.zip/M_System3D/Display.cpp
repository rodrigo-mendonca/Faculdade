/*

    File: Display.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include <windows.h>

#include "error.h"
#include "oglh.h"

#include "display.h"
#include "keyboard.h"

static char *M_WindowClassName = "M_WindowClass";

HINSTANCE My_RegisterClass(WNDPROC wndProc)
{
    WNDCLASS    wc;
	static HINSTANCE hInstance = 0;

    /* only register the window class once - use hInstance as a flag. */
    if (!hInstance) {
		hInstance = GetModuleHandle(NULL);

		wc.style         = CS_OWNDC;
		wc.lpfnWndProc   = wndProc;
		wc.cbClsExtra    = 0;
		wc.cbWndExtra    = 0;
		wc.hInstance     = hInstance;
		wc.hIcon         = LoadIcon(NULL, IDI_WINLOGO);
		wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
		wc.hbrBackground = NULL;
		wc.lpszMenuName  = NULL;
		wc.lpszClassName = M_WindowClassName;

		if (!RegisterClass(&wc)) {
		    Error("My_RegisterClass(): RegisterClass() failed:  ");
		    return 0;
		}
    }

	return hInstance;
}

HWND My_CreateWindow(int x, int y, int width, int height, char *title, WNDPROC wndProc)
{
    HWND hWnd;
	HINSTANCE hInst;

	if ( (hInst = My_RegisterClass(wndProc)) == 0)
	{
		Error("My_CreateWindow(): My_RegisterClass() failed");
		return NULL;
	}

	DWORD dwExStyle =	WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;
	DWORD dwStyle =		WS_OVERLAPPEDWINDOW | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;

    hWnd = CreateWindowEx(dwExStyle, M_WindowClassName, title,
			dwStyle, x, y, width, height, NULL, NULL, hInst, NULL);

    if (hWnd == NULL)
	{
		Error("My_CreateWindow():  hWnd failed to be created");
		return NULL;
    }

	return hWnd;
}

//used internally - via set keyboard handler
#define MY_WM_POST_OGLH		0x2502
#define MY_WM_POST_KBDH		0x2503
#define MY_WM_POST_MOUSEH	0x2504
#define MY_WM_POST_CDAUDIO	0x2505

// ********** unorganized me looking for a quick fix: **********
#include "main.h"

LONG WINAPI DisplayWindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static M_Display *displayH = NULL;
	static OpenGLHandler *oglH = NULL;
	static M_KeyboardHandler *kbdH = NULL;
	static M_MouseHandler *mouseH = NULL;
	static M_CDAudio *cdAudio = NULL;

	static PAINTSTRUCT ps;

	switch(uMsg) {

	case WM_CREATE:
// ********** unorganized me looking for a quick fix: **********
		displayH = main_display;
		return 0;

	case MY_WM_POST_OGLH:
		oglH = (OpenGLHandler *)lParam;
		return 0;
	case MY_WM_POST_KBDH:
		kbdH = (M_KeyboardHandler *)lParam;
		return 0;
	case MY_WM_POST_MOUSEH:
		mouseH = (M_MouseHandler *)lParam;
		return 0;
	case MY_WM_POST_CDAUDIO:
		cdAudio = (M_CDAudio *)lParam;
		return 0;

	case WM_PAINT:
		BeginPaint(hWnd, &ps);
		EndPaint(hWnd, &ps);
		return 0;

	case WM_SIZE:
		//post a resize message
		if (oglH)
		{
			oglH->ResetViewport();
//DIRTY HACK
			oglH->Clear(main_display->clearColor,main_display->clearDepth,main_display->clearStencil);
		}

		displayH->displayWidth = LOWORD(lParam);
		displayH->displayHeight = HIWORD(lParam);

		//update window data
		if (GetWindowRect(hWnd, &displayH->displayRect))
		{
			displayH->displayCenter.x = (displayH->displayRect.left + displayH->displayRect.right) >> 1;
			displayH->displayCenter.y = (displayH->displayRect.top + displayH->displayRect.bottom) >> 1;
		}

		return 0;

	case WM_CLOSE:
		//post a quit message for the main program
		RequestExit();
		//and go
		return 0;

// ********* MOUSE WINDOWS MESSAGES ********* 

//dirty of me...
#define WM_MOUSEWHEEL                   0x020A
		///all the same deal
	case WM_MOUSEWHEEL:
		if (mouseH) mouseH->SetState(
			(wParam & MK_LBUTTON) == MK_LBUTTON,
			(wParam & MK_RBUTTON) == MK_RBUTTON, 
			(wParam & MK_MBUTTON) == MK_MBUTTON, 
			LOWORD(lParam), 
			HIWORD(lParam),
			HIWORD(wParam));		//scroll =)
		return 0;

	case WM_MOUSEMOVE:
	case WM_LBUTTONUP:
	case WM_MBUTTONUP:
	case WM_RBUTTONUP:
	case WM_LBUTTONDOWN:
	case WM_MBUTTONDOWN:
	case WM_RBUTTONDOWN:
		if (mouseH) mouseH->SetState(
			(wParam & MK_LBUTTON) == MK_LBUTTON,
			(wParam & MK_RBUTTON) == MK_RBUTTON, 
			(wParam & MK_MBUTTON) == MK_MBUTTON, 
			LOWORD(lParam), 
			HIWORD(lParam),
			0);
		return 0;

// ********* KEYBOARD WINDOWS MESSAGE ********* 

	case WM_KEYDOWN:
		if (kbdH) kbdH->KeyDown(wParam);
		return 0;
	case WM_KEYUP:
		if (kbdH) kbdH->KeyUp(wParam);
		return 0;

// ********* CD AUDIO WINDOWS MESSAGE ********* 

	case WM_DEVICECHANGE:

		if (cdAudio)
		{
			cdAudio->DeviceChange((unsigned int)wParam, (unsigned int)lParam);
			return 0;
		}
		break;

	case MM_MCINOTIFY:				//for some odd reason this is only coming through after i move the window
		if (cdAudio) return cdAudio->SendMessage(wParam, lParam);
		break;

// ********* CALLBACK (?) *********
	case WM_MENUSELECT:
		if (main_display->menuSelectCallback) {
			main_display->menuSelectCallback((UINT)LOWORD(wParam), (UINT)HIWORD(wParam), (HMENU)lParam);
			return 0;
		}
		break;
	case WM_COMMAND:
		if (main_display->commandCallback) {
			if (main_display->commandCallback(HIWORD(wParam), LOWORD(wParam), (HWND)lParam)) {
				return 0;
			}
		}
		break;
	}

	if (main_display->messageCallback) {
		if (main_display->messageCallback(hWnd, uMsg, wParam, lParam)) {
			return 0;
		}
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam); 
} 

M_Display::M_Display() {
	//NULL the pointers
	displayWnd = NULL;
	menuSelectCallback = NULL;
	commandCallback = NULL;
	messageCallback = NULL;
	fullscreen = false;
	clearColor = true;
	clearDepth = true;
	clearStencil = false;

}

bool M_Display::Init(void)
{
	//create the display window and pass the memory lcoation of the opengl handler pointer
	//to the window.  we are passing the pointer to the pointer so that DisplayWindowProc
	//will have the abillity to modify the variable's data.  this ability is needed
	//if the Initialization of the opengl handler fails, and the pointer needs to be set
	//to NULL

	//set it at the right spot on the screen
	int xpos = (GetSystemMetrics(SM_CXSCREEN) >> 1) - (640 >> 1);
	int ypos = (GetSystemMetrics(SM_CYSCREEN) >> 1) - (480 >> 1);

	displayWnd = My_CreateWindow(xpos,ypos,640,480, "M_System3D", DisplayWindowProc);
	if (displayWnd == NULL)
	{
		Error("InitDisplay() displayWnd failed to be created");
		return false;
	}

	if (oglh.Init(displayWnd, true) == false)	//if the opengl display obj failed to Init
	{
		//destroy opengl handler
		oglh.Kill();
		return false;	//WM_CREATE failed
	}

	//good to go - show the window and leave
	ShowWindow(displayWnd, SW_SHOW);

	//send the OpenGLHandler pointer to the window - for catching WM_RESIZE messages
	SendMessage(displayWnd, MY_WM_POST_OGLH, 0, (LPARAM)&oglh);

	//initialize fullscreen as false - and save current DEVMODE info
	EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &devmodeBackup);
	fullscreen = false;

	return true;
}

//send the M_KeyboardHandler pointer to the window - for catching WM_RESIZE messages
void M_Display::SetKeyboardHandler(M_KeyboardHandler *kbdH)
{
	SendMessage(displayWnd, MY_WM_POST_KBDH, 0, (LPARAM)kbdH);
}

//send the M_MouseHandler pointer to the window - for catching WM_RESIZE messages
void M_Display::SetMouseHandler(M_MouseHandler *mouseH)
{
	SendMessage(displayWnd, MY_WM_POST_MOUSEH, 0, (LPARAM)mouseH);
}

//send the M_CDAudio pointer to the window - for catching WM_RESIZE messages
void M_Display::SetCDAudio(M_CDAudio *cdAudio)
{
	SendMessage(displayWnd, MY_WM_POST_CDAUDIO, 0, (LPARAM)cdAudio);
}

void M_Display::Update(void)
{
	//update the opengl handler (if we have an active one)
	oglh.Update();
}

void M_Display::Clear(void)
{
	oglh.Clear(clearColor,clearDepth,clearStencil);
}


M_Display::~M_Display() { Kill(); }

void M_Display::Kill(void)
{
	SetFullscreen(false, 0, 0, 0);

	//if the OpenGL Handler exists, then kill it!
	oglh.Kill();

	//same to you, display window!
	if (displayWnd)
	{
		DestroyWindow(displayWnd);
		displayWnd = NULL;
	}
}

void M_Display::SetViewport(int w, int h)	{oglh.SetViewport(w,h); }
void M_Display::ResetViewport(void)			{oglh.ResetViewport(); }

bool M_Display::HasExtension(const char *ext) {return oglh.HasExtension(ext);}

bool M_Display::SetFullscreen(bool fs, int width, int height, int bitsPerPixel)
{
	if (fs == false && fullscreen == true)
	{

		//of course this assumes the cursor was hidden...
//		ShowCursor(TRUE);

		//initially hide the window
		ShowWindow(displayWnd, SW_HIDE);

		if (ChangeDisplaySettings(NULL,CDS_TEST) != DISP_CHANGE_SUCCESSFUL)
		{
			ChangeDisplaySettings(NULL, CDS_RESET);
			ChangeDisplaySettings(&devmodeBackup, CDS_RESET);
		}
		else
		{
			ChangeDisplaySettings(NULL, CDS_RESET);
		}

		fullscreen = false;

		SetWindowLong(displayWnd, GWL_EXSTYLE, WS_EX_APPWINDOW | WS_EX_WINDOWEDGE);
		SetWindowLong(displayWnd, GWL_STYLE, WS_OVERLAPPEDWINDOW | WS_CLIPSIBLINGS | WS_CLIPCHILDREN);

		DEVMODE newSettings;
		EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &newSettings);

		MoveWindow(displayWnd,
			(newSettings.dmPelsWidth >> 1) - 320,
			(newSettings.dmPelsHeight >> 1) - 240,
			640, 480, false); 

		//show the window again
		ShowWindow(displayWnd, SW_SHOW);
		SetActiveWindow(displayWnd);
	}
	else if (fs == true)
	{
		DEVMODE dmScreenSettings;
		memset(&dmScreenSettings, 0, sizeof(DEVMODE));

		//initially hide the window
		ShowWindow(displayWnd, SW_HIDE);

		dmScreenSettings.dmSize = sizeof(DEVMODE);

		if (width)
		{
			dmScreenSettings.dmPelsWidth	= width;
			dmScreenSettings.dmFields		|= DM_PELSWIDTH;
		}

		if (height)
		{
			dmScreenSettings.dmPelsHeight	= height;
			dmScreenSettings.dmFields		|= DM_PELSHEIGHT;
		}

		if (bitsPerPixel)
		{
			dmScreenSettings.dmBitsPerPel	= bitsPerPixel;
			dmScreenSettings.dmFields		|= DM_BITSPERPEL;
		}

		if (ChangeDisplaySettings(&dmScreenSettings, CDS_FULLSCREEN) != DISP_CHANGE_SUCCESSFUL)
		{
			Error("Could not change video mode to %dx%dx%d", width, height, bitsPerPixel);

			//show the window again
			ShowWindow(displayWnd, SW_SHOW);
			SetActiveWindow(displayWnd);

			return false;
		}

		fullscreen = true;

		SetWindowLong(displayWnd, GWL_EXSTYLE, WS_EX_APPWINDOW);
		SetWindowLong(displayWnd, GWL_STYLE, WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN);

		DEVMODE newSettings;
		EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &newSettings);

		MoveWindow(displayWnd, 0, 0, 2, 2, false);		//force a WM_SIZE by changing size regardless
		MoveWindow(displayWnd, 0, 0, newSettings.dmPelsWidth, newSettings.dmPelsHeight, false); 

		//show the window again
		ShowWindow(displayWnd, SW_SHOW);
		SetActiveWindow(displayWnd);
	}

	return true;
}
