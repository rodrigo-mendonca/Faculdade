/*

    File: Keyboard.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include <windows.h>	//for memcpy and memset

#include "keyboard.h"
#include "main.h"

M_KeyboardHandler::M_KeyboardHandler()
{
	Reset();
}

void M_KeyboardHandler::Reset(void)
{
	memset(keypress, 0, sizeof(keypress));
	memset(keypress_last, 0, sizeof(keypress));
	memset(keystate, 0, sizeof(keystate));
	memset(keydownqueue, 0, sizeof(keydownqueue));

	firstkeydown = lastkeydown = 0;

	execFunc = NULL;
	memset(bindmap, 0, sizeof(bindmap));
}

void M_KeyboardHandler::KeyUp(int key)
{
	keypress[key] = 0;
}

void M_KeyboardHandler::KeyDown(int key)
{
	//record in the keydown queue
	keydownqueue[lastkeydown] = key;
	//calc the new queue end location
	int nextkeydown = ((lastkeydown + 1) & (KBH_KEYBUF_SIZE-1));
	//if it doesnt surpass the beginning, then increment
	if (nextkeydown != firstkeydown) lastkeydown = nextkeydown;

	//set the current key state to 'down'
	keypress[key] = 1;
}

void M_KeyboardHandler::PreUpdate(void)
{
	// *************** INTRO - calc the keystat array via the keypress and keypress_last arrays

	for (int x = 0; x < KBH_KEY_COUNT; x++)
	{
		if (keypress[x])	//key down
		{
			if (keypress_last[x])		//it is pressed and has been presssed
				keystate[x] = KBH_DOWN;
			else					//is being pressed but has not been before
				keystate[x] = KBH_PRESS;
		}
		else			//key up
		{
			if (keypress_last[x])		//is being released and was being pressed
				keystate[x] = KBH_RELEASE;
			else					//is up and has been up
				keystate[x] = KBH_UP;
		}

/* bindmap addition
	if the current key/state matches anything in the bindkey buffer
	then execute it
*/
		if (execFunc && bindmap[x][keystate[x]][0])
			execFunc(bindmap[x][keystate[x]]);
	}

	// *************** ENCORE - copy the keypress map to the keypress_last map

	memcpy(keypress_last, keypress, sizeof(keypress));
}

//this is a post-update so all else between has a chance to view the current key queue (ie the console)
void M_KeyboardHandler::PostUpdate(void)
{
	firstkeydown = lastkeydown;
}

/* bindmap addition
binds a key to a cvar function
'key'	the ascii character associated with the key
'state' whether the key is to be up, pressed, down, or depressed
'cmd'	the cvar command to execute when the key is invoked
*/
void M_KeyboardHandler::Bind_Key(unsigned char key, unsigned char state, char *cmd)
{
	int len = strlen(cmd);
	if (len > 31) len = 31;

	key = (unsigned char)VkKeyScan(key);
	state &= 3;

	memcpy(&bindmap[key][state], cmd, len);
	bindmap[key][state][len] = 0;
}

/* bindmap addition
'func'	the function to pass bindmap cmds to when a bindmap action is invoked
*/
void M_KeyboardHandler::Bind_ExecFunc(void (*func)(char *))
{
	execFunc = func;
}
