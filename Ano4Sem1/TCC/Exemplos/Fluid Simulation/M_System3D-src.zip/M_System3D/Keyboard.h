/*

    File: Keyboard.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
/*
TODO:
overhaul current model
replace with the quake-style bind/unbind keyup/keydown using a function pointer table
current model does not work well with keeping track of certain keystates while trying to keep hidden other keystates
*/
#ifndef SYSTEM3D_KEYBOARD_H
#define SYSTEM3D_KEYBOARD_H

#define KBH_KEY_COUNT	256
#define KBH_KEYBUF_SIZE	32	//matching the oldschool dos keyboard buffer of 32 bytes

#define KBH_UP			0
#define KBH_DOWN		1
#define KBH_PRESS		2
#define KBH_RELEASE		3
#define KBH_STATE_COUNT	4

//TODO make main_keyboard part of a main object which all other objects can access

class M_KeyboardHandler {
public:
	M_KeyboardHandler();

	//called upon init and before the window loses focus
	void Reset(void);

	//call when a key is pressed
	void KeyUp(int key);
	//call when a key is depressed
	void KeyDown(int key);

	//call to calculate the keystate array and copy the current keypress over the last
	void PreUpdate(void);
	//call to clear the keydown queue
	void PostUpdate(void);

	//the state of a key - PRESSED, DOWN, DEPRESSED, UP
	char keystate[KBH_KEY_COUNT];

	//store all the keystrokes between this frame and the previous frame
	int keydownqueue[KBH_KEYBUF_SIZE];
	int firstkeydown, lastkeydown;

	void Bind_Key(unsigned char key, unsigned char state, char *cmd);
	void Bind_ExecFunc(void (*func)(char *));

private:
	//whether a key is up or down (0 or 1, respectively)
	char keypress[KBH_KEY_COUNT];
	char keypress_last[KBH_KEY_COUNT];

	void (*execFunc)(char *);
	char bindmap[KBH_KEY_COUNT][KBH_STATE_COUNT][32];	//32 max length
};

#endif