/*

    File: CVar.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#if !defined(M_FOUNDATION_CVAR_H)
#define M_FOUNDATION_CVAR_H

#ifndef NULL
#define NULL 0
#endif

typedef void CFUNC(int, char **);

class CVar {
private:
	const char *name;
	const char *desc;
public:
	CVar(const char *name);
	CVar(const char *name, const char *desc);
	CVar(const char *name, CFUNC *func);
	CVar(const char *name, const char *desc, CFUNC *func);

	virtual void execArgs(int argc, char **argv);

	const char *getName(void) { return name; }

	CFUNC *func;
};

class CVarPrim : public CVar {
public:
	CVarPrim(const char *name, const char *desc, CFUNC *func) : CVar(name,desc,func) {}

	virtual void execArgs(int argc, char **argv);
	virtual void setValue(int argc, char **argv);
	virtual void echoData(void);
};

class CVarf : public CVarPrim {
public:
	CVarf(const char *name, float val) : CVarPrim(name,NULL,NULL) { data = val; }

	virtual void setValue(int argc, char **argv);
	virtual void echoData(void);

	virtual void operator=(float f) { data = f; }
	virtual operator float(void) { return data; }
	
	float data;
};

class CVari : public CVarPrim {
public:
	CVari(const char *name, int val) : CVarPrim(name,NULL,NULL) { data = val; }

	virtual void setValue(int argc, char **argv);
	virtual void echoData(void);

	virtual void operator=(int f) { data = f; }
	virtual operator int(void) { return data; }
	
	int data;
};

//works as CVarF, but references the data indirectly
class CVarfv : public CVarPrim {
public:
	CVarfv(const char *name) : CVarPrim(name,NULL,NULL) {	data = 0; }
	CVarfv(float *data, const char *name) : CVarPrim(name,NULL,NULL) {	this->data = data; }
	CVarfv(float *data, const char *name, CFUNC *func) : CVarPrim(name,NULL,func) {	this->data = data; }

	virtual void setValue(int argc, char **argv);
	virtual void echoData(void);

	virtual void operator=(float *f) { data = f; }

	float *data;
};

//for some odd reason it gets errors when i dont specifically define operator=
//for all CVarfv's child classes...
class CVar3fv : public CVarfv {
public:
	CVar3fv(const char *name) : CVarfv(name) {}

	virtual void setValue(int argc, char **argv);
	virtual void echoData(void);

	virtual void operator=(float *f) { data = f; }
};

class CVar4fv : public CVarfv {
public:
	CVar4fv(const char *name) : CVarfv(name) {}
	CVar4fv(float *data, const char *name, CFUNC *func) : CVarfv(data,name,func) {}

	virtual void setValue(int argc, char **argv);
	virtual void echoData(void);
	
	virtual void operator=(float *f) { data = f; }
};

class CVariv : public CVarPrim {
public:
	CVariv(const char *name) : CVarPrim(name,NULL,NULL) {	data = 0; }
	CVariv(int *data, const char *name) : CVarPrim(name,NULL,NULL) {	this->data = data; }
	CVariv(int *data, const char *name, CFUNC func) : CVarPrim(name,NULL,func) {	this->data = data; }

	virtual void setValue(int argc, char **argv);
	virtual void echoData(void);

	virtual void operator=(int *f) { data = f; }

	int *data;
};

typedef enum {
	CVAR_TYPE_NONE,
	CVAR_TYPE_BOOL,
	CVAR_TYPE_INT,
	CVAR_TYPE_FLOAT,
	CVAR_TYPE_DOUBLE,
} cvar_type_t;

#include "../m_math3d/geometry.h"

//wildcard - auto-detect the primitive - but not = r/w operations
class CVarw : public CVarPrim {
public:
	CVarw(int data, const char *name, CFUNC *func = NULL);
	CVarw(bool *data, const char *name, CFUNC *func = NULL);
	CVarw(int *data, const char *name, CFUNC *func = NULL);
	CVarw(float *data, const char *name, CFUNC *func = NULL);
	CVarw(double *data, const char *name, CFUNC *func = NULL);
	//math lib specific
	CVarw(vector_t *data, const char *name, CFUNC *func = NULL);
	CVarw(quat_t *data, const char *name, CFUNC *func = NULL);

	void *data;
	cvar_type_t type;
	int dim;

	virtual void setValue(int argc, char **argv);
	virtual void echoData(void);
};

bool Init_CVars(void);
void Shutdown_CVars(void);
void CVar_Exec(char *buffer);

#endif