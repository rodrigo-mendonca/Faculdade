/*

    File: Main.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include "../m_system3d/main.h"
#include "../m_system3d/error.h"
#include "main.h"
#include "const.h"

extern bool Init_Application3D(void);
extern void Update_Application3D(void);
extern void Shutdown_Application3D(void);

M_Console		*main_console = NULL;
M_Camera		*main_camera = NULL;

int				overrideCameraKeys = 0;
float			overrideCameraSpeed = 0.5f;
float			overrideCameraRot = 1.f;
bool			m_foundation_use_camera = true;

// ************ CONSOLE FUNCTIONS ************ 

//			SYSTEM.OGLH CONSOLE SHELL

static int CVar_GL_PolygonMode = 2;
static int CVar_GL_CullFace = 0;
static int CVar_GL_DepthTest = 0;
static quat_t CVar_GL_ClearColor = {0,0,0,1};

void CFunc_GL_PolygonMode(int argc, char **argv)
{
	if (CVar_GL_PolygonMode == 0)
		glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
	else if (CVar_GL_PolygonMode == 1)
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	else
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
}

void CFunc_GL_CullFace(int argc, char **argv)
{
	if (CVar_GL_CullFace)
	{
		if (CVar_GL_CullFace == 1)
			glCullFace(GL_BACK);
		else if (CVar_GL_CullFace == 2)
			glCullFace(GL_FRONT);
		glEnable(GL_CULL_FACE);
	}
	else
	{
		glDisable(GL_CULL_FACE);
	}
}

void CFunc_GL_DepthTest(int argc, char **argv)
{
	if (CVar_GL_DepthTest)
		glEnable(GL_DEPTH_TEST);
	else
		glDisable(GL_DEPTH_TEST);
}

void CFunc_GL_ClearColor(int argc, char **argv)
{
	glClearColor(CVar_GL_ClearColor.x, CVar_GL_ClearColor.y, CVar_GL_ClearColor.z, CVar_GL_ClearColor.w);
}

//			SYSTEM.DISPLAY CONSOLE SHELL

void CFunc_SetMode(int argc, char **argv)
{
	int width = 0;
	int height = 0;
	int bpp = 0;

	if (argc == 1)
	{
		if (main_display->SetFullscreen(false, 0, 0, 0))
			main_console->Print("SetMode: sucessfully set to windows mode\n");
		else
			main_console->Print("SetMode: failed\n");
	}
	else
	{
		if (argc > 1) width = atoi(argv[1]);
		if (argc > 2) height = atoi(argv[2]);
		if (argc > 3) bpp = atoi(argv[3]);

		if (main_display->SetFullscreen(true, width, height, bpp))
			main_console->Print("SetMode: sucessfully set to %dx%dx%d\n", width, height, bpp);
		else
			main_console->Print("SetMode: failed\n");
	}
}

//			SYSTEM.CDAUDIO CONSOLE SHELL

void CFunc_CDAudio(int argc, char **argv)
{
	if (argc < 2) return;
	//two var cd funcs

	if (!_stricmp(argv[1], "init"))	
	{
		main_console->Print("CD Audio Init() %s\n", main_cdaudio->Init() ? "sucessful" : "failed");
		return;
	}

	if (!_stricmp(argv[1], "shutdown"))		main_cdaudio->Kill();		//is this really needed?
	if (!_stricmp(argv[1], "stop"))			main_cdaudio->Stop();
	if (!_stricmp(argv[1], "pause"))		main_cdaudio->Pause();
	if (!_stricmp(argv[1], "eject"))		main_cdaudio->Eject();
	if (!_stricmp(argv[1], "close"))		main_cdaudio->Close();

	if (argc < 3) return;
	//three var cd funcs

	if (!_stricmp(argv[1], "play"))
	{
		if (main_cdaudio->Play( atoi( argv[2] ) ))
			main_console->Print("CD Audio : Playing Track %s\n", argv[2]);
		else
			main_console->Print("CD Audio : Unable To Play Track %s\n", argv[2]);
	}

	if (!_stricmp(argv[1], "playthru"))		main_cdaudio->PlayMode ( (atoi(argv[2]) != 0) );
}

//			SYSTEM.MAIN CONSOLE SHELL

void CFunc_Quit(int argc, char **argv)
{
	RequestExit();
}

//			SYSTEM.ERROR CONSOLE SHELL

void CFunc_Error(int argc, char **argv)
{
	if (argc > 1) Error("%s", argv[1]);
}

void CFunc_BindKey(int argc, char **argv)
{
	if (argc < 3)
	{
		main_console->Print("usage: Bind <key><state> <func>\n");
		return;
	}

	unsigned char key = (unsigned char)argv[1][0];
	unsigned char state;

	switch (argv[1][1])
	{
	case '0':	case 'u':	case 'U':	state = 0;	break;
	case '1':	case 'd':	case 'D':	state = 1;	break;
	case '2':	case 'p':	case 'P':	state = 2;	break;
	case '3':	case 'r':	case 'R':	state = 3;	break;
	default:							state = 2;	break;
	}

	main_keyboard->Bind_Key(key, state, argv[2]);
}

static int DisplayFPS = 0;
float system_currentFPS;

static CVar cv_quit("quit",			CFunc_Quit);
static CVar cv_exit("exit",			CFunc_Quit);
static CVar cv_setmode("setMode",	CFunc_SetMode);
static CVar cv_cdaudio("cdAudio",	CFunc_CDAudio);
static CVar cv_error("error",		CFunc_Error);
static CVar cv_bind("bind",			CFunc_BindKey);

static CVariv cv_dfps(&DisplayFPS,			"displayFPS");
static CVarfv cv_cfps(&system_currentFPS,	"currentFPS");
static CVariv cv_ock(&overrideCameraKeys,	"cameraKeys");
static CVarfv cv_ocs(&overrideCameraSpeed,	"camSpeed");
static CVarfv cv_ocr(&overrideCameraRot,		"camRot");
static CVariv cv_pm(&CVar_GL_PolygonMode,	"polygonMode",			CFunc_GL_PolygonMode);
static CVariv cv_cf(&CVar_GL_CullFace,		"cullFace",				CFunc_GL_CullFace);
static CVariv cv_dt(&CVar_GL_DepthTest,		"depthTest",			CFunc_GL_DepthTest);
static CVar4fv cv_cc(CVar_GL_ClearColor.v,	"clearColor",			CFunc_GL_ClearColor);

void Init_Foundation_CVars(void)
{
	static bool init_d = false;
	if (!init_d)
	{
		init_d = true;

		//set up the bindkey/cvar interface.  should we be doing this here?  sure, where else?
		main_keyboard->Bind_ExecFunc(CVar_Exec);
	}
}

bool Init_Foundation(void)
{
	//calculate useful constant values
	Calc_Constants();

	//initialize the console var system
	Init_CVars();

	//get the console up
	main_console = new M_Console();
	if (main_console && !main_console->Init(80,50))
	{
		delete main_console;
		main_console = NULL;
	}
	if (!main_console) return false;

	//create the foundation-specific console variables
	Init_Foundation_CVars();

	//opengl stuff - the system layer independant low level stuff
	Init_OpenGL();

	main_camera = new M_Camera();
	if (main_camera && !main_camera->Init())
	{
		delete main_camera;
		main_camera = NULL;
	}
	if (!main_camera) return false;
	VectorSet(&main_camera->position, 0,0,0);
	main_camera->znear = 1;
	main_camera->zfar = 10000;
	main_camera->Activate();

	//external call
	if (!Init_Application3D())
	{
		Error("Failed to init Application3D layer");
		return false;
	}

	return true;
}

void Foundation_OverrideCameraKeys(void)
{
	//quick and easy camera control - this is so commonly used im placing it in the foundation layer
	if (overrideCameraKeys)
	{
		char *keystate = main_keyboard->keystate;

		//interpret movement keys
		vector_t movement;
		VectorSet(&movement, 0,0,0);
		if (keystate[VkKeyScan('e')])	movement.x += overrideCameraSpeed;	//fwd			
		if (keystate[VkKeyScan('d')])	movement.x -= overrideCameraSpeed;	//back			
		if (keystate[VkKeyScan('s')])	movement.y += overrideCameraSpeed;	//left			
		if (keystate[VkKeyScan('f')])	movement.y -= overrideCameraSpeed;	//right			
		if (keystate[VkKeyScan('r')])	movement.z += overrideCameraSpeed;	//up			
		if (keystate[VkKeyScan('v')])	movement.z -= overrideCameraSpeed;	//down
		QuatRotateVector(&movement, &main_camera->angle, &movement);
		VectorAdd(&main_camera->position, &movement, &main_camera->position);
//		main_camera->position += RotateVector(movement, main_camera->angle);

		//interpret rotation keys
		scalar_t rx = 0, ry = 0, rz = 0;
		if (keystate[VkKeyScan('k')]) ry -= overrideCameraRot;	//up (x-)
		if (keystate[VkKeyScan('i')]) ry += overrideCameraRot;	//down (x+)
		if (keystate[VkKeyScan('j')]) rz += overrideCameraRot;	//left (y+)
		if (keystate[VkKeyScan('l')]) rz -= overrideCameraRot;	//right (y-)
		if (keystate[VkKeyScan('u')]) rx -= overrideCameraRot;	//roll left
		if (keystate[VkKeyScan('o')]) rx += overrideCameraRot;	//roll right
		if (rx || ry || rz)
		{
			quat_t rotation;
			if (rx)
			{
				AngleAxisToQuat(1,0,0,rx, &rotation);
				QuatMul(&main_camera->angle, &rotation, &main_camera->angle);
			}
			if (ry)
			{
				AngleAxisToQuat(0,1,0,ry, &rotation);
				QuatMul(&main_camera->angle, &rotation, &main_camera->angle);
			}
			if (rz)
			{
				AngleAxisToQuat(0,0,1,rz, &rotation);
				QuatMul(&main_camera->angle, &rotation, &main_camera->angle);
			}
			QuatUnit(&main_camera->angle, &main_camera->angle);

//			if (rx) main_camera->angle *= AngleAxisToQuat(Quat(1,0,0,rx));
//			if (ry) main_camera->angle *= AngleAxisToQuat(Quat(0,1,0,ry));
//			if (rz) main_camera->angle *= AngleAxisToQuat(Quat(0,0,1,rz));
//			main_camera->angle.Normalize();
		}
	}
}

void Update_Foundation(void)
{
	//calculate the framerate
	{
		//time_t?? instead of double??
		static double lasttime=-1,thistime, framecount=0;
		framecount++;

		thistime = main_timer->GetTime();
		if ((int)lasttime != (int)thistime)
		{
			system_currentFPS = (float)framecount / (float)(thistime - lasttime);
			if (DisplayFPS) main_console->Print("FPS: %f\n", system_currentFPS);
			lasttime = thistime;
			framecount = 0;
		}
	}

	if (m_foundation_use_camera)
	{
		//calculate OpenGL boundaries in 3space
		main_camera->CalculateFrustum();
		//reset camera matricies
		main_camera->TransformScene(CAMERA_RESET_PROJECTION | CAMERA_RESET_ROTATION | CAMERA_RESET_TRANSLATION);
	}

	//gather keystrokes / filter input to be sent to application layer
	main_console->PreUpdate();

//	if (m_foundation_use_camera)
//	{
		//see if we are supposed to allow for the quick hack camera input
		Foundation_OverrideCameraKeys();
//	}

	//external call
	Update_Application3D();

	//replace all previously filtered info
	main_console->PostUpdate();

	//display console final - draw atop all else
	main_console->Display();
}

void Shutdown_Foundation(void)
{
	//external call
	Shutdown_Application3D();

	if (main_camera)	{delete main_camera;	main_camera = NULL;		}
	if (main_console)	{delete main_console;	main_console = NULL;	}

	Shutdown_CVars();
}
