/*

    File: Console.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include <windows.h>
#include <stdio.h>
#include <assert.h>

#include "console.h"
#include "cvar.h"

#include "../m_system3d/main.h"
#include "../m_system3d/error.h"

#include "main.h"

//console cvars

void CFunc_Con_SetInfo(int argc, char **argv) {
	main_console->SetInfo(argc, argv);
}

void M_Console::SetInfo(int argc, char **argv)
{
	if (argc > 2)
	{
		if (!_stricmp(argv[1], "width"))
		{
			width = atoi(argv[2]);
		}
		else if (!_stricmp(argv[1], "height"))
		{
			height = atoi(argv[2]);
		}
		else if (!_stricmp(argv[1], "droptime"))
		{
			droptime = atof(argv[2]);
		}
		else if (!_stricmp(argv[1], "droptype"))
		{
			droptype = atoi(argv[2]);
		}
		else if (!_stricmp(argv[1], "idlevis"))
		{
			idleVisible = (atoi(argv[2]) != 0);
		}
		else if (!_stricmp(argv[1], "idledrop"))
		{
			idleDropdown = atoi(argv[2]);
		}
	}

	Print("  Width:   %d\n", width);
	Print("  Height:  %d\n", height);
	Print("  DropTime:%f\n", droptime);
	Print("  DropType:%d\n", droptype);
	Print("  IdleVis: %s\n", idleVisible ? "true" : "false");
	Print("  IdleDrop:%d\n", idleDropdown);
}

void CFunc_ConsoleFont(int argc, char **argv) {
	if (argc < 2) return;
	Texture *font = main_console->font;
	if (!font) return;

	font->Destroy();
	font->Create(argv[1]);
}

//console methods

#include <gl/gl.h>
#include "random.h"

//construction / creation
M_Console::M_Console()
{
	memset(this, 0, sizeof(this));	//right?

	font = NULL;

	ClearInput();
	memset(textbuffer, 0, sizeof(textbuffer));

	isActive = false;
}

#define CONSOLE_TYPE_COUNT 4

static CVar cv_console("Console",		CFunc_Con_SetInfo);
static CVar cv_consolefont("ConsoleFont",	CFunc_ConsoleFont);

bool M_Console::Init(int w, int h)
{
	width = w;
	height = h;

	droptype = 3;	//my fav
	droptime = 0.5;
	idleDropdown = 4;

	idleVisible = true;

	memset(&inputcmd[0][0], 0, sizeof(inputcmd));
	last_prev_cmd = 0;

	font = new Texture();
	if (!font) return false;

	//do this for the sake of apps w/o access to the font file
//	if (!font->Create("../M_Foundation/ConsoleData/Font.bmp"))
	font->Create("ConsoleData/Font.bmp");

//	new M_CVar(0,	"Console",		CFunc_Con_SetInfo,	(void*)this);
//	new M_CVar(0,	"ConsoleFont",	CFunc_ConsoleFont,	(void*)font);

	return true;
}

//destruction

void M_Console::Kill(void)
{
	if (font) delete font;
	font = NULL;
}

//update

static M_KeyboardHandler	pushKeyboardHandler;
static bool					usePushKeyboardHandler;

void M_Console::PreUpdate(void)
{
	usePushKeyboardHandler = false;

	//cycle through keydown queue - execute keys as we go.
	//if after all of them are computed, the console is up
	//then push the keyboard onto a temporary keyboard
	//and clear all its stats - thus negating any use by
	//the Application layer

	//after application layer execution, push the keyboard contents back
	//during the PostUpdate

	for (int a = main_keyboard->firstkeydown; a != main_keyboard->lastkeydown; a = (a + 1) & (KBH_KEYBUF_SIZE-1))
		KeyDown(main_keyboard->keydownqueue[a]);

	//push keyboard contents onto temporary keybaord
	if (isActive)
	{
		//this is only a valid command
		//if the main keyboard handler object is an object of the
		//M_KeyboardHandler class (not of a child class) *AND* the
		//main keyboard handler object does not require any externally
		//allocated memory (ie - all arrays hard-coded into the class)

		usePushKeyboardHandler = true;
		
		memcpy(&pushKeyboardHandler, main_keyboard, sizeof(M_KeyboardHandler));
		
		main_keyboard->Reset();
	}
}

void M_Console::PostUpdate(void)
{
	if (usePushKeyboardHandler)
		memcpy(main_keyboard, &pushKeyboardHandler, sizeof(M_KeyboardHandler));
}

bool M_Console::KeyDown(int key)
{
	if (key == VkKeyScan('`'))
	{
		Toggle();

		if (isActive)
		{
			//reset the console state
			ClearInput();
			droptype %= CONSOLE_TYPE_COUNT;			// = MRand() % CONSOLE_TYPE_COUNT;
			dropstart = main_timer->GetTime();
		}

		return true;	//true means we interpreted the key
	}

	if (isActive)
	{
		//hack for cycling thru prev cmds - if we dont hit an 'up' then reset the buffer for next swing
		if (key != VK_UP && key != VK_DOWN) last_prev_cmd = 0;


		if (key == VK_RETURN)
		{
			//push back all prev cmds
			for (int i = PREV_CMD_MAX-2; i >= 0; i--)
				memcpy(&inputcmd[i+1][0], &inputcmd[i][0], CMD_LENGTH);
			//out the cmd
			Print("]%s\n", &inputcmd[0][0]);
			//parse the current command buffer
			CVar_Exec(&inputcmd[0][0]);
			//and clear it
			ClearInput();
			return true;
		}
		else if (key == VK_SPACE)
		{
			AddToInput(' ');
			return true;
		}
		else if (key == VK_BACK)
		{
			AddToInput(8);
			return true;
		}
		else if (key == VK_UP)
		{
			last_prev_cmd++;
			if (last_prev_cmd >= PREV_CMD_MAX) last_prev_cmd = PREV_CMD_MAX - 1;

			inkey_next = strlen(&inputcmd[last_prev_cmd][0]);
			memcpy(&inputcmd[0][0], &inputcmd[last_prev_cmd][0], inkey_next+1);
		}
		else if (key == VK_DOWN)
		{
			last_prev_cmd--;
			if (last_prev_cmd < 0) last_prev_cmd = 0;

			inkey_next = strlen(&inputcmd[last_prev_cmd][0]);
			memcpy(&inputcmd[0][0], &inputcmd[last_prev_cmd][0], inkey_next+1);
		}
		else
		{
			if (main_keyboard->keystate[VK_SHIFT] ||
				main_keyboard->keystate[VK_LSHIFT] ||
				main_keyboard->keystate[VK_RSHIFT])
					key |= 0x100;

			//replace this with a key mapping function
			for (int ch = 32; ch < 128; ch++)
			{
				if (VkKeyScan(ch) == key)
				{
					AddToInput((char)ch);
					return true;
				}
			}
		}
	}

	return false;
}

void M_Console::AddToInput(char key)
{
	//backspace
	if (key == 8)
	{
		if (inkey_next > 0)
		{
			inkey_next--;
			inputcmd[0][inkey_next] = 0;
		}
		return;
	}

	//any other key...

	//make sure we have room
	if (inkey_next >= CMD_LENGTH-1) return;

	//add the key to the buffer
	inputcmd[0][inkey_next] = key;
	inkey_next++;

	//make sure we're still null-terminated.
	inputcmd[0][inkey_next] = 0;
}
void M_Console::ClearInput(void)
{
	memset(&inputcmd[0][0], 0, CMD_LENGTH);
	inkey_next = 0;
}

void M_Console::Toggle(void)
{
	isActive = !isActive;
}

//sets whether the console is visible when inactive
void M_Console::SetIdleVisible(bool isvis)
{
	idleVisible = isvis;
}

// output

//and the per-object function
void M_Console::Print(const char *_format, ...)
{
	char text[1024];
	va_list ap;

	va_start(ap, _format);
	_vsnprintf(text, sizeof(text), _format, ap);
	va_end(ap);

	AddString(text);
}

class CConsoleLogger {
public:

	CConsoleLogger();
	~CConsoleLogger();

	void Enable(bool e);
	void AddString(char *s);

	int consoleLogging;
	FILE *consoleFile;
};

#include <string>

static CConsoleLogger consoleLogger;
static std::string consoleFilename = "console.txt";

static void CFunc_consoleLogging(int argc, char **argv) {

	if (argc > 1) {
		consoleFilename = argv[1];
		main_console->Print("changing console filename to %s\n", consoleFilename.c_str());
	}

	consoleLogger.Enable(!consoleLogger.consoleLogging);
}
static CVarw cv_consoleLogging(0, "log", CFunc_consoleLogging);


CConsoleLogger::CConsoleLogger() {
	consoleLogging = 0;
	consoleFile = NULL;
}

CConsoleLogger::~CConsoleLogger() {
	Enable(false);
}

void CConsoleLogger::Enable(bool e) {

	if (!e) {
		if (consoleFile) {
			fclose(consoleFile);
			consoleFile = NULL;
		}
		
		if (main_console) main_console->Print("Logging Disabled\n");

	} else {
		
		if (main_console) main_console->Print("Logging Enabling...\n");

		if (!consoleFile) {
			//clear it once...
			consoleFile = fopen(consoleFilename.c_str(), "w");
			if (consoleFile) {
				fclose(consoleFile);
				consoleFile = fopen(consoleFilename.c_str(), "a");
			}
		}
		if (!consoleFile) {
			//tell our cvar that we're down
			consoleLogging = 0;
		}
	}
}

void CConsoleLogger::AddString(char *s) {
	if (consoleFile) {
		fwrite(s, strlen(s), 1, consoleFile);
	}
}

void M_Console::AddString(char *append_data) {

	CCriticalSectionLock lock(&cs);
//	cs.lock();

	consoleLogger.AddString(append_data);

	int append_data_len = strlen(append_data);

	if (!append_data) {
//		cs.unlock();
		return;
	}
	if (!*append_data) {
//		cs.unlock();
		return;
	}

	int buffer_data_len = strlen(textbuffer);
	if (buffer_data_len + append_data_len > sizeof(textbuffer) - 1) {
		memcpy(	textbuffer, &textbuffer[append_data_len], buffer_data_len - append_data_len);

		textbuffer[buffer_data_len - append_data_len] = 0;
	}
	strcat(textbuffer, append_data);

//	cs.unlock();
}

//display
void M_Console::Display(void)
{
	int current_dropdown = height-1;

	if (!isActive)
	{
		if (!idleVisible) return;
		current_dropdown = idleDropdown;
	}

	//0 - console just dropped
	//1 - console set in position
	timefrac = (float)(main_timer->GetTime() - dropstart) / (float)droptime;
	if (timefrac > 1) timefrac = 1;
	if (timefrac < 0) timefrac = 0;

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	glOrtho(0,width,height,0,-1000,1000);

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();


	//distort this according to time_frac
	switch (droptype)
	{
	case 1:
		glTranslatef((float)width/2.f, (float)height/2.f, 0);
		glScalef(timefrac, timefrac, 1.f);
		glRotatef(1000 - 1000 * timefrac, 0,0,1);
		glTranslatef(-(float)width/2.f, -(float)height/2.f, 0);
		break;
	case 2:
		{
			if (timefrac < 0.5)
				glScalef(.2f, 2*timefrac, 1.f);
			else
				glScalef(1.6f*(timefrac-.5f) + .2f, 1.f, 1.f);
		}
		break;
	}

	glPushAttrib(GL_ALL_ATTRIB_BITS);

	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);
	glDisable(GL_LIGHTING);
	glDisable(GL_ALPHA_TEST);
	
	int glMaxClipPlanes;
	glGetIntegerv(GL_MAX_CLIP_PLANES, &glMaxClipPlanes);
	for (int i = 0; i < glMaxClipPlanes; i++)
		glDisable(GL_CLIP_PLANE0 + i);

	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glEnable(GL_BLEND);

	//draw a shaded background
#if 0
	if (isActive)
	{

		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glBindTexture(GL_TEXTURE_2D, 0);
		glColor4f(0,0,0,.75f);
		glBegin(GL_QUADS);
		glVertex2f(0,0);
		glVertex2f((float)width,0);
		glVertex2f((float)width,(float)height);
		glVertex2f(0,(float)height);
		glEnd();
	}
#endif

	if (font) font->Set();

	//overlay text
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glColor4f(1,1,1,0.75f);

	//print the current cmd being typed
	glTranslatef(0,(float)current_dropdown,0);
	
	static char inputcmd_display[CMD_LENGTH+1];
	memcpy(&inputcmd_display[1], &inputcmd[0][0], CMD_LENGTH);
	inputcmd_display[0] = ']';

	DisplayLine(inputcmd_display, strlen(inputcmd_display));

	//print the text in the console
	char *start, *end;
	for (end = textbuffer; *end; end++)
		if (end >= textbuffer + sizeof(textbuffer))
			break;
	if (!(*end)) end--;		//if we break'd because of a null terminator then backtrack over it

	do {
		for (start = end;					//start at the last line and move back
			*start >= 32 &&					//stop moving back if we hit a space
			(int)(end - start) < width &&	//or if we go past the width of the console
			start >= textbuffer;			//or if we pass the start of the text buffer
			start--);

		glTranslatef(0,-1,0);
		DisplayLine(&start[1], end-start);
		
		for (end = start-1; *end < 32 && end >= textbuffer; end--);

	} while (end >= textbuffer);

	glPopAttrib();

	glPopMatrix();		//pop the modelview matrix
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();		//pop the projection matrix
	glMatrixMode(GL_MODELVIEW);	//and set the current matrix back to modelview
}

#include <math.h>
#include "const.h"
void M_Console::DisplayLine(char *p, int len)
{
	for (int a = 0; a < len; a++)
	{
		int tx = (*(unsigned char *)p & 15);
		int ty = (*(unsigned char *)p >> 4) - 2;

		float vtx[4][2] = {
			{(float)a,		0},
			{(float)(a+1),	0},
			{(float)(a+1),	1},
			{(float)a,		1}};

		if (droptype == 3)
			for (int v = 0; v < 4; v++)
				if ((vtx[v][0] / (float)width) < (1.f - timefrac)) vtx[v][0] = 0;

		glBegin(GL_QUADS);
		glTexCoord2f((float)tx/16.f, (float)(ty)/16.f);			glVertex2fv(vtx[0]);
		glTexCoord2f((float)(tx+1)/16.f, (float)(ty)/16.f);		glVertex2fv(vtx[1]);
		glTexCoord2f((float)(tx+1)/16.f, (float)(ty+1)/16.f);	glVertex2fv(vtx[2]);
		glTexCoord2f((float)tx/16.f, (float)(ty+1)/16.f);		glVertex2fv(vtx[3]);
		glEnd();

		p++;
	}
}
