/*

    File: Texture.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#ifndef M_FOUNDATION_TEXTURES_H
#define M_FOUNDATION_TEXTURES_H

#include "chain.h"

//TODO: Combine 'Fractal' and all image loading functions of 'Texture' into a new unique module

class Texture : public Chain {

//public:
//	friend Texture *GetTexture(LinkedList *p, char *title);

// ********** CONSTRUCTION/DESTRUCTION ********** 
public:
	Texture() {Reset();}					//zero all the vars
//unlink an Texture from the list
	~Texture() {Destroy();}

	void Destroy(void);
private:
	void Reset(void);

// ********** SETTING CURRENT TEXTURE ********** 

public:
	void Set(void);

// ********** MODIFYING TEXTURE ********** 
public:
	void SetWrap(int mode_s, int mode_t);
	void SetFilter(int magnification, int minification);

// ********** TEXTURE PRE-CREATION ********** 
public:
	bool CreateEmpty(int width, int height, int internal_format, int external_format);
	void UpdateData(int width, int height, int internal_format, int external_format, void *src);

// ********** TEXTURE ARRAY EXTRACTION ********** 
public:
	bool Extract(int width, int height, int internal_format, int external_format, const unsigned char *ptr, int colskip, int rowskip);

// ********** TEXTURE IMAGE LOADING ********** 
public:
	bool Create(const char *fn, bool mipmap = true, int format = -1, bool border = false);		//load the texture - return the texture ID
	unsigned int texture_id;

	char title[64];

private:
	void InitOpenGLTexture(bool mipmap);

	unsigned char *LoadData(const char *fn, bool border = false);
	unsigned char *ConvertData(unsigned char *data, int flags);
	unsigned char *LoadBMP(const char *filename, bool border = false);
	unsigned char *LoadTGA(const char *filename, bool border = false);
	unsigned char *LoadJPEG(const char *filename, bool border = false);

public:		//this structure is a mess.
	unsigned int width, height, bytes_per_pixel;
private:
	unsigned int flags;
	int type;		//either TEXTURE_1D, TEXTURE_2D, TEXTURE_CUBE_MAP_ARB, or TEXTURE_3D

// ********** CUBE MAP TEXTURE ********** 
public:
	bool CreateCubeMap(const char *fn[7], bool mipmap = true, int format = -1);
};

//used by image.  maybe moved there later.
int GL_Type_to_BPP(int type);
int GL_Format_to_Components(int format);

#endif