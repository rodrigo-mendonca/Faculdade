/*

    File: Fractal.cpp
	
    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include <math.h>
#include <windows.h>	//NULL

#include "fractal.h"
#include "random.h"

#define fInf (-(float)log(0))

#include <stdlib.h>

//temporary: for fractal terrain
float Fractal_pickvalue(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4);
float Fractal_getval(int x, int y);
bool Fractal_set(int x, int y, float val, bool check);
void Fractal_subdivide(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4);


//****************** TEMPORARY MAP GENERATION ****************** 

static int fractal_width = 0;
static int fractal_height = 0;
static int fractal_step_size = 0;
static float *fractal_data = NULL;

float Fractal_pickvalue(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4)
{
	float average;
	float area, proportion, variation;

	area = 0.5f * (float)(x1*y2 - x2*y1 + x2*y3 - x3*y2 + x3*y4 - x4*y3 + x4*y1 - x1*y4);
	if (area < 0) area = -area;

	proportion = area / (float)(fractal_width*fractal_height);
	proportion = (float)sqrt(proportion);
	proportion *= (float)3.0;						//PROPORTION_SCALAR

	variation = proportion*(float)MCRand();
	
	average = (Fractal_getval(x1,y1) +
				Fractal_getval(x2,y2) +
				Fractal_getval(x3,y3) +
				Fractal_getval(x4,y4)) * 0.25f;
	average += variation;

	return average;
}

float Fractal_getval(int x, int y)
{
	while (x < 0) x += fractal_width;
	while (y < 0) y += fractal_height;
	x %= fractal_width;
	y %= fractal_height;

	float *f = (float *)((char *)fractal_data + (x + y * fractal_width) * fractal_step_size);

	return *f;
}

bool Fractal_set(int x, int y, float val, bool check = true)
{
	while (x < 0) x += fractal_width;
	while (y < 0) y += fractal_height;
	x %= fractal_width;
	y %= fractal_height;

	if (check && (Fractal_getval(x,y) != -fInf)) return false;

	float *f = (float *)((char *)fractal_data + (x + y * fractal_width) * fractal_step_size);

	*f = val;

	return true;
}

void Fractal_subdivide(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4)
{
	/*
	x1,y1	x2,y2

	x4,y4	x3,y3
	*/

	int xmid1_2, ymid1_2, xmid4_3, ymid4_3, xmid2_3, ymid2_3, xmid1_4, ymid1_4;

	xmid1_2 = x1 + (x2 - x1)/2;
	ymid1_2 = y1 + (y2 - y1)/2;
	xmid4_3 = x4 + (x3 - x4)/2;
	ymid4_3 = y4 + (y3 - y4)/2;
	xmid2_3 = x2 + (x3 - x2)/2;
	ymid2_3 = y2 + (y3 - y2)/2;
	xmid1_4 = x1 + (x4 - x1)/2;
	ymid1_4 = y1 + (y4 - y1)/2;

/*
center = ydist * ((point1 + xdist * delta1_2) - (point4 + xdist * delta4_3)) + (point1 + xdist * delta1_2)
*/
	float xdist = 0.5f + MCRand() * 0.25f;
	float ydist = 0.5f + MCRand() * 0.25f;

	float xcenter = ydist *  ((x4 + xdist * (x3 - x4)) - (x1 + xdist * (x2 - x1)))
							+ (x1 + xdist * (x2 - x1));
	float ycenter = ydist *  ((y4 + xdist * (y3 - y4)) - (y1 + xdist * (y2 - y1)))
							+ (y1 + xdist * (y2 - y1));

	int xmid = (int)xcenter, ymid = (int)ycenter;

	float midval = (Fractal_getval(x1,y1) +
				Fractal_getval(x2,y2) + 
				Fractal_getval(x3,y3) + 
				Fractal_getval(x4,y4)) * 0.25f;

	Fractal_set(xmid,ymid,midval);
	Fractal_set(xmid1_2,ymid1_2,Fractal_pickvalue(x1,y1,x2,y2,x3,y3,x4,y4));
	Fractal_set(xmid1_4,ymid1_4,Fractal_pickvalue(x1,y1,x2,y2,x3,y3,x4,y4));
	Fractal_set(xmid4_3,ymid4_3,Fractal_pickvalue(x1,y1,x2,y2,x3,y3,x4,y4));
	Fractal_set(xmid2_3,ymid2_3,Fractal_pickvalue(x1,y1,x2,y2,x3,y3,x4,y4));

	float area = 0.5f * (float)(x1*y2 - x2*y1 + x2*y3 - x3*y2 + x3*y4 - x4*y3 + x4*y1 - x1*y4);
	if (area < 0) area = -area;
	if (area <= 1.f) return;

	Fractal_subdivide(	x1,y1,
				xmid1_2,ymid1_2,
				xmid,ymid,
				xmid1_4,ymid1_4);
	Fractal_subdivide(	xmid1_2,ymid1_2,
				x2,y2,
				xmid2_3,ymid2_3,
				xmid,ymid);
	Fractal_subdivide(	xmid1_4,ymid1_4,
				xmid,ymid,
				xmid4_3,ymid4_3,
				x4,y4);
	Fractal_subdivide(	xmid,ymid,
				xmid2_3,ymid2_3,
				x3,y3,
				xmid4_3,ymid4_3);

}

bool Fractal_Create(float *data, float min, float max, int width, int height, int step_size, int filter_level)
{
	int a, a_end, a_step;
	int b, b_end, b_step;

	//minimum_alt = -log(0);	//inf
	//maximum_alt = log(0);	//-inf

	fractal_width = width;
	fractal_height = height;
	fractal_step_size = step_size;
	fractal_data = data;


	for (b = 0; b < fractal_height; b++)
	{
		for (a = 0; a < fractal_width; a++)
		{
			Fractal_set(a,b,-fInf, false);
		}
	}

	int xhalf = fractal_width>>1, yhalf = fractal_height>>1;

//	xhalf = (int)((float)(fractal_width-1) * MFRand());
//	yhalf = (int)((float)(fractal_height-1) * MFRand());


	Fractal_set(0,0,MFRand());
	Fractal_set(xhalf,0,MFRand());
	Fractal_set(0,yhalf,MFRand());
	Fractal_set(xhalf,yhalf,MFRand());

	Fractal_subdivide(0,	0,		xhalf,			0,		xhalf,			yhalf,			0,		yhalf);
	Fractal_subdivide(xhalf,0,		fractal_width,	0,		fractal_width,	yhalf,			xhalf,	yhalf);
	Fractal_subdivide(0,	yhalf,	xhalf,			yhalf,	xhalf,			fractal_height,	0,		fractal_height);
	Fractal_subdivide(xhalf,yhalf,	fractal_width,	yhalf,	fractal_width,	fractal_height,	xhalf,	fractal_height);

	//filter out remaining empty spaces on the map
	for (b = 0; b < fractal_height; b++)
	{
		for (a = 0; a < fractal_width; a++)
		{
			if (Fractal_getval(a,b) != -fInf) continue;

			float val, div;
			val =  div = 0.f;
			for (int rx = a - 1; rx <= a + 1; rx++)
			{
				for (int ry = b - 1; ry <= b + 1; ry++)
				{
					if (Fractal_getval(rx,ry) == -fInf) continue;

					int dist_2 = (rx-a)*(rx-a) + (ry-b)*(ry-b);
					float gaussian = (float)exp(-dist_2);

					val = val + Fractal_getval(rx,ry) * gaussian;
					div = div + gaussian;

				}
			}
			if (div != 0.f)
			{
				val /= div;
				Fractal_set(a,b,val, false);
			}
		}
	}


	//smoothing filter - lets see how good this works. . .
	//one error:  tiles that have been filtered are considered unfiltered to the
	//tiles that still have to be filtered
	for (int filter = 0; filter < filter_level; filter++)
	{
		if (MRand()&1)
		{
			b = 0;
			b_end = fractal_height-1;
			b_step = 1;
		}
		else
		{
			b = fractal_height-1;
			b_end = 0;
			b_step = -1;
		}

		for (; b != b_end+b_step; b+=b_step)
		{
			if (MRand()&1)
			{
				a = 0;
				a_end = fractal_width-1;
				a_step = 1;
			}
			else
			{
				a = fractal_width-1;
				a_end = 0;
				a_step = -1;
			}

			for (; a != a_end + a_step; a+=a_step)
			{
				float val, div;
				val =  div = 0;
				for (int rx = a - 1; rx <= a + 1; rx++)
				{
					for (int ry = b - 1; ry <= b + 1; ry++)
					{
						int dist_2 = (rx-a)*(rx-a) + (ry-b)*(ry-b);
						float gaussian = (float)exp(-dist_2);

						val += Fractal_getval(rx,ry) * gaussian;
						div += gaussian;

					}
				}
				if (div != 0.f)
				{
					val /= div;
					Fractal_set(a,b,val, false);
				}
			}
		}
	}

	//resize map to min/max
	float cur_min = fInf, cur_max = -fInf;
	for (b = 0; b < fractal_height; b++)
	{
		for (a = 0; a < fractal_width; a++)
		{
			float cv = Fractal_getval(a,b);
			if (cv < cur_min) cur_min = cv;
			if (cv > cur_max) cur_max = cv;
		}
	}
	for (b = 0; b < fractal_height; b++)
	{
		for (a = 0; a < fractal_width; a++)
		{
			float cv = (Fractal_getval(a,b) - cur_min) / (cur_max - cur_min);
			cv *= (max - min);
			cv += min;
			Fractal_set(a,b, cv, false);
		}
	}

	return true;
}



// ******************* THROWN IN OUTTA NOWHERE ******************* 

bool Blur_Array(float *data, float *blend, int width, int height, int data_step_size, int blend_step_size)
{
	int filter_level = 0;

	int a, a_end, a_step;
	int b, b_end, b_step;

	fractal_width = width;
	fractal_height = height;

	fractal_step_size = blend_step_size;
	fractal_data = blend;
	for (b = 0; b < fractal_height; b++)
	{
		for (a = 0; a < fractal_width; a++)
		{
			int ival = (int)Fractal_getval(a,b);
			if (ival > filter_level) filter_level = ival;
		}
	}

	for (int filter = 0; filter < filter_level; filter++)
	{
		if (MRand()&1)
		{
			b = 0;
			b_end = fractal_height-1;
			b_step = 1;
		}
		else
		{
			b = fractal_height-1;
			b_end = 0;
			b_step = -1;
		}

		for (; b != b_end+b_step; b+=b_step)
		{
			if (MRand()&1)
			{
				a = 0;
				a_end = fractal_width-1;
				a_step = 1;
			}
			else
			{
				a = fractal_width-1;
				a_end = 0;
				a_step = -1;
			}

			for (; a != a_end + a_step; a+=a_step)
			{
				fractal_step_size = blend_step_size;
				fractal_data = blend;
				float blendval = Fractal_getval(a,b);

				//grab the current blend level for the area
				if (blendval < filter) continue;

				fractal_step_size = data_step_size;
				fractal_data = data;

				float val, div;
				val =  div = 0;
				for (int rx = a - 1; rx <= a + 1; rx++)
				{
					for (int ry = b - 1; ry <= b + 1; ry++)
					{
						int dist_2 = (rx-a)*(rx-a) + (ry-b)*(ry-b);
						float gaussian = (float)exp(-dist_2);

						val += Fractal_getval(rx,ry) * gaussian;
						div += gaussian;

					}
				}
				if (div != 0.f)
				{
					val /= div;
					Fractal_set(a,b,val, false);
				}
			}
		}
	}

	return true;
}

bool Normalize_Array(float *data, int count, int step_size)
{
	char *cp;
	float *fp;
	int a;

	//resize map to min/max
	float cur_min = fInf, cur_max = -fInf;

	cp = (char *)data;
	for (a = 0; a < count; a++) {
		fp = (float *)cp;
		if (*fp < cur_min) cur_min = *fp;
		if (*fp > cur_max) cur_max = *fp;
		cp += step_size;
	}
	cp = (char *)data;
	for (a = 0; a < count; a++) {
		fp = (float *)cp;
		*fp = (*fp - cur_min) / (cur_max - cur_min);
		cp += step_size;
	}

	return true;
}

bool Scale_Array(float *data, int count, int step_size, float scale)
{
	char *cp;
	float *fp;

	cp = (char *)data;
	for (; count > 0; count--)
	{
		fp = (float *)cp;
		*fp *= scale;
		cp += step_size;
	}

	return true;
}

bool Add_Array(float *data, int count, int step_size, float add)
{
	char *cp;
	float *fp;

	cp = (char *)data;
	for (; count > 0; count--)
	{
		fp = (float *)cp;
		*fp += add;
		cp += step_size;
	}

	return true;
}
