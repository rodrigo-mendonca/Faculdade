/*

    File: Image.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include <windows.h>
#include <gl/gl.h>
#include <stdio.h>

#include "image.h"
#include "main.h"

void Image::Reset(void) {
	memset(this, 0, sizeof(Image));
}

void Image::Unload(void) {
	//unalloc / shutdown all locals
	if (image) free(image);
	//and reset
	Reset();
}

enum {
	EXTENSION_UNKNOWN,
	EXTENSION_BMP,
	EXTENSION_TGA,
};

static int GetExtension(const char *filename) {
	//set our method vars
	char ext[4] = {0};
	int i = strlen(filename);

	//copy over the file extension
	memcpy(ext, &filename[i-3], 3);

	//properly case the file extension
	if (ext[0] >= 'A' && ext[0] <= 'Z') ext[0] += 'a' - 'A';
	if (ext[1] >= 'A' && ext[1] <= 'Z') ext[1] += 'a' - 'A';
	if (ext[2] >= 'A' && ext[2] <= 'Z') ext[2] += 'a' - 'A';

	if (!memcmp(ext, "bmp", 3)) return EXTENSION_BMP;
	if (!memcmp(ext, "tga", 3)) return EXTENSION_TGA;

	return EXTENSION_UNKNOWN;
}

bool Image::Load(const char *filename) {
	bool success = false;
	switch (GetExtension(filename)) {
	case EXTENSION_BMP:
		success = LoadBMP(filename);
		break;
	case EXTENSION_TGA:
		success = LoadTGA(filename);
		break;
	default:
		main_console->Print("Image::Load(): unknown extension type on file!");
		break;
	}
	if (!success) {
		Unload();
		return false;
	}
	return true;
}

bool Image::LoadBMP(const char *filename) {

//open the file
	FILE *file = fopen(filename, "rb");
	if (!file) {
		main_console->Print("I couldn't open the file %s\n", filename);
		return false;
	}

//read the BITMAPFILEHEADER struct
	BITMAPFILEHEADER	bmfh;

	if (!fread(&bmfh, sizeof(bmfh), 1, file)) {
		fclose(file);
		main_console->Print("I Couldn't Read The Bitmap File Header.  This Bitmap Is Probably Corrupt");
		return false;
	}

	if (bmfh.bfType != 0x4D42) {
		fclose(file);
		main_console->Print("The Bitmap ID Was Incorrect.  This Bitmap Is Probably Corrupt");
		return false;
	}

//alloc mem to store intermediate data, between the bmfh and the bitmap bits

	unsigned int src_extraDataSize = bmfh.bfOffBits - sizeof(bmfh);

	char *src_extraData;
	if (!(src_extraData = (char *)malloc(src_extraDataSize))) {
		fclose(file);
		main_console->Print("I Couldnt Load The File Header.  Unable to Alloc %u Bytes of Memory", src_extraDataSize);
		return false;
	}
	
	if (!fread(src_extraData, src_extraDataSize, 1, file)) {
		fclose(file);
		free(src_extraData);
		main_console->Print("I couldn't read the bitmap file extra header.\n");
		return false;
	}

//and gather the useful stats...
	BITMAPINFOHEADER *bmih = (BITMAPINFOHEADER *)src_extraData;
	BITMAPCOREHEADER *bmch = (BITMAPCOREHEADER *)src_extraData;

	//use the bmih
	if (src_extraDataSize < bmih->biSize) {
		fclose(file);
		free(src_extraData);
		main_console->Print("there wasnt enuf room for the next header\n");
		main_console->Print("\tsrc_extraDataSize = %d\n", src_extraDataSize);
		main_console->Print("\tbmih->biSize = %d\n", bmih->biSize);
		return false;
	}

	int src_bitsPerPixel;
	int src_palIndexCount;
	int src_compression;
	if (bmih->biSize == 12) {
		//use the bmch

		this->width = bmch->bcWidth;
		this->height = bmch->bcHeight;
		src_bitsPerPixel = bmch->bcBitCount;
		src_palIndexCount = 0;
		src_compression = 0;
	} else if (bmih->biSize == 40) {
		//use the bmih

		this->width = bmih->biWidth;
		this->height = bmih->biHeight;
		src_bitsPerPixel = bmih->biBitCount;
		src_palIndexCount = bmih->biClrUsed;
		src_compression = bmih->biCompression;
	} else {
		//corrupt bitmap

		fclose(file);
		free(src_extraData);
		main_console->Print( "The Bitmap File Header had an Invalid Size of %d.  This Bitmap Is Probably Corrupt", bmih->biSize);
		return false;
	}

	switch (src_compression) {
	case BI_RGB:
		break;					//only one we support right now
	case BI_RLE4:
	case BI_RLE8:
	case BI_BITFIELDS:
	default:
		free(src_extraData);
		fclose(file);
		main_console->Print("This Image is RLE Compressed.  This Does Not Yet Support RLE Compressed BMP files.");
		return false;
	}

	int tex_bytes_per_pixel = 0;
	switch (src_bitsPerPixel) {
	case 1:
	case 4:
	case 8:
	case 16:
	case 24:
	case 32:
		tex_bytes_per_pixel = 3;		//silly windows, bitmaps cant hold alpha values
		break;
	default:
		free(src_extraData);
		fclose(file);
		main_console->Print("The Bits Per Pixel Is %d, An Unsupported Value.", src_bitsPerPixel);
		return false;
	}

//determine how much extra data is remaining for the palette
	int src_palDataSize = src_extraDataSize - sizeof(bmfh) - bmih->biSize;

//allocate the dest image
	int dest_imageSize = this->width * this->height * tex_bytes_per_pixel;
	this->image = malloc(dest_imageSize);

	if (!this->image) {
		free(src_extraData);
		fclose(file);
		main_console->Print("I Couldnt Load the Image.  Unable to Allocate %u Bytes of Memory.", dest_imageSize);
		return false;
	}

//when exactly do we need to load a palette?
//is it only for 1,4,8-bpp files?
	unsigned char *src_palette = NULL;
	if (src_bitsPerPixel <= 8) {			//if an offset to the image exists...
		//if (palIndexCount > 256) then we cant grab all the indecies
		if (src_palIndexCount == 0) src_palIndexCount = (1 << src_bitsPerPixel);
		//why in the world...
		if (src_palIndexCount > 256) src_palIndexCount = 256;
		src_palette = (unsigned char *)bmih + (short)bmih->biSize;
	}

	//for reading the rows of the bitmap and for calc'ing the row offset
	unsigned char *rowPtr = NULL;
	unsigned int rowSize = this->width * src_bitsPerPixel;
	rowSize = (rowSize>>3) + !!(rowSize & 7);

	//waste of space - thank the people at microsoft for this idea - the row offset
	unsigned int rowOffset = rowSize & 3;
	if (rowOffset)	rowOffset = 4 - rowOffset;

	//used for indexed bitmaps:
	unsigned char curByte;
	int current_bit_offset = 8 - src_bitsPerPixel;
	int pixels_per_byte = 8 / src_bitsPerPixel;
	int pixel_bitmask = (1 << src_bitsPerPixel) - 1;
	int index;

	rowPtr = (unsigned char *)this->image;
	for (int y = 0; y < (int)this->height; y++) {
		//load the poop as indexed, then convert it from the palette
		if (src_bitsPerPixel <= 8) {
			//load these per-byte and convert them as we go
			for (int x = 0; x < (int)this->width; x++) {
				if ((x % pixels_per_byte) == 0) {
					current_bit_offset = 8 - src_bitsPerPixel;
					if (!fread(&curByte, 1, 1, file)) {
						free(src_extraData);
						fclose(file);
						main_console->Print("There Was An Error Reading Image Byte <%d,%d>", x, y);
						return false;
					}

					index = (curByte >> current_bit_offset) & pixel_bitmask;
					current_bit_offset -= src_bitsPerPixel;
					memcpy(rowPtr, &src_palette[index<<2], tex_bytes_per_pixel);
				} else {
					index = (curByte >> current_bit_offset) & pixel_bitmask;
					current_bit_offset -= src_bitsPerPixel;
					memcpy(rowPtr, &src_palette[index<<2], tex_bytes_per_pixel);
				}
				rowPtr += tex_bytes_per_pixel;
			}
		} else {	//load the poop as true color
			for (int x = 0; x < (int)this->width; x++) {
				int read_pixel;
				unsigned int src_bytesPerPixel = src_bitsPerPixel>>3;
				if (!fread(&read_pixel, src_bytesPerPixel, 1, file)) {
					free(src_extraData);
					fclose(file);
					main_console->Print("There Was An Error Reading Image Pixel <%d,%d>", x, y);
					return false;
				}
				switch (src_bytesPerPixel) {
				case 2:
					//expand
					rowPtr[0] = ((read_pixel >> 5*0) & ((1<<5)-1)) << (8-5);
					rowPtr[1] = ((read_pixel >> 5*1) & ((1<<5)-1)) << (8-5);
					rowPtr[2] = ((read_pixel >> 5*2) & ((1<<5)-1)) << (8-5);
					break;
				case 3:
				case 4:
					memcpy(rowPtr, &read_pixel, 3);
					break;
				}
				rowPtr += tex_bytes_per_pixel;
			}
		}

		if (rowOffset) {
			if (fseek(file, rowOffset, SEEK_CUR)) {
				free(src_extraData);
				fclose(file);
				main_console->Print("I was Unable to Seek Through the Offset of Row %d", y);
				return false;
			}
		}
	}

	free(src_extraData);
	fclose(file);

	this->format = GL_BGR_EXT;
	this->type = GL_UNSIGNED_BYTE;

	return true;
}

bool Image::LoadTGA(const char *filename) {
	GLubyte		header[18];
	GLuint		bitsPerPixel;
	GLuint		imageSize;
	GLuint		rowSize;

	unsigned char *rowPtr;

	//main_console->Print("Loading TGA %s\n", filename);

	//open the file
	FILE *file = fopen(filename, "rb");
    if (!file) {
		main_console->Print("Texture::LoadTGA(%s): unable to open file\n", filename);
		return false;
	}


	if (!fread(header,sizeof(header),1,file)) {
		fclose(file);
		main_console->Print("Texture::LoadTGA(%s): couldnt read header\n", filename);
		return false;
	}

	if (fseek(file, header[0], SEEK_CUR)) {
		fclose(file);
		main_console->Print("Texture::LoadTGA(%s): error trying to seek past image ID info\n", filename);
		return false;
	}

	//indexed color stuff:
	unsigned char *colorMap = NULL;
	int colorMapCount;
	int colorMapBits, colorMapBytes;

	if (header[1])		//a color map is present - lets read it
	{
		colorMapCount = *(GLushort *)(&header[5]);
		colorMapBits = header[7];

		//my way of rounding up - base 8
		colorMapBytes = (colorMapBits>>3) + !!(colorMapBits & 7);

		colorMap = (unsigned char *)malloc(colorMapCount * colorMapBytes);
		if (!colorMap) {
			main_console->Print("Texture::LoadTGA(%s): couldnt allocate memory for the TGA's palette\n", filename);
			fclose(file);
			return false;
		}
	}

	int imageType = header[2] & 7;
	int RLEcompressed = header[2] & 8;
	if (RLEcompressed)
	{
		main_console->Print("Texture::LoadTGA(%s): this TGA file just happens to be RLE, which I dont support yet\n", filename);
		if (colorMap) free(colorMap);
		fclose(file);
		return false;
	}

	this->width = *(GLushort *)(&header[12]);
	this->height = *(GLushort *)(&header[14]);
	bitsPerPixel = header[16];
	int src_bytesPerPixel = bitsPerPixel>>3;

	int tex_bytes_per_pixel = 3;
	if (src_bytesPerPixel == 32) tex_bytes_per_pixel = 4;

	int flip_flags = header[17];		//0x10 = flip x, 0x20 = flip y

 	if (bitsPerPixel != 8 && bitsPerPixel !=24 && bitsPerPixel!=32) {
		if (colorMap) free(colorMap);
		fclose(file);
		main_console->Print("Texture::LoadTGA(%s): This TGA is not of either 8,24, or 32 bits per pixel\n", filename);
		return false;
	}

	imageSize = this->width * this->height * tex_bytes_per_pixel;

	this->image = malloc(imageSize);
	if (!this->image) {
		fclose(file);
		if (colorMap) free(colorMap);
		main_console->Print("Texture::LoadTGA(%s): couldnt allocate the image data\n", filename);
		return false;
	}

	rowSize	= this->width * src_bytesPerPixel;

	rowPtr = (unsigned char *)this->image;
	int x;
	for (int y = 0; y < (int)this->height; y++)
	{
		if (bitsPerPixel == 8)
		{
			GLubyte t;
			for (x = 0; x < (int)this->width; x++)
			{
				if (!fread(&t, 1, 1, file)) {
					if (colorMap) free(colorMap);
					fclose(file);
					main_console->Print("Texture::LoadTGA(%s): error in reading this TGA\n", filename);
					return false;
				}

				if (header[1] == 0 && header[2] == 3) {	//greyscale 8bit image
					rowPtr[2] = rowPtr[1] = rowPtr[0] = t;
				} else if (header[1] == 1 && header[2] == 1) {
					if (colorMap == NULL) {
						main_console->Print("Texture::LoadTGA(%s): colormap hasnt been found\n", filename);
						fclose(file);
						return false;
					}
					memcpy(rowPtr, &colorMap[t*3], 3);
				}

				rowPtr += 3;
			}
		} else {
			if (! fread(rowPtr, rowSize, 1, file)) {
				if (colorMap) free(colorMap);
				fclose(file);
				main_console->Print("Texture::LoadTGA(%s): couldnt read texture row\n", filename);
				return false;
			}
			rowPtr += rowSize;
		}
	}

	if (colorMap) free(colorMap);
	fclose (file);

	this->format = (tex_bytes_per_pixel == 4) ? GL_BGRA_EXT : GL_BGR_EXT;
	this->type = GL_UNSIGNED_BYTE;

	return true;
}

bool Image::createEmpty(int width, int height, int format, int type) {
	Unload();

	this->width = width;
	this->height = height;
	this->format = format;
	this->type = type;
	
	int components = GL_Format_to_Components(format);
	int bpp = GL_Type_to_BPP(type);
	int size = (width * height * bpp * components) >> 3;

	if (!(image = malloc(size))) return false;

	memset(image, 0, size);
	return true;
}

#if 0
bool Image::setTexel(int x, int y, float r, float g, float b, float a) {
	if (x < 0 || x >= width) return false;
	if (y < 0 || y >= height) return false;
	if (!image) return false;

	//NOT YET SUPPORTED
	if (type != GL_UNSIGNED_BYTE) return false;
	if (format != GL_RGB) return false;

	//clamp and write values
	unsigned char *texel = (unsigned char *)image + 3 * (x + y * width);
	texel[0] = r <= 0 ? 0 : (r >= 1 ? 255 : (unsigned char)(r * 255.f));
	texel[1] = g <= 0 ? 0 : (g >= 1 ? 255 : (unsigned char)(g * 255.f));
	texel[2] = b <= 0 ? 0 : (b >= 1 ? 255 : (unsigned char)(b * 255.f));

	return true;
}
#endif

static inline void format_to_float(const void *src, float *dest, int type, int channels) {
	int bytesPerChannel = GL_Type_to_BPP(type) >> 3;	//WARNING - this destroys non-byte-alignment type storages (i.e. non-8-factor bits per pixel)
	for (int i = 0; i < channels; i++, src = (char *)src + bytesPerChannel, dest++) {
		switch (type) {
		case GL_UNSIGNED_BYTE:
			*dest = (float)*(unsigned char *)src / 255.f;
			break;
		case GL_BYTE:
			*dest = ((float)*(signed char *)src + 128.f) / 255.f;
			break;
		case GL_UNSIGNED_SHORT:
			*dest = (float)*(unsigned short *)src / 65535.f;
			break;
		case GL_SHORT:
			*dest = ((float)*(signed short *)src + 32768.f) / 65535.f;
			break;
		case GL_UNSIGNED_INT:
			*dest = (float)*(unsigned int *)src / 4294967295.f;
			break;
		case GL_INT:
			*dest = ((float)*(signed int *)src + 2147483648.f) / 4294967295.f;
			break;
		case GL_FLOAT:
			*dest = *(float *)src;
			break;
		}
	}
}

static inline void float_to_format(const float *src, void *dest, int type, int channels) {
	int bytesPerChannel = GL_Type_to_BPP(type) >> 3;	//WARNING - this destroys non-byte-alignment type storages (i.e. non-8-factor bits per pixel)
	for (int i = 0; i < channels; i++, src++, dest = (char *)dest + bytesPerChannel) {
		switch (type) {
		case GL_UNSIGNED_BYTE:
			*(unsigned char *)dest = (unsigned char)(*src * 255.f);
			break;
		case GL_BYTE:
			*(signed char *)dest = (signed char)(*src * 255.f - 128.f);
			break;
		case GL_UNSIGNED_SHORT:
			*(unsigned short *)dest = (unsigned short)(*src * 65535.f);
			break;
		case GL_SHORT:
			*(signed short *)dest = (signed short)(*src * 65535.f - 32768.f);
			break;
		case GL_UNSIGNED_INT:
			*(unsigned int *)dest = (unsigned int)(*src * 4294967295.f);
			break;
		case GL_INT:
			*(signed int *)dest = (signed int)(*src * 4294967295.f - 2147483648.f);
			break;
		case GL_FLOAT:
			*(float *)dest = *src;
			break;
		}
	}
}

bool Image::resample(int newWidth, int newHeight) {
	if (!image) return false;

	//NOT YET SUPPORTED
	if (type != GL_UNSIGNED_BYTE) return false;
	if (format != GL_RGB) return false;

	int components = GL_Format_to_Components(format);
	int bitsPerChannel = GL_Type_to_BPP(type);
	int bytesPerPixel = (bitsPerChannel * components) >> 3;

	int destSize = newWidth * newHeight * bytesPerPixel;
	unsigned char *destData = (unsigned char *)malloc(destSize);
	if (!destData) return false;

	float src_dx = (float)(width - 2)/(float)(newWidth - 1);
	float src_dy = (float)(height - 2)/(float)(newHeight - 1);

	int y;
	float src_y;
	unsigned char *dst = destData;
	for (y = 0, src_y = 0;
		y < newHeight;
		y++, src_y += src_dy) 
	{
		int x;
		float src_x;
		for (x = 0, src_x = 0;
			x < newWidth;
			x++, src_x += src_dx, dst += bytesPerPixel)
		{
			int i_src_x = (int)src_x;
			int i_src_y = (int)src_y;

			if (i_src_x >= width) i_src_x = width-1;
			if (i_src_y >= height) i_src_y = height-1;

			int i_src_x_next = (int)(src_x + src_dx);
			int i_src_y_next = (int)(src_y + src_dy);

			if (i_src_x_next >= width) i_src_x_next = width-1;
			if (i_src_y_next >= height) i_src_y_next = height-1;
			

			float frac_x = src_x - (float)i_src_x;
			float frac_y = src_y - (float)i_src_y;

			char *src;

			/*
			 0 1
			 2 3
			*/
			float pt[4][4];	//[corner][rgba]


			src = (char *)image + (i_src_x + i_src_y * width)*bytesPerPixel;
//			pt[0][0] = src[0]; pt[0][1] = src[1]; pt[0][2] = src[2];
			format_to_float(src, pt[0], type, components);

			src = (char *)image + (i_src_x_next + i_src_y*width)*bytesPerPixel;
//			pt[1][0] = src[0]; pt[1][1] = src[1]; pt[1][2] = src[2];
			format_to_float(src, pt[1], type, components);

			src = (char *)image + (i_src_x + i_src_y_next*width)*bytesPerPixel;
//			pt[2][0] = src[0]; pt[2][1] = src[1]; pt[2][2] = src[2];
			format_to_float(src, pt[2], type, components);

			src = (char *)image + (i_src_x_next + i_src_y_next*width)*bytesPerPixel;
//			pt[3][0] = src[0]; pt[3][1] = src[1]; pt[3][2] = src[2];
			format_to_float(src, pt[3], type, components);

			float pt_dx1[3], pt_dx2[3], pt_dy[3];

			pt_dx1[0] = (pt[1][0] - pt[0][0])*frac_x + pt[0][0];
			pt_dx1[1] = (pt[1][1] - pt[0][1])*frac_x + pt[0][1];
			pt_dx1[2] = (pt[1][2] - pt[0][2])*frac_x + pt[0][2];

			pt_dx2[0] = (pt[3][0] - pt[2][0])*frac_x + pt[2][0];
			pt_dx2[1] = (pt[3][1] - pt[2][1])*frac_x + pt[2][1];
			pt_dx2[2] = (pt[3][2] - pt[2][2])*frac_x + pt[2][2];

			pt_dy[0] = (pt_dx2[0] - pt_dx1[0])*frac_y + pt_dx1[0];
			pt_dy[1] = (pt_dx2[1] - pt_dx1[1])*frac_y + pt_dx1[1];
			pt_dy[2] = (pt_dx2[2] - pt_dx1[2])*frac_y + pt_dx1[2];

//			dst[0] = (unsigned char)pt_dy[0];
//			dst[1] = (unsigned char)pt_dy[1];
//			dst[2] = (unsigned char)pt_dy[2];
			float_to_format(pt_dy, dst, type, components);
		}
	}

	free(image);
	image = destData;
	width = newWidth;
	height = newHeight;
	//assume type and format are equal

	return true;
}

bool Image::createTexture(Texture *tex) {
	if (!tex) return false;
	return tex->Extract(width, height, format, type, (unsigned char *)image, 3, 3 * width);
}
