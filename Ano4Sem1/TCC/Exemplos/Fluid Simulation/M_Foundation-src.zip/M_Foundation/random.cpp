/*

    File: random.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include "random.h"

static unsigned _int64 next = 7;

int MRand(void)
{
	next = next * (_int64)6364136223846793005 + 1;
	return (int)((next >> 21) & 2147483647);
}

void MSRand(unsigned seed)
{
	next = seed;
}

float MFRand(void)
{
	return ((float)MRand() / (float)2147483647);
}

float MCRand(void)
{
	return (MFRand() * 2.f - 1.f);
}