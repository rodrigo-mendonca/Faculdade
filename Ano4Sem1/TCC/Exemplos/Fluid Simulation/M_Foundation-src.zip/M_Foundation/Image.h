/*

    File: Image.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#if !defined M_FOUNDATION_IMAGE_H
#define M_FOUNDATION_IMAGE_H

//should Image access Texture, or should Texture access Image?
//i think Texture should access Image
//but for now i'll have it the other way around
//just because.
#include "texture.h"

/*
glteximage2d

format:				components:		red,green,blue,alpha:
GL_COLOR_INDEX		1				<mapped via palette>		UNSUPPORTED!
GL_RED				1				c0,	0,	0,	1
GL_GREEN			1				0,	c0,	0,	1
GL_BLUE				1				0,	0,	c0,	1
GL_ALPHA			1				0,	0,	0,	c0
GL_RGB				3				c0,	c1,	c2,	1
GL_RGBA				4				c0,	c1,	c2,	c3
GL_BGR_EXT			3				c2,	c1,	c0,	1
GL_BGRA_EXT			4				c2,	c1,	c0,	c3
GL_LUMINANCE		1				c0,	c0,	c0,	1
GL_LUMINANCE_ALPHA	2				c0,	c0,	c0,	c1

type:				bits:
GL_BITMAP			1											UNSUPPORTED!
GL_UNSIGNED_BYTE	8
GL_BYTE				8
GL_UNSIGNED_SHORT	16
GL_SHORT			16
GL_UNSIGNED_INT		32
GL_INT				32
GL_FLOAT			32
*/

class Image {
public://private:

	int width;
	int height;
	int format;			//matches opengl
	int type;			//matches opengl
	void *image;		//size = type.size * format.components * width * height

	void Reset(void);

	bool LoadBMP(const char *filename);
	bool LoadTGA(const char *filename);

public:

	Image() {Reset();}
	~Image() {Unload();}

	void Unload(void);

	bool Load(const char *filename);

	bool createEmpty(int width, int height, int format, int type);

#if 0
	bool setTexel(int x, int y, float r, float g, float b, float a);
#endif

	bool resample(int newWidth, int newHeight);

	bool createTexture(Texture *tex);
};

#endif