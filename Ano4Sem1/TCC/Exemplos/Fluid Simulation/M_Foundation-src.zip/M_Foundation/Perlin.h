/*

    File: Perlin.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#if !defined M_FOUNDATION_PERLIN_H
#define M_FOUNDATION_PERLIN_H

typedef struct {
	//buffer specifications
	float	*ptr;
	int		inc;		//increment between ptr's
	int		width;
	int		height;
	//perlin noise evaluation
	int		level_start;		//subdiv 2^[start,end]
	int		level_end;
	double	persistance;
	int		seed;
} perlin_noise_t;

bool PerlinNoise(const perlin_noise_t *p);

#endif //M_FOUNDATION_PERLIN_H