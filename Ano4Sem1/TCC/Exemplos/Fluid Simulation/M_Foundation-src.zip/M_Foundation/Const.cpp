/*

    File: Const.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
// ************ USEFUL CONSTANTS ************ 

#include "const.h"
#include <math.h>

double Inf;
float fInf;

vector_t	vectorZero;
vector_t	vectorBaseAxis[3];
quat_t		quatIdentity;
quat_t		quatZero;
matrix_t	matrixIdentity;
matrix_t	matrixZero;
box_t		boxNull;
box_t		boxZero;

void Calc_Constants(void)
{
	Inf = -log(0);
	fInf = (float)Inf;

	VectorSet(&vectorZero, 0,0,0);
	VectorSet(&vectorBaseAxis[0], 1,0,0);
	VectorSet(&vectorBaseAxis[1], 0,1,0);
	VectorSet(&vectorBaseAxis[2], 0,0,1);
	QuatSet(&quatIdentity, 0,0,0,1);
	QuatSet(&quatZero, 0,0,0,0);
	MatrixSet(&matrixIdentity,	1,0,0,0,1,0,0,0,1);
	MatrixSet(&matrixZero,		0,0,0,0,0,0,0,0,0);
	boxZero.min = vectorZero;
	boxZero.max = vectorZero;
	VectorSet(&boxNull.min, fInf, fInf, fInf);
	VectorSet(&boxNull.max, -fInf, -fInf, -fInf);
}
