/*

    File: CVar.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include <stdio.h>
#include <stdlib.h>
#include <vector>

#include "cvar.h"

#include "main.h"

//the parent chain... global
//CHECK THIS OUT
//if you declare the object here, then the vector will get pumped into as global cvars are added
//UNTIL this line is reached, in which the vector will be cleared
//and only any subsequent cvars will remainn on the list
//SO
//my work around is to allocate the object upon its first CVar request
static std::vector<CVar *> *cvarVector = NULL;

// ***********************************
// M_CVar
// ***********************************

static void cvarAddNew(CVar *var);

CVar::CVar(const char *name) {
	this->name = name;
	this->desc = NULL;
	this->func = NULL;
	cvarAddNew(this);
}
CVar::CVar(const char *name, const char *desc) {
	this->name = name;
	this->desc = desc;
	this->func = NULL;
	cvarAddNew(this);
}
CVar::CVar(const char *name, CFUNC *func) {
	this->name = name;
	this->desc = NULL;
	this->func = func;
	cvarAddNew(this);
}
CVar::CVar(const char *name, const char *desc, CFUNC *func) {
	this->name = name;
	this->desc = desc;
	this->func = func;
	cvarAddNew(this);
}

void CVar::execArgs(int argc, char **argv) {
	//no input, no output, just printing the function
	if (func) {
		func(argc, argv);
	}
}

void CVarPrim::execArgs(int argc, char **argv) {
	if (argc > 1) setValue(argc, argv);
	CVar::execArgs(argc, argv);
	echoData();
}

void CVarPrim::setValue(int argc, char **argv) {}
void CVarPrim::echoData(void) {}

void CVarf::setValue(int argc, char **argv) {
	data = (float)atof(argv[1]);
}

void CVarf::echoData(void) {
	main_console->Print("%s := %f\n", getName(), data);
}

void CVari::setValue(int argc, char **argv) {
	data = atoi(argv[1]);
}

void CVari::echoData(void) {
	main_console->Print("%s := %d\n", getName(), data);
}

void CVarfv::setValue(int argc, char **argv) {
	*data = (float)atof(argv[1]);
}

void CVarfv::echoData(void) {
	main_console->Print("%s := %f\n", getName(), *data);
}

void CVar3fv::setValue(int argc, char **argv) {
	if (argv[1]) data[0] = (float)atof(argv[1]);
	if (argv[2]) data[1] = (float)atof(argv[2]);
	if (argv[3]) data[2] = (float)atof(argv[3]);
}

void CVar3fv::echoData(void) {
	main_console->Print("%s := %f %f %f\n", getName(), data[0], data[1], data[2]);
}

void CVar4fv::setValue(int argc, char **argv) {
	if (argv[1]) data[0] = (float)atof(argv[1]);
	if (argv[2]) data[1] = (float)atof(argv[2]);
	if (argv[3]) data[2] = (float)atof(argv[3]);
	if (argv[4]) data[3] = (float)atof(argv[4]);
}

void CVar4fv::echoData(void) {
	main_console->Print("%s := %f %f %f %f\n", getName(), data[0], data[1], data[2], data[3]);
}

void CVariv::setValue(int argc, char **argv) {
	*data = atoi(argv[1]);
}

void CVariv::echoData(void) {
	main_console->Print("%s := %d\n", getName(), *data);
}

CVarw::CVarw(int data, const char *name, CFUNC *func) : CVarPrim(name, NULL, func) {
	type = CVAR_TYPE_NONE;
	dim = 0;
	this->data = NULL;
}

CVarw::CVarw(bool *data, const char *name, CFUNC *func) : CVarPrim(name, NULL, func) {
	type = CVAR_TYPE_BOOL;
	dim = 1;
	this->data = data;
}

CVarw::CVarw(int *data, const char *name, CFUNC *func) : CVarPrim(name, NULL, func) {
	type = CVAR_TYPE_INT;
	dim = 1;
	this->data = data;
}

CVarw::CVarw(float *data, const char *name, CFUNC *func) : CVarPrim(name, NULL, func) {
	type = CVAR_TYPE_FLOAT;
	dim = 1;
	this->data = data;
}

CVarw::CVarw(double *data, const char *name, CFUNC *func) : CVarPrim(name, NULL, func) {
	type = CVAR_TYPE_DOUBLE;
	dim = 1;
	this->data = data;
}

//math lib specific

CVarw::CVarw(vector_t *data, const char *name, CFUNC *func) : CVarPrim(name, NULL, func) {
	type = CVAR_TYPE_FLOAT;
	dim = 3;
	this->data = &data->v;
}

CVarw::CVarw(quat_t *data, const char *name, CFUNC *func) : CVarPrim(name, NULL, func) {
	type = CVAR_TYPE_FLOAT;
	dim = 4;
	this->data = &data->v;
}

void CVarw::setValue(int argc, char **argv) {

	for (int i = 0; i < dim; i++) {
		int ai = i + 1;
		if (ai > argc) break;
		char *s = argv[ai];
		if (!s) break;

		switch (type) {
		case CVAR_TYPE_NONE:
			break;
		case CVAR_TYPE_BOOL:
			if (!stricmp(argv[1], "true")) {
				//interpret literally
				((bool *)data)[i] = true;
			} else {
				//interpret numerically.
				//non-"true" strings default to zero == false
				((bool *)data)[i] = (atoi(s) != 0);
			}
			break;
		case CVAR_TYPE_INT:
			((int *)data)[i] = atoi(s);
			break;
		case CVAR_TYPE_FLOAT:
			((float *)data)[i] = (float)atof(s);
			break;
		case CVAR_TYPE_DOUBLE:
			((double *)data)[i] = atof(s);
			break;
		}
	}
}

void CVarw::echoData(void) {

	if (type == CVAR_TYPE_NONE) return;

	main_console->Print("%s :=", getName());

	for (int i = 0; i < dim; i++) {
		switch (type) {
		case CVAR_TYPE_BOOL:
			main_console->Print(((bool *)data)[i] ? " true" : " false");
			break;
		case CVAR_TYPE_INT:
			main_console->Print(" %d", ((int *)data)[i]);
			break;
		case CVAR_TYPE_FLOAT:
			main_console->Print(" %f", ((float *)data)[i]);
			break;
		case CVAR_TYPE_DOUBLE:
			main_console->Print(" %f", ((double *)data)[i]);
			break;
		}
	}

	main_console->Print("\n");
}

//M_CVar::M_CVar(int p,		const char *n, CFUNC *f, void *o)	{data = 0; name = n; func = f; param = o; type = CVAR_EMPTY;	cvarAddNew(this);}
//M_CVar::M_CVar(bool *p,		const char *n, CFUNC *f, void *o)	{data = p; name = n; func = f; param = o; type = CVAR_BOOL;		cvarAddNew(this);}
//M_CVar::M_CVar(int *p,		const char *n, CFUNC *f, void *o)	{data = p; name = n; func = f; param = o; type = CVAR_INT;		cvarAddNew(this);}
//M_CVar::M_CVar(float *p,	const char *n, CFUNC *f, void *o)	{data = p; name = n; func = f; param = o; type = CVAR_FLOAT;	cvarAddNew(this);}
//M_CVar::M_CVar(double *p,	const char *n, CFUNC *f, void *o)	{data = p; name = n; func = f; param = o; type = CVAR_DOUBLE;	cvarAddNew(this);}
//M_CVar::M_CVar(vector_t *p,	const char *n, CFUNC *f, void *o)	{data = p; name = n; func = f; param = o; type = CVAR_VECTOR;	cvarAddNew(this);}
//M_CVar::M_CVar(quat_t *p,	const char *n, CFUNC *f, void *o)	{data = p; name = n; func = f; param = o; type = CVAR_QUAT;		cvarAddNew(this);}
//
//void M_CVar::Reset(int p)		{data = 0; type = CVAR_EMPTY;}
//void M_CVar::Reset(bool *p)		{data = p; type = CVAR_BOOL;}
//void M_CVar::Reset(int *p)		{data = p; type = CVAR_INT;}
//void M_CVar::Reset(float *p)	{data = p; type = CVAR_FLOAT;}
//void M_CVar::Reset(double *p)	{data = p; type = CVAR_DOUBLE;}
//void M_CVar::Reset(vector_t *p)	{data = p; type = CVAR_VECTOR;}
//void M_CVar::Reset(quat_t *p)	{data = p; type = CVAR_QUAT;}

//M_CVar::~M_CVar()
//{
//	Unlink();
//}	//this is a definate - unlink a CVar upon destruction

//int M_CVar::GetType(void)
//{
//	return type;
//}

//const char *M_CVar::GetName(void)
//{
//	return name;
//}

//	//echoes its data to the string in dest - specific per-type
//void M_CVar::EchoData(char *dest)
//{
//	if (!data) return;	//duh
//
//	switch (type)
//	{
//	case CVAR_INT:		sprintf(dest, "%d", *(int *)data); break;
//	case CVAR_FLOAT:	sprintf(dest, "%f", *(float *)data); break;
//	case CVAR_DOUBLE:	sprintf(dest, "%f", *(double *)data); break;
//	case CVAR_VECTOR:	sprintf(dest, "%f %f %f", ((vector_t *)data)->x, ((vector_t *)data)->y, ((vector_t *)data)->z);	break;
//	case CVAR_QUAT:		sprintf(dest, "%f %f %f %f", ((quat_t *)data)->x, ((quat_t *)data)->y, ((quat_t *)data)->z, ((quat_t *)data)->w);	break;
//	}
//}

//float InterpretArgv(char *argv)
//{
////possible new system of treating cvars like variables in any other language:
////	M_CVar *check = MatchString(argv);
////	if (check) return check->data;
//
//	return (float)atof(argv);
//}

//	//pointer to an array of pointers to strings to contain the value
//void M_CVar::SetValue(char **argv)
//{
//	switch (type)
//	{
//	case CVAR_INT:
//		if (!argv[1]) break;		*(int *)data = (int)InterpretArgv(argv[1]);
//		break;
//	case CVAR_FLOAT:
//		if (!argv[1]) break;		*(float *)data = (float)InterpretArgv(argv[1]);
//		break;
//	case CVAR_DOUBLE:
//		if (!argv[1]) break;		*(double *)data = (double)InterpretArgv(argv[1]);
//		break;
//	case CVAR_VECTOR:
//		if (!argv[1]) break;		((vector_t *)data)->x = (float)InterpretArgv(argv[1]);
//		if (!argv[2]) break;		((vector_t *)data)->y = (float)InterpretArgv(argv[2]);
//		if (!argv[3]) break;		((vector_t *)data)->z = (float)InterpretArgv(argv[3]);
//		break;
//	case CVAR_QUAT:
//		if (!argv[1]) break;		((quat_t *)data)->x = (float)InterpretArgv(argv[1]);
//		if (!argv[2]) break;		((quat_t *)data)->y = (float)InterpretArgv(argv[2]);
//		if (!argv[3]) break;		((quat_t *)data)->z = (float)InterpretArgv(argv[3]);
//		if (!argv[4]) break;		((quat_t *)data)->w = (float)InterpretArgv(argv[4]);
//		break;
//	}
//}

//void M_CVar::ExecFunc(int argc, char **argv)
//{
//	if (func) (*func)(argc, argv, param);
//}


// GLOBAL FUNCTIONS

static CVar *cvarMatchString(const char *str) {

	if (!cvarVector) return NULL;

	for (int i =0 ; i < (*cvarVector).size(); i++) {
		CVar *v = (*cvarVector)[i];
		if (!strcmp(v->getName(), str)) return v;
	}
	return NULL;
}

#include "../m_system3d/error.h"

static void cvarAddNew(CVar *var) {

	if (!cvarVector) {
		cvarVector = new std::vector<CVar *>();
		if (!cvarVector) {
			//failed to alloc the cvar vector!
			return;
		}
	}

//	Error("cvar %s\n", var->getName());

	if (cvarMatchString(var->getName())) {
		main_console->Print("cvarAddNew: found two cvars with name %s\n", var->getName());
		return;
	}

	cvarVector->push_back(var);
}

void CFunc_ListCmds(int argc, char **argv) {

	if (!cvarVector) return;

	const char *name;
	const char *match_str = NULL;

	if (argc > 1) match_str = argv[1];

	for (int i = 0; i < (*cvarVector).size(); i++) {
		CVar *v = (*cvarVector)[i];
		name = v->getName();
		if (match_str && *match_str) {	//if it exists and has at least once char...
			const char *match_end = match_str + strlen(match_str);
			const char *name_end = name + strlen(name);

			const char *m = match_str;
			const char *n = name;
			bool skip = false;

			const char *next_block_start = NULL;
			const char *next_block_end = NULL;
			int next_block_size = 0;

			do {
				//if we find a pre_string then loop while the pre_string is there
				for (; *m != '*'; m++, n++) {
					//if we passed the end of the 'm' then bail
					if (m >= match_end) {
						//if we hadnt completed our 'n' search
						if (n < name_end) skip = true;
						break;
					}
					//if the name exceeded the end and we still have match to go
					if (n >= name_end) {
						skip = true;
						break;
					}
					//compare - and if we find inaccuracies then skip this name
					if (*m != *n) {
						skip = true;
						break;
					}
				}
				if (skip == true) break;
				if (m >= match_end) break;

				//if we find a wildcard then read the next match block
				//and search for it
				if (*m == '*') {
					for (; *m == '*'; m++) {
						if (m >= match_end) break;
					}
					if (m >= match_end) break;	//read wildcards to the end - dont care anymore compares.
					next_block_start = m;
					for (; *m != '*'; m++) {
						if (m >= match_end) break;
					}
					next_block_end = m;
					next_block_size = next_block_end - next_block_start;

					bool found_next_block = false;
					for (; n <= name_end - next_block_size; n++) {
						//if we find the next block then bail out of this loop
						if (!memcmp(n, next_block_start, next_block_size)) {
							found_next_block = true;
							break;
						}
					}
					//if we never find the next block, assume its not a match
					if (!found_next_block) {
						skip = true;
						break;
					}
				}
				if (skip == true) break;
			} while (m < match_end);

			if (skip) continue;
		}
		//if 'name' matches the match_str then...
		main_console->Print("%s\n", name);
	}
}


#define CVAR_MAX_ARGS	16
#define CVAR_MAX_ARGLEN	128

char *cvar_argv[CVAR_MAX_ARGS];
static char stupid_buffer[CVAR_MAX_ARGS][CVAR_MAX_ARGLEN];		//a stupid buffer for a stupid C
int cvar_argc = 0;

//in the future?
//class CVarListCmds : public CVar {
//} cv_listcmds;

static CVar cv_listcmds("listcmds", CFunc_ListCmds);
bool Init_CVars(void) {
	//i'm going to get my cvar_argv** whether you like it or not...
	for (int i = 0; i < CVAR_MAX_ARGS; i++)
		cvar_argv[i] = stupid_buffer[i];

	return true;
}

void Shutdown_CVars(void) {
	if (cvarVector) {
		cvarVector->clear();
		delete cvarVector;
		cvarVector = NULL;
	}
}

void CVar_ParseArgs(char *buffer) {
	cvar_argc = 0;
	int argi = 0;

	for (int i = 0; ; i++)
	{
		//fill the next elem in the cvar_argv with the buffer
		cvar_argv[cvar_argc][argi] = buffer[i];
		//if we reach the end of the buffer
		if (argi == CVAR_MAX_ARGLEN-1)
		{
			//null-terminate the current cvar_argv
			cvar_argv[cvar_argc][argi] = 0;
			//increment our argument counter
			cvar_argc++;
			//make sure we have not surpassed our argument capacity
			if (cvar_argc >= CVAR_MAX_ARGS) return;
			//reset the argument index counter
			argi = 0;
			//begin writing the current line into the new argument
			cvar_argv[cvar_argc][argi] = buffer[i];
		}
		//sucessfully wrote a character - increment the cvar_argv index counter
		argi++;

		//if we write a null-terminated string
		if (buffer[i] == 0)
		{
			//increment the argument counter
			cvar_argc++;
			//and return
			return;
		}

		//if we write a space..
		if (buffer[i] == ' ')
		{
			//null-terminate the current cvar_argv (remove the newly written space)
			cvar_argv[cvar_argc][argi-1] = 0;
			//increment the argument counter
			cvar_argc++;
			//make sure we have not surpassed our argument capacity
			if (cvar_argc >= CVAR_MAX_ARGS) return;
			//and reset the argument index counter
			argi = 0;
		}
	}
}

void CVar_ExecuteArgs(void) {
	//if there are none then return
	if (cvar_argc == 0) return;

	//match the first argument to a known variable
	CVar *var = cvarMatchString(cvar_argv[0]);
	if (var) {
		var->execArgs(cvar_argc, cvar_argv);
	} else {
		main_console->Print("unknown cvar \"%s\"\n", cvar_argv[0]);
	}
}

void CVar_Exec(char *buffer) {
	CVar_ParseArgs(buffer);
	CVar_ExecuteArgs();
}
