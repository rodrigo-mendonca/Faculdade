/*

    File: OpenGL.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include "../m_system3d/main.h"		//main_display

#include "opengl.h"
#include "main.h"					//main_console

/*
prereq - OpenGL must be init'd
		(shouldnt be a problem if application3D code is all thats calling this)
params -
		IN:
	ext_name - null-terminated string for extension name
	func_name - array of pointers to null-terminated strings for extension functions
	func_count - size of the func_name array
		OUT:
	func_ptr - array of pointers filled with the function pointers.  NULL if not found

returns -
	true - the extension was found
	false - the extension wasnt found

to ensure that all the functions were recieved, the invoker will have to make sure all
the function pointers in the func_ptr array are not NULL
*/
bool OpenGL_LoadExtension(
	const char *ext_name,
	const char **func_name,
	int func_count,
	void **func_ptr)
{
	if (!main_display->HasExtension(ext_name)) return false;

	for (int i = 0; i < func_count; i++) {
		func_ptr[i] = wglGetProcAddress(func_name[i]);
		if (!func_ptr[i]) return false;
	}

	return true;
}

bool								found_GL_ARB_texture_env_combine		= false;


bool								found_GL_ARB_texture_cube_map			= false;

bool								found_GL_ARB_multitexture				= false;
PFNGLMULTITEXCOORD2FARBPROC			glMultiTexCoord2fARB					= 0;
PFNGLMULTITEXCOORD2FVARBPROC		glMultiTexCoord2fvARB					= 0;
PFNGLMULTITEXCOORD3FARBPROC			glMultiTexCoord3fARB					= 0;
PFNGLMULTITEXCOORD3FVARBPROC		glMultiTexCoord3fvARB					= 0;
PFNGLACTIVETEXTUREARBPROC			glActiveTextureARB						= 0;
PFNGLCLIENTACTIVETEXTUREARBPROC		glClientActiveTextureARB				= 0;

bool								found_GL_EXT_draw_range_elements		= false;
PFNGLDRAWRANGEELEMENTSPROC			glDrawRangeElements						= 0;

bool								found_GL_EXT_compiled_vertex_array		= false;
PFNGLLOCKARRAYSEXTPROC				glLockArraysEXT							= 0;
PFNGLUNLOCKARRAYSEXTPROC			glUnlockArraysEXT						= 0;

bool								found_GL_EXT_point_parameters			= false;
PFNGLPOINTPARAMETERFEXTPROC			glPointParameterfEXT					= 0;
PFNGLPOINTPARAMETERFVEXTPROC		glPointParameterfvEXT					= 0;

bool								found_GL_EXT_separate_specular_color	= false;

bool								found_GL_EXT_fog_coord					= false;
PFNGLFOGCOORDFEXTPROC				glFogCoordfEXT							= 0;
PFNGLFOGCOORDFVEXTPROC				glFogCoordfvEXT							= 0;
PFNGLFOGCOORDDEXTPROC				glFogCoorddEXT							= 0;
PFNGLFOGCOORDDVEXTPROC				glFogCoorddvEXT							= 0;
PFNGLFOGCOORDPOINTEREXTPROC			glFogCoordPointerEXT					= 0;

bool								found_GL_NV_texgen_reflection			= false;
bool								found_GL_NV_light_max_exponent			= false;
bool								found_GL_NV_texgen_emboss				= false;

bool								found_GL_NV_vertex_array_range			= false;
PFNGLFLUSHVERTEXARRAYRANGENVPROC	glFlushVertexArrayRangeNV				= 0;
PFNGLVERTEXARRAYRANGENVPROC			glVertexArrayRangeNV					= 0;
PFNWGLALLOCATEMEMORYNV				wglAllocateMemoryNV						= 0;
PFNWGLFREEMEMORYNV					wglFreeMemoryNV							= 0;

void Init_OpenGL(void)
{
	//FOUNDATION-DEPENDANT - Texture.cpp
	//GL_ARB_texture_cube_map
	//GL_EXT_texture_cube_map
	if (main_display->HasExtension("GL_ARB_texture_cube_map") ||
		main_display->HasExtension("GL_EXT_texture_cube_map"))		//pre-ARB extension name - compatible with ARB
	{
		found_GL_ARB_texture_cube_map = true;
		main_console->Print("found GL extension GL_ARB_texture_cube_map\n");
	}

	//GL_ARB_multitexture
    if (main_display->HasExtension("GL_ARB_multitexture"))
	{
		glMultiTexCoord2fARB		= (PFNGLMULTITEXCOORD2FARBPROC)		wglGetProcAddress("glMultiTexCoord2fARB");
		glMultiTexCoord2fvARB		= (PFNGLMULTITEXCOORD2FVARBPROC)	wglGetProcAddress("glMultiTexCoord2fvARB");
		glMultiTexCoord3fARB		= (PFNGLMULTITEXCOORD3FARBPROC)		wglGetProcAddress("glMultiTexCoord3fARB");
		glMultiTexCoord3fvARB		= (PFNGLMULTITEXCOORD3FVARBPROC)	wglGetProcAddress("glMultiTexCoord3fvARB");
		glActiveTextureARB			= (PFNGLACTIVETEXTUREARBPROC)		wglGetProcAddress("glActiveTextureARB");		
		glClientActiveTextureARB	= (PFNGLCLIENTACTIVETEXTUREARBPROC)	wglGetProcAddress("glClientActiveTextureARB");

		if (glMultiTexCoord2fARB &&
			glActiveTextureARB &&
			glClientActiveTextureARB &&
			glMultiTexCoord2fvARB)
		{
			found_GL_ARB_multitexture = true;
			main_console->Print("found GL extension GL_ARB_multitexture\n");
		}
	}

	//GL_EXT_draw_range_elements
	if (main_display->HasExtension("GL_EXT_draw_range_elements"))
	{
		glDrawRangeElements			= (PFNGLDRAWRANGEELEMENTSPROC)		wglGetProcAddress("glDrawRangeElements");

		if (glDrawRangeElements)
		{
			found_GL_EXT_draw_range_elements = true;
			main_console->Print("found GL extension GL_EXT_draw_range_elements\n");
		}
	}

	//GL_EXT_point_parameters
	if (main_display->HasExtension("GL_EXT_point_parameters"))
	{
		glPointParameterfEXT		= (PFNGLPOINTPARAMETERFEXTPROC)		wglGetProcAddress("glPointParameterfEXT");
		glPointParameterfvEXT		= (PFNGLPOINTPARAMETERFVEXTPROC)	wglGetProcAddress("glPointParameterfvEXT");

		if (glPointParameterfEXT && 
			glPointParameterfvEXT)
		{
			found_GL_EXT_point_parameters = true;
			main_console->Print("found GL extension GL_EXT_point_parameters\n");
		}
	}

	//GL_ARB_texture_env_combine
	if (main_display->HasExtension("GL_ARB_texture_env_combine"))
	{
		found_GL_ARB_texture_env_combine = true;
		main_console->Print("found GL extension GL_ARB_texture_env_combine\n");
	}

	//GL_EXT_separate_specular_color
	if (main_display->HasExtension("GL_EXT_separate_specular_color"))
	{
		found_GL_EXT_separate_specular_color = true;
		main_console->Print("found GL extension GL_EXT_separate_specular_color\n");
	}

	//GL_EXT_compiled_vertex_array
	if (main_display->HasExtension("GL_EXT_compiled_vertex_array"))
	{
		glLockArraysEXT				= (PFNGLLOCKARRAYSEXTPROC)			wglGetProcAddress("glLockArraysEXT");
		glUnlockArraysEXT			= (PFNGLUNLOCKARRAYSEXTPROC)		wglGetProcAddress("glUnlockArraysEXT");

		if (glLockArraysEXT &&
			glUnlockArraysEXT)
		{
			found_GL_EXT_compiled_vertex_array = true;
			main_console->Print("found GL extension GL_EXT_compiled_vertex_array\n");
		}
	}

	//GL_EXT_fog_coord
	if (main_display->HasExtension("GL_EXT_fog_coord"))
	{
		glFogCoordfEXT				= (PFNGLFOGCOORDFEXTPROC)			wglGetProcAddress("glFogCoordfEXT");
		glFogCoordfvEXT				= (PFNGLFOGCOORDFVEXTPROC)			wglGetProcAddress("glFogCoordfvEXT");
		glFogCoorddEXT				= (PFNGLFOGCOORDDEXTPROC)			wglGetProcAddress("glFogCoorddEXT");
		glFogCoorddvEXT				= (PFNGLFOGCOORDDVEXTPROC)			wglGetProcAddress("glFogCoorddvEXT");
		glFogCoordPointerEXT		= (PFNGLFOGCOORDPOINTEREXTPROC)		wglGetProcAddress("glFogCoordPointerEXT");

		if (glFogCoordfEXT &&
			glFogCoordfvEXT &&
			glFogCoorddEXT &&
			glFogCoorddvEXT &&
			glFogCoordPointerEXT)
		{
			found_GL_EXT_fog_coord = true;
			main_console->Print("found GL extension GL_EXT_fog_coord\n");
		}
	}

	//GL_NV_texgen_reflection
	if (main_display->HasExtension("GL_NV_texgen_reflection"))
	{
		found_GL_NV_texgen_reflection = true;
		main_console->Print("found GL extension GL_NV_texgen_reflection\n");
	}


	//GL_NV_light_max_exponent
	if (main_display->HasExtension("GL_NV_light_max_exponent"))
	{
		found_GL_NV_light_max_exponent = true;
		main_console->Print("found GL extension GL_NV_light_max_exponent\n");
	}

	//GL_NV_texgen_emboss
	if (main_display->HasExtension("GL_NV_texgen_emboss"))
	{
		found_GL_NV_texgen_emboss = true;
		main_console->Print("found GL extension GL_NV_texgen_emboss\n");
	}

	//GL_NV_vertex_array_range
	if (main_display->HasExtension("GL_NV_vertex_array_range"))
	{
		glFlushVertexArrayRangeNV	= (PFNGLFLUSHVERTEXARRAYRANGENVPROC)wglGetProcAddress("glFlushVertexArrayRangeNV");
		glVertexArrayRangeNV		= (PFNGLVERTEXARRAYRANGENVPROC)		wglGetProcAddress("glVertexArrayRangeNV");
		wglAllocateMemoryNV			= (PFNWGLALLOCATEMEMORYNV)			wglGetProcAddress("wglAllocateMemoryNV");
		wglFreeMemoryNV				= (PFNWGLFREEMEMORYNV)				wglGetProcAddress("wglFreeMemoryNV");

		if (glFlushVertexArrayRangeNV &&
			glVertexArrayRangeNV &&
			wglAllocateMemoryNV &&
			wglFreeMemoryNV)
		{
			found_GL_NV_vertex_array_range = true;
			main_console->Print("found GL extension GL_NV_vertex_array_range\n");
		}
	}
}
