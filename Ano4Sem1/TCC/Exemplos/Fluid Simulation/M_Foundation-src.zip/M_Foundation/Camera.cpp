/*

    File: Camera.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/#include <windows.h>
#include <gl/gl.h>

#include "camera.h"
#include "cvar.h"

#include "../m_system3d/main.h"	//for main_display and main_mouse

// ********** CONSTRUCTION ********** 

M_Camera::M_Camera()
{
	//link all CVars - dont do this outside of any method
	//instead, let the parent chain of the cvar be created and constructed
	//before linking anything to it
//	CamInitCVars();

	//upon construction of the position vector and angle quaternion, identity
	//( [0,0,0] and {[0,0,0],1}, respectively) is set
	active = false;
	ortho = false;

	halfWidth = 1;
	halfHeight = 1;

	adjustRatio = CAMERA_ADJUST_HEIGHT;
	znear = 1.0f;
	zfar = 30000.0f;

	VectorSet(&position, 0,0,0);
	QuatSet(&angle, 0,0,0,1);
	mirror = false;
	flip = false;

	trackPosition = NULL;
	trackAngle = NULL;
	trackMethod = CAM_TRACK_NO;
	trackSlerpC = 0.5f;	//the slerp coefficient from the current to the tracking angle
	trackLerpC = 0.5f;	//lerp position coeff

	VectorSet(&chaseOffsetPos, -25, 0, 5);
	QuatSet(&chaseOffsetAngle, 0,0,0,1);
}

M_Camera::M_Camera(M_Camera *src)		//create a cam from another cam
{
	memcpy(this, src, sizeof(M_Camera));
}


bool M_Camera::Init(void) {return true;}

static CVar3fv	cv_campos("CamPos");
static CVar4fv	cv_camangle("CamAngle");
static CVariv	cv_trackmethod("CamTrackMethod");
static CVarfv	cv_tracklerpc("CamTrackLerpC");
static CVarfv	cv_trackslerpc("CamTrackSlerpC");
static CVar3fv	cv_camofspos("CamOffsetPos");
static CVar4fv	cv_camofsangle("CamOffsetAngle");
static CVarfv	cv_znear("CamZNear");
static CVarfv	cv_zfar("CamZFar");
static CVariv	cv_adjustRatio("CamAdjustRatio");
static CVarfv	cv_halfWidth("CamHalfWidth");
static CVarfv	cv_halfHeight("CamHalfHeight");

void M_Camera::Activate(void) {

	cv_campos = position.v;
	cv_camangle = angle.v;
	cv_trackmethod = &trackMethod;
	cv_tracklerpc = &trackLerpC;
	cv_trackslerpc = &trackSlerpC;
	cv_camofspos = chaseOffsetPos.v;
	cv_camofsangle = chaseOffsetAngle.v;
	cv_znear = &znear;
	cv_zfar = &zfar;
	cv_adjustRatio = &adjustRatio;
	cv_halfWidth = &halfWidth;
	cv_halfHeight = &halfHeight;

	active = true;
}

// ********** DESTRUCTION ********** 

void M_Camera::Kill(void) {}

// ********** SCENE TRANSFORMATION ********** 

void M_Camera::TransformScene(int flags)
{
	//only call this when the viewport dimensions have changed
	if (flags & CAMERA_RESET_PROJECTION)
		SetProjection();	//sets the field of vision / clip planes / etc

	if (flags & (CAMERA_RESET_TRANSLATION | CAMERA_RESET_ROTATION))
		SetModelview(flags);		//sets the translation / rotation
}

// **************************************
// Projection Matrix transformation calls
// **************************************

void M_Camera::SetProjection(void)
{
	double glleft, glright, glbottom, gltop, glznear, glzfar;
	double swap;

	//by default, use the camera height
	double trueHalfHeight = halfHeight;
	double trueHalfWidth = halfWidth;

	//. . .unless adjustHeight says otherwise. . .
	if (main_display && adjustRatio)
	{
		double ratio = (double)main_display->displayHeight / (double)main_display->displayWidth;
		switch (adjustRatio)
		{
		case CAMERA_ADJUST_HEIGHT:
			trueHalfHeight = halfWidth * ratio;
			break;
		case CAMERA_ADJUST_WIDTH:
			trueHalfWidth = halfHeight / ratio;
			break;
		}
	}

//field of view is based upon screen width
	glleft = -znear * trueHalfWidth;
	glright = znear * trueHalfWidth;
//screen height is adjusted to compensate
	glbottom = -znear * trueHalfHeight;
	gltop = znear * trueHalfHeight;

	glznear = znear;
	glzfar = zfar;

	//grab that frustum
	if (mirror)
	{
		swap = glleft;
		glleft = glright;
		glright = swap;
	}

	if (flip)
	{
		swap = gltop;
		gltop = glbottom;
		glbottom = swap;
	}

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	if (!ortho)	glFrustum(glleft, glright, glbottom, gltop, glznear, glzfar);
	else		glOrtho(glleft, glright, glbottom, gltop, glznear, glzfar);

	//should the camera be the only guy in charge of front face orientation?
	if (mirror ^ flip)	glFrontFace(GL_CW);
	else				glFrontFace(GL_CCW);
}

// *************************************
// Modelview Matrix transformation calls
// *************************************

//to be multiplied by objects desiring this transformation in worldspace (most notably inverse camera rotations)
float Camera_DefaultMatrix[16] =
{
	0.0f,	-1.0f,	0.0f,	0.0f,
	0.0f,	0.0f,	1.0f,	0.0f,
	-1.0f,	0.0f,	0.0f,	0.0f,
	0.0f,	0.0f,	0.0f,	1.0f
};

//to be multiplied by the modelview matrix at the beginning of the scene
//because - camera matrix influences are always inverse matricies in inverse order
//because - as MTH341 says - (BA)^-1 = (B^-1)(A^-1)
float Camera_DefaultMatrixInverse[16] =
{
	0.0f,	0.0f,	-1.0f,	0.0f,
	-1.0f,	0.0f,	0.0f,	0.0f,
	0.0f,	1.0f,	0.0f,	0.0f,
	0.0f,	0.0f,	0.0f,	1.0f
};

void M_Camera::SetModelview(int flags)
{
	glMatrixMode(GL_MODELVIEW);

	//set initial conversion
	glLoadMatrixf(Camera_DefaultMatrixInverse);
	//x faces forward
	//y faces to the left
	//z faces upwards

	if (flags & CAMERA_RESET_ROTATION)		RotateScene();
	if (flags & CAMERA_RESET_TRANSLATION)	TranslateScene();
}

void M_Camera::TranslateScene(void)
{
	//and translate it
	glTranslatef(-position.x, -position.y, -position.z);
}

void M_Camera::RotateScene(void)
{
	quat_t q;
	QuatToAngleAxis(&angle, &q);
	glRotatef(q.w, -q.x, -q.y, -q.z);
}

// **************************
// Camera frustum calculation
// **************************

//calculates the frustum verticies
//the three axii (x/y/z)
//the six border planes
void M_Camera::CalculateFrustum(void)
{
	//by default, use the camera height
	float trueHalfHeight = halfHeight;
	float trueHalfWidth = halfWidth;

	//. . .unless adjustHeight says otherwise. . .
	if (main_display && adjustRatio)
	{
		float ratio = (float)main_display->displayHeight / (float)main_display->displayWidth;
		switch (adjustRatio)
		{
		case CAMERA_ADJUST_HEIGHT:
			trueHalfHeight = halfWidth * ratio;
			break;
		case CAMERA_ADJUST_WIDTH:
			trueHalfWidth = halfHeight / ratio;
			break;
		}
	}

	
//and recalculate the frustum:
//this is here right now because we have already referenced 'ratio'

	/*LR(1) UD(2)  fwd/back(0)
	0	-	 -			-
	1	-	 +			-
	2	+	 +			-
	3	+	 -			-
	4	-	 -			+
	5	-	 +			+
	6	+	 +			+
	7	+	 -			+
	*/

	/*
	frustum_vtx[0] = position + axis[0] * znear - axis[1] - ratio * axis[2];
	frustum_vtx[1] = position + axis[0] * znear + axis[1] - ratio * axis[2];
	frustum_vtx[2] = position + axis[0] * znear + axis[1] + ratio * axis[2];
	frustum_vtx[3] = position + axis[0] * znear - axis[1] + ratio * axis[2];
	frustum_vtx[4] = position + axis[0] * zfar - axis[1] - ratio * axis[2];
	frustum_vtx[5] = position + axis[0] * zfar + axis[1] - ratio * axis[2];
	frustum_vtx[6] = position + axis[0] * zfar + axis[1] + ratio * axis[2];
	frustum_vtx[7] = position + axis[0] * zfar - axis[1] + ratio * axis[2];
	*/

	static int axis_flag[8][3] =
	{
		{0, 0, 0},
		{0, 0, 1},
		{0, 1, 1},
		{0, 1, 0},
		{1, 0, 0},
		{1, 0, 1},
		{1, 1, 1},
		{1, 1, 0}
	};

	QuatToMatrix(&angle, &matrix);

	for (int v = 0; v < 8; v++)
	{
		vector_t vec;

		vec.v[1] = axis_flag[v][1] ? trueHalfWidth : -trueHalfWidth;
		vec.v[2] = axis_flag[v][2] ? trueHalfHeight : -trueHalfHeight;

		if (!ortho)
		{
			if (!axis_flag[v][0])
			{
				vec.v[0] = znear;
				vec.v[1] *= znear;
				vec.v[2] *= znear;
			}
			else
			{
				vec.v[0] = zfar;
				vec.v[1] *= zfar;
				vec.v[2] *= zfar;
			}
		}
		else
		{
			vec.v[0] = axis_flag[v][0] ? zfar : znear;
		}

		MatrixMul(&matrix, &vec, &vec);
		VectorAdd(&position, &vec, &frustum_vtx[v]);
	}

	//calculate the mouse position
	CalcMouseLine();

	//calculate the frustum planes

	/*
	0	znear
	1	zfar
	2	bottom
	3	left
	4	top
	5	right
	*/

	//quick front and back - normal is already same as camera dir

	frustum_plane[0].normal.x = -matrix.vec[0].x;
	frustum_plane[0].normal.y = -matrix.vec[0].y;
	frustum_plane[0].normal.z = -matrix.vec[0].z;
	frustum_plane[0].dist_neg = -VectorDot(&frustum_plane[0].normal, &frustum_vtx[0]);
//	VectorCopy(&frustum_vtx[0], &frustum_plane[0].pos);

	PlaneConstruct(&frustum_vtx[4], &matrix.vec[0], &frustum_plane[1]);
	//VectorCopy(&frustum_vtx[4], &frustum_plane[1].pos);
	//VectorCopy(&matrix.vec[0], &frustum_plane[1].normal);

	for (v = 0; v < 4; v++)
	{
		vector_t ave;

		int v_inc = (v+1)&3;

		VectorAdd(&frustum_vtx[v], &frustum_vtx[v_inc], &ave);
		VectorAdd(&ave, &frustum_vtx[v_inc+4], &ave);
		VectorAdd(&ave, &frustum_vtx[v+4], &ave);
		VectorScale(&ave, 0.25f, &ave);
//		frustum_plane[v+2].pos =
//			(frustum_vtx[v] + frustum_vtx[v_inc] + frustum_vtx[v_inc+4] + frustum_vtx[v+4]) * 0.25;

		VectorPlaneUnitNormal(
			&frustum_vtx[v],
			&frustum_vtx[v_inc],
			&frustum_vtx[v_inc+4],
			&frustum_plane[v+2].normal);

		frustum_plane[v+2].dist_neg = -VectorDot(&frustum_plane[v+2].normal, &ave);
	}
}

//needs to be calculated every time either the frustum changes or the mouse coordinates change
void M_Camera::CalcMouseLine(void)
{
	/* 
   {screen space}

 ^
 1	[2]	 Z+  [1]
 |
 		 |
sy  Y+ --+-- Y-
 		 |
 |
 0	[3]	 Z-  [0]
 v
    <0-- sx --1>

	*/

	scalar_t sx = main_mouse->mouseSX;
	scalar_t sy = main_mouse->mouseSY;
	scalar_t nx = 1.f - sx;
	scalar_t ny = 1.f - sy;

	mouseLine.pos.x =
		frustum_vtx[1].x * sx * sy +
		frustum_vtx[2].x * nx * sy +
		frustum_vtx[0].x * sx * ny +
		frustum_vtx[3].x * nx * ny - position.x;
	mouseLine.pos.y =
		frustum_vtx[1].y * sx * sy +
		frustum_vtx[2].y * nx * sy +
		frustum_vtx[0].y * sx * ny +
		frustum_vtx[3].y * nx * ny - position.y;
	mouseLine.pos.z =
		frustum_vtx[1].z * sx * sy +
		frustum_vtx[2].z * nx * sy +
		frustum_vtx[0].z * sx * ny +
		frustum_vtx[3].z * nx * ny - position.z;

	if (!ortho) VectorCopy(&mouseLine.pos, &mouseLine.dir);
	else		VectorCopy(&matrix.vec[0], &mouseLine.dir);

	VectorAdd(&mouseLine.pos, &position, &mouseLine.pos);
}

//void M_Camera::CalculateMatrix(void)
//{
//	matrix = Matrix(angle);

	//change the axis array to a rotation matrix ? save 
//	for (v = 0; v < 3; v++)
//		axis[v] = RotateVector(vectorBaseAxis[v], angle);
//	axis[0] = *matrix.XAxis();
//	axis[1] = *matrix.YAxis();
//	axis[2] = *matrix.ZAxis();
//}


/*
Note about AddRotation():

normal quaternion rotation combination is as follows
q' = q2 * q
this adds the rotation of q2 to q

the camera quaternion is opposite of that (inverted) because when camera rotations
are added to the current camera angle, the rotations are done relative to the current
orientation of the camera instead of the identity orientation, as is implied in the
previous example.  because of this special case for camera rotations, the products
are multiplied backwards (resulting in an inverse rotation)
*/


// ********** TRACKING ********** 

void M_Camera::Update(void)
{
	//recalculate the position and angle

	switch (trackMethod)
	{
		//ignore CAM_TRACK_NO
	case (CAM_TRACK_YES):
		if (trackAngle) QuatCopy(trackAngle, &angle);
		if (trackPosition) VectorCopy(trackPosition, &position);
		break;

	case (CAM_TRACK_CHASE):
		//SLERP from the current angle to the track angle
		if (trackAngle)
		{
			quat_t destAngle;
			QuatMul(trackAngle, &chaseOffsetAngle, &destAngle);
			QuatSlerp(&angle, &destAngle, trackSlerpC, &angle);
		}

		if (trackPosition)
		{
			//rotate chase offset according to the current angle
			//add it to the tracking position
			//and you got your current position
			vector_t destPos;
			QuatRotateVector(&chaseOffsetPos, &angle, &destPos);
			VectorAdd(&destPos, trackPosition, &destPos);
			//destPos = (*trackPosition) + RotateVector(chaseOffsetPos, angle);

			//LERP from the current track position to the destination track position
			//btw, how 'bout that convergance of geometric infinite series?
			VectorSub(&destPos, &position, &destPos);
			VectorMultAdd(&position, &destPos, trackLerpC, &position);
			//position += (destPos - position) * trackLerpC;
		}

		break;
	}
}
