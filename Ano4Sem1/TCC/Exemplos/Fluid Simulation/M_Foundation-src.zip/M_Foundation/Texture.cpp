/*

    File: Texture.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include <windows.h>
#include <gl/gl.h>
#include <gl/glu.h>

//#define USE_JPEG

#include "texture.h"

#ifdef USE_JPEG
#include "jpeglib.h"
#endif //USE_JPEG

#include "main.h"				//main_console
#include "../m_system3d/error.h"

int GL_Type_to_BPP(int type) {
	switch (type) {
	case GL_BITMAP:			return 1;
	case GL_UNSIGNED_BYTE:
	case GL_BYTE:			return 8;
	case GL_UNSIGNED_SHORT:
	case GL_SHORT:			return 16;
	case GL_UNSIGNED_INT:
	case GL_INT:
	case GL_FLOAT:			return 32;
	}
	return 0;
}

int GL_Format_to_Components(int format) {
	switch (format) {
	case GL_COLOR_INDEX:
	case GL_RED:
	case GL_GREEN:
	case GL_BLUE:
	case GL_ALPHA:
	case GL_LUMINANCE:		return 1;
	case GL_LUMINANCE_ALPHA:return 2;
	case GL_RGB:			return 3;
	case GL_RGBA:			return 4;
	}
	return 0;
}

//NOTICE - THIS BELONGS IN IMAGE...but I haven't made the conversion quite yet...
int mBuild2DMipmaps(
	GLenum target, 
	GLint components, 
	GLint width, 
	GLint height, 
	GLenum format, 
	GLenum type, 
	const void *data
) {
	if (target != GL_TEXTURE_2D) return 1;
	if (components < 1 || components > 4) return 1;

	if (components != GL_Format_to_Components(format)) {
		main_console->Print("mBuild2DMipmaps - got a bad component number %d with format %d\n", components, format);
		return 1;
	}

	int bytes_pp = (GL_Type_to_BPP(type) >> 3);
	int data_size = width * height * components * bytes_pp;
	void *buffer = malloc(data_size);
	memcpy(buffer, data, data_size);

	for (int level = 0; ; level++) {
		//store the level
		glTexImage2D(target, level, components, width, height, 0, format, type, data);
		//reduce in size
		width>>=1;
		height>>=1;
		//if we dont have anything more to go then bail
		if (!width || !height) break;

		//reduce the bitmap *HERE*
	}
}
 

// ********** CONSTRUCTION/DESTRUCTION ********** 

void Texture::Destroy(void)
{
	if (texture_id) {
		glDeleteTextures(1, &texture_id);
	}
	Reset();
}

//private - only use when re-wiping it all - this should be done on init and when load fails
void Texture::Reset(void)
{
	memset(this, 0, sizeof(Texture));
	type = GL_TEXTURE_2D;	//by default
}

// ********** SETTING CURRENT TEXTURE ********** 

void Texture::Set(void)
{
	if (!type) return;
	
	//disable any previous targets
//	glDisable(GL_TEXTURE_1D);
//	glDisable(GL_TEXTURE_2D);
//	if (found_GL_ARB_texture_cube_map) {
//		glDisable(GL_TEXTURE_CUBE_MAP_ARB);
//	}
	//enable the target we're looking for
//	glEnable(type);
	//and bind the texture
	glBindTexture(type, texture_id);
}

// ********** MODIFYING TEXTURE ********** 

//todo - detect cubemap/tex3d and set accordingly
void Texture::SetWrap(int mode_s, int mode_t) {
	if (!type) return;
	glBindTexture(type, texture_id);
	glTexParameteri(type, GL_TEXTURE_WRAP_S, mode_s);
	glTexParameteri(type, GL_TEXTURE_WRAP_T, mode_t);
}

void Texture::SetFilter(int magnification, int minification) {
	if (!type) return;
	glBindTexture(type, texture_id);
	glTexParameteri(type, GL_TEXTURE_MAG_FILTER, magnification);
	glTexParameteri(type, GL_TEXTURE_MIN_FILTER, minification);
}

// ********** BASE FUNCTION USED BY ALL TEXTURE LOADERS ********** 

void Texture::InitOpenGLTexture(bool mipmap = true)
{
	//required for all textures
	glEnable(GL_TEXTURE);

	//this acts independant of the current texture
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	//required for our texture...
	glGenTextures(1, &texture_id);

	//needed?
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texture_id );

	//default settings
//	SetWrap(GL_REPEAT, GL_REPEAT);
	glTexParameteri(type, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(type, GL_TEXTURE_WRAP_T, GL_REPEAT);
//	SetFilter(GL_LINEAR, mipmap ? GL_LINEAR_MIPMAP_LINEAR : GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_MIN_FILTER, mipmap ? GL_LINEAR_MIPMAP_LINEAR : GL_LINEAR);
	glTexParameteri(type, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
}

// ********** TEXTURE PRE-CREATION ********** 

#include "console.h"

bool Texture::CreateEmpty(int width, int height, int internal_format, int external_format)
{
	Destroy();

	//data type being the format of the data used to store the image
	int bpp = GL_Type_to_BPP(external_format);
	int components = GL_Format_to_Components(internal_format);

	int size = (width * height * bpp * components) >> 3;

	unsigned char *data = (unsigned char *)malloc(size);
	if (!data) return false;

	memset(data, 0, size);

	InitOpenGLTexture(false);

	glTexImage2D(GL_TEXTURE_2D, 0, components, width, height, 0, internal_format, external_format, data);

// --- FREE --- 
	free(data);

	//main_console->Print("sucessfully created blank texture %d\n", texture_id);

	return true;
}

void Texture::UpdateData(int width, int height, int internal_format, int external_format, void *src)
{
	glBindTexture(GL_TEXTURE_2D, texture_id);
	glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width, height, internal_format, external_format, src);
}

// ********** TEXTURE ARRAY EXTRACTION ********** 

bool Texture::Extract(
	int width,
	int height,
	int internal_format,
	int external_format,
	const unsigned char *ptr,
	int colskip,
	int rowskip)
{
	Destroy();

	//data type being the format of the data used to store the image
	int bpp = GL_Type_to_BPP(external_format);
	int components = GL_Format_to_Components(internal_format);

	int pixelsize = (bpp * components) >> 3;
	int size = width * height * pixelsize;

	unsigned char *data = (unsigned char *)malloc(size);
	if (!data) return false;

	int i,j;
	const unsigned char *psrc_x, *psrc_y;
	unsigned char *pdest;

	pdest = data;
	psrc_y = ptr;
	for (j = 0; j < height; j++)
	{
		psrc_x = psrc_y;
		for (i = 0; i < width; i++)
		{
			for (int k = 0; k < pixelsize; k++) {
				pdest[k] = psrc_x[k];
			}
//			memcpy(pdest, psrc_x, pixelsize);
			pdest += pixelsize;
			psrc_x += colskip;
		}
		psrc_y += rowskip;
	}

	//create the OpenGL texture alias and init some of its required variables
	InitOpenGLTexture();

	gluBuild2DMipmaps (GL_TEXTURE_2D, components, width, height, internal_format, external_format, data);

// --- FREE --- 
	free(data);

	//main_console->Print("sucessfully extracted texture %d\n", texture_id);

	return true;
}

// ********** TEXTURE IMAGE LOADING ********** 

		//load the texture - return the texture ID
bool Texture::Create(const char *fn, bool mipmap, int format, bool border)
{
	Destroy();

	int nameSize = strlen(fn);
	memcpy(title, fn, nameSize > sizeof(title) ? sizeof(title) : nameSize);

// --- ALLOCATE AND LOAD --- 

	//attempt to load the texture data *here*
	unsigned char *data = LoadData(fn, border);
	if (!data)
	{
		Destroy();
		return false;
	}

// --- SET OPENGL VARS --- 
	InitOpenGLTexture(mipmap);

// --- LOAD TEXTURE --- 

	//load the texture data into Video RAM
/*
	glTexImage2D(
		GL_TEXTURE_2D,		//gl_texture_2d
		0,					//mipmap level
		3,					//internal format
		width,		//texture width
		height,	//texture height
		0,					//use border?
		GL_RGB,				//pixel data format
		GL_UNSIGNED_BYTE,	//pixel data type
		data);		//pixel data pointer
*/
	if (format == -1)	//default val if no param is passed thru
	{
		format = GL_RGB;
		if (bytes_per_pixel == 3) format = GL_RGB;
		else if (bytes_per_pixel == 4) format = GL_RGBA;
	}

	if (mipmap) {
		gluBuild2DMipmaps (GL_TEXTURE_2D, bytes_per_pixel, width, height, format, GL_UNSIGNED_BYTE, data);
	} else {
		if (border) {
			width += 2;
			height += 2;
		}
		glTexImage2D(GL_TEXTURE_2D, 0, bytes_per_pixel,
			width, height, border != 0, format, GL_UNSIGNED_BYTE, data);
	}

// --- FREE --- 
	free(data);

	//main_console->Print("sucessfully loaded texture %s as %d\n", fn, texture_id);

	return true;
}

// *********** LOAD TEXTURE *********
// responcible for choosing which of the above functions to use
// in loading data

/*
LoadTexture()
loads the texture image from the file specified in "filename"
and stores the contents in the texture_t structure
returns true on sucess, or false on failure
*/
unsigned char *Texture::LoadData(const char *fn, bool border)
{
	//set our method vars
	char ext[256] = {0};
	int i = strlen(fn);

	//initialize texture image vars
	width = height = 0;

	//copy over the file extension
	strncpy(ext, strrchr(fn, '.')+1, sizeof(ext));

	//BMP:
	if (!_stricmp(ext, "bmp"))
		return LoadBMP(fn, border);

	//TGA:
	if (!_stricmp(ext, "tga"))
		return LoadTGA(fn, border);

#ifdef USE_JPEG
	//JPEG
	if (!_stricmp(ext, "jpg") ||
		!_stricmp(ext, "jpeg"))
		return LoadJPEG(fn, border);
#endif //USE_JPEG

	//unknown:
	main_console->Print("Attempted to load an unknown texture extension %s\n", ext);
	return NULL;
}

#define TF_FLIP_Y	1
#define TF_SWAP_BR	2
#define TF_BORDER	4

unsigned char *Texture::ConvertData(unsigned char *src, int flags)
{
	int x, y, y_step, y_end;
	unsigned char *dest, *src_ptr, *dest_ptr;

	if (!src) return NULL;	//no data to convert


	int dest_width = width;
	int dest_height = height;
	if (flags & TF_BORDER) {
		dest_width += 2;
		dest_height += 2;
	}

	//couldnt allocate temp data
	dest = (unsigned char *)malloc(dest_width * dest_height * bytes_per_pixel);
	if (!dest)
	{
		free(src);
		return NULL;
	}
	memset(dest, 0, dest_width * dest_height * bytes_per_pixel);

	if (flags & TF_FLIP_Y)
	{
		y = height-1;
		y_step = -1;
		y_end = 0;
	}
	else
	{
		y = 0;
		y_step = 1;
		y_end = height-1;
	}

	dest_ptr = dest;
	if (flags & TF_BORDER) {
		dest_ptr += (1 + dest_width) * bytes_per_pixel;
	}

	for (; y != y_end+y_step; y += y_step)
	{
		src_ptr = &src[y*width*bytes_per_pixel];
		for (x = 0; x < (int)width; x++)
		{
			if (flags & TF_SWAP_BR)
			{
				dest_ptr[0] = src_ptr[2];
				dest_ptr[2] = src_ptr[0];
			}
			else
			{
				dest_ptr[0] = src_ptr[0];
				dest_ptr[2] = src_ptr[2];
			}
			dest_ptr[1] = src_ptr[1];

			if (bytes_per_pixel == 4) dest_ptr[3] = src_ptr[3];

			dest_ptr += bytes_per_pixel;
			src_ptr += bytes_per_pixel;
		}

		if (flags & TF_BORDER) {
			dest_ptr += 2 * bytes_per_pixel;
		}
	}

	//free original - and return the new
	free(src);

	return dest;
}



/*
bool TextureLoad___ (char *filename)

prereq: none
proreq:
	width contains the image in filename's width
	height contains the image in filename's height
	bytes_per_pixel contains the image in filename's bytes per pixel (3 or 4)
	data contains the interleaved RGB data

returns:
	true if loading all was sucessful
	false if an error occured (mind you, data will be freed if this occurs)
*/


//*********************************** LOAD THE IMAGE *********************************** 

/*
typedef struct {
  unsigned short        id PACKED;          //'BM' 0x4d42

  0  unsigned long         filesize PACKED;
  1  unsigned long         reserved PACKED;         //0
  2  unsigned long         pictureoffset PACKED;

  3  unsigned long         headersize PACKED;     //40
  4  unsigned long         width PACKED;
  5  unsigned long         height PACKED;
  6  unsigned short        planes PACKED;
     unsigned short        bpp PACKED;
  7  unsigned long         compression PACKED;
  8  unsigned long         picturesize PACKED;
  9  unsigned long         width_in_ppm PACKED;
  A  unsigned long         height_in_ppm PACKED;
  B  unsigned long         colors_used PACKED;
  C  unsigned long         important_colors PACKED;
} bmp_header;
*/

//bitmaps require (TEXTURE_FLAG_BGR)
unsigned char *Texture::LoadBMP(const char *filename, bool border)			// Loads A TGA File Into Memory
{    
	GLushort	BMPsignature = 0x4D42;
	GLushort	BMPcompare;
	GLuint		header[13];

	GLuint		bitsPerPixel;			//the src iamge's bits per pixel
	GLuint		imageSize;				//the dest image's size

	GLuint		rowSize, rowOffset;		//used for reading rows
	GLuint		tmpVar;

	unsigned char *rowPtr;

	GLubyte		palette[1024];
	GLuint		palIndexCount;

	DWORD		dwBytesRead;	//for ReadFile()


	//main_console->Print("Loading Bitmap %s\n", filename);

	//open the file
	HANDLE hFile = CreateFile(filename, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE)
	{
		main_console->Print("Texture::LoadBMP(%s): I Couldn't Open file\n", filename);
		return false;
	}


	if ((!ReadFile(hFile, &BMPcompare, sizeof(BMPcompare), &dwBytesRead, NULL)) ||
		(dwBytesRead != sizeof(BMPcompare)))
	{
		CloseHandle(hFile);
		main_console->Print( "Texture::LoadBMP(%s): I Couldn't Read The Bitmap Signature.  This Bitmap Is Probably Corrupt\n", filename);
		return false;
	}

	if (memcmp(&BMPcompare,&BMPsignature,sizeof(GLushort))!=0)
	{
		CloseHandle(hFile);
		main_console->Print("Texture::LoadBMP(%s): The Bitmap ID Was Incorrect.  This Bitmap Is Probably Corrupt\n", filename);
		return false;
	}

	if ((!ReadFile(hFile, header, sizeof(header), &dwBytesRead, NULL)) ||
		(dwBytesRead != sizeof(header)))

	{
		CloseHandle(hFile);
		main_console->Print("Texture::LoadBMP(%s): I Couldnt Read The Bitmap Header.  This Bitmap Is Probably Corrupt\n", filename);
		return false;
	}

	width  = header[4];
	height = header[5];
	bitsPerPixel = HIWORD(header[6]);
	palIndexCount = header[11];

	if (bitsPerPixel != 1 && 
		bitsPerPixel != 4 &&
		bitsPerPixel != 8 &&
		bitsPerPixel != 24)
	{
		CloseHandle(hFile);
		main_console->Print("Texture::LoadBMP(%s): The Bits Per Pixel Is %d, An Unsupported Value.\n", filename, bitsPerPixel);
		return false;
	}

	if (header[7])
	{
		CloseHandle(hFile);
		main_console->Print("Texture::LoadBMP(%s): We Do Not Yet Support RLE Compressed BMP files.  This Image is RLE Compressed\n", filename);
		return false;
	}

	if (bitsPerPixel <= 8)	bytes_per_pixel = 3;
	else					bytes_per_pixel = (bitsPerPixel>>3);

	//for allocation...
	imageSize	= width * height * bytes_per_pixel;

	unsigned char *data = (unsigned char *)malloc(imageSize);

	if(data==NULL)
	{
		main_console->Print("Texture::LoadBMP(%s): I Couldnt Allocate Memory To Load The Image\n", filename);
		CloseHandle(hFile);
		return false;
	}

	if (tmpVar = (header[2] - 54))					//if an offset to the image exists...
	{
		unsigned int palSize, extraSize;
		//if (palIndexCount > 256) then we cant grab all the indecies

		if (palIndexCount == 0) palSize = tmpVar > 1024 ? 1024 : tmpVar;
		else palSize = (palIndexCount<<2);

		extraSize = tmpVar - palSize;

		if (palSize > 0)
		{

			//if (fread(palette, 1, palSize, file) != palSize)
			if ((!ReadFile(hFile, palette, palSize, &dwBytesRead, NULL)) ||
				(dwBytesRead != palSize))
			{
				free(data);	data = NULL;
				CloseHandle(hFile);
				main_console->Print("Texture::LoadBMP(%s): There Was An Error Reading The Palette\n", filename);
				return false;
			}
		}

		if (extraSize > 0)
		{
//			if (fseek(file, extraSize, SEEK_CUR))
			if (SetFilePointer(hFile, extraSize, NULL, FILE_CURRENT) == 0xFFFFFFFF)
			{
				free(data);	data = NULL;
				CloseHandle(hFile);
				main_console->Print("Texture::LoadBMP(%s): There Was An Error Seeking To The Image Data\n", filename);
				return false;
			}
		}
	}

	//for reading the rows of the bitmap and for calc'ing the row offset
	rowSize = width * bitsPerPixel;
	rowSize = (rowSize>>3) + !!(rowSize & 7);

	//waste of space - thank the people at microsoft for this idea - the row offset
	rowOffset		= rowSize&3;
	if (rowOffset)	rowOffset = 4-rowOffset;

	//used for indexed bitmaps:
	GLubyte curByte;
	int current_bit_offset = 8 - bitsPerPixel;
	int pixels_per_byte = 8 / bitsPerPixel;
	int pixel_bitmask = (1 << bitsPerPixel) - 1;
	int index;

	rowPtr = data;
	for (int y = 0; y < (int)height; y++)
	{
		//load the poop as indexed, then convert it from the palette
		if (bitsPerPixel <= 8)
		{
			//load these per-byte and convert them as we go
			for (int x = 0; x < (int)width; x++)
			{
				if ((x % pixels_per_byte) == 0)
				{
					current_bit_offset = 8 - bitsPerPixel;
					if ((!ReadFile(hFile, &curByte, 1, &dwBytesRead, NULL)) ||
						(dwBytesRead != 1))
					{
						free(data);	data = NULL;
						CloseHandle(hFile);
						main_console->Print("Texture::LoadBMP(%s): There Was An Error Reading Image Byte <%d,%d>\n", filename, x, y);
						return false;
					}

					index = (curByte >> current_bit_offset) & pixel_bitmask;
					current_bit_offset -= bitsPerPixel;
					memcpy(rowPtr, &palette[index<<2], bytes_per_pixel);
				}
				else
				{
					index = (curByte >> current_bit_offset) & pixel_bitmask;
					current_bit_offset -= bitsPerPixel;
					memcpy(rowPtr, &palette[index<<2], bytes_per_pixel);
				}
				rowPtr += bytes_per_pixel;
			}
		}
		else
		{	//load the poop as true color
			if ((!ReadFile(hFile, rowPtr, rowSize, &dwBytesRead, NULL)) ||
				(dwBytesRead != rowSize))
			{
				free(data);	data = NULL;
				CloseHandle(hFile);
				main_console->Print("Texture::LoadBMP(%s): There Was An Error Reading Image Row %d\n", filename, y);
				return false;
			}
			rowPtr += rowSize;
		}

		if (rowOffset)
		{
			if (SetFilePointer(hFile, rowOffset, NULL, FILE_CURRENT) == 0xFFFFFFFF)
			{
				free(data);	data = NULL;
				CloseHandle(hFile);
				main_console->Print("Texture::LoadBMP(%s): I was Unable to Seek Through the Offset of Row %d\n", filename, y);
				return false;
			}
		}
	}

	CloseHandle(hFile);

	//main_console->Print("Loaded Bitmap %s\n", filename);

	int convert_flags = TF_SWAP_BR | TF_FLIP_Y;
	if (border) convert_flags |= TF_BORDER;
	return ConvertData(data, convert_flags);
}

	/*
	TGA header:
	{
		0	1 byte		imageID			-> number of bytes in colormap first index
		1	1 byte		colorMapType
		2	1 byte		imageType

		combinations of [1]::[2]
		{
			1,1 -> color mapped
			0,2 -> true color
			0,3 -> greyscale
			1,9 -> RLE encoded color mapped
			0,10 -> RLE encoded true color
			0,11 -> RLE greyscale
		}

						(zero if no colormap is used):
		3	2 short	colorMap.firstEntryIndex - starting entry of the colormap
		5	2 short	colorMap.length  - number of entries in the color map
		7	1 byte	colorMap.entrySize - the number of bits per entry: (15,16,24,32)

		8	2 short		x origin of image
		10	2 short		y origin of image
		12	2 short		width of image
		14	2 short		height of image
		16	1 byte		bits per pixel
		17	1 byte		image descriptor
	}

	next comes the colormap info - size equal to colorMap.length * bytes per each colorMap entry

    and then the BGR interleaved image data
	*/


//TGAs require TEXTURE_FLAG_BGR
unsigned char *Texture::LoadTGA(const char *filename, bool border)
{
	int			flags = TF_SWAP_BR | TF_FLIP_Y;

	GLubyte		header[18];
	GLuint		bitsPerPixel;
	GLuint		imageSize;
	GLuint		rowSize;

	unsigned char *rowPtr;

	//main_console->Print("Loading TGA %s\n", filename);
	DWORD dwBytesRead;

	//open the file
	HANDLE hFile = CreateFile(filename, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE)
	{
		main_console->Print("Texture::LoadTGA(%s): unable to open file\n", filename);
		return false;
	}

	//try to reset the file ptr, if thats the problem
	if (SetFilePointer(hFile, 0, NULL, FILE_CURRENT) == 0xFFFFFFFF)
	{
		CloseHandle(hFile);
		main_console->Print("Texture::LoadTGA(%s): error resetting the file ptr\n", filename);
		return false;
	}

//	if (fread(header,1,sizeof(header),file) != sizeof(header))
	if ((!ReadFile(hFile, header, sizeof(header), &dwBytesRead, NULL)) ||
		(dwBytesRead != sizeof(header)))
	{
		CloseHandle(hFile);
		main_console->Print("Texture::LoadTGA(%s): couldnt read header\n", filename);
		return false;
	}

//	if (fseek(file, header[0], SEEK_CUR))
	if (SetFilePointer(hFile, header[0], NULL, FILE_CURRENT) == 0xFFFFFFFF)
	{
		CloseHandle(hFile);
		main_console->Print("Texture::LoadTGA(%s): error trying to seek past image ID info\n", filename);
		return false;
	}


	//indexed color stuff:
	unsigned char *colorMap = NULL;
	int colorMapCount;
	int colorMapBits, colorMapBytes;

	if (header[1])		//a color map is present - lets read it
	{
		colorMapCount = *(GLushort *)(&header[5]);
		colorMapBits = header[7];

		//my way of rounding up - base 8
		colorMapBytes = (colorMapBits>>3) + !!(colorMapBits & 7);

		colorMap = (unsigned char *)malloc(colorMapCount * colorMapBytes);
		if (colorMap == NULL)
		{
			main_console->Print("Texture::LoadTGA(%s): couldnt allocate memory for the TGA's palette\n", filename);
			CloseHandle(hFile);
			return false;
		}
	}

	int imageType = header[2] & 7;
	int RLEcompressed = header[2] & 8;
	if (RLEcompressed)
	{
		main_console->Print("Texture::LoadTGA(%s): this TGA file just happens to be RLE, which I dont support yet\n", filename);
		if (colorMap) free(colorMap);
		colorMap = NULL;
		CloseHandle(hFile);
		return false;
	}

	width = *(GLushort *)(&header[12]);
	height = *(GLushort *)(&header[14]);
	bitsPerPixel = header[16];
	int src_bytesPerPixel = bitsPerPixel>>3;

	if (src_bytesPerPixel == 4) bytes_per_pixel = 4;
	else bytes_per_pixel = 3;

	if (header[17] & 0x20) flags ^= TF_FLIP_Y;		//vertical flip
	//if (header[17] & 0x10) flags |= TF_FLIP_X;		//horizontal flip

 	if(bitsPerPixel != 8 && bitsPerPixel !=24 && bitsPerPixel!=32)
	{
		if (colorMap) free(colorMap);
		colorMap = NULL;
		CloseHandle(hFile);
		main_console->Print("Texture::LoadTGA(%s): This TGA is not of either 8,24, or 32 bits per pixel\n", filename);
		return false;
	}

	imageSize = width * height * bytes_per_pixel;

	unsigned char *data = (unsigned char *)malloc(imageSize);
	if(data==NULL)
	{
		CloseHandle(hFile);
		if (colorMap) free(colorMap);
		colorMap = NULL;
		main_console->Print("Texture::LoadTGA(%s): couldnt allocate the image data\n", filename);
		return false;
	}

//	for(temp=0; temp<(int)imageSize; temp++) data[temp]=0;

	rowSize	= width * src_bytesPerPixel;

	rowPtr = data;
	int x;
	for (int y = 0; y < (int)height; y++)
	{
		if (bitsPerPixel == 8)
		{
			GLubyte t;
			for (x = 0; x < (int)width; x++)
			{
//				if (fread(&t, 1, 1, file) != 1)
				if ((!ReadFile(hFile, &t, 1, &dwBytesRead, NULL)) ||
					(dwBytesRead != 1))
				{
					if (colorMap) free(colorMap);
					colorMap = NULL;
					free(data);	data = NULL;
					CloseHandle(hFile);
					main_console->Print("Texture::LoadTGA(%s): error in reading this TGA\n", filename);
					return false;
				}

				if (header[1] == 0 && header[2] == 3)	//greyscale 8bit image
				{
					rowPtr[2] = rowPtr[1] = rowPtr[0] = t;
				}
				else if (header[1] == 1 && header[2] == 1)
				{
					if (colorMap == NULL)
					{
						main_console->Print("Texture::LoadTGA(%s): colormap hasnt been found\n", filename);
						free(data);	data = NULL;
						CloseHandle(hFile);
						return false;
					}
					memcpy(rowPtr, &colorMap[t*3], 3);
				}

				rowPtr += 3;
			}
		}
		else
		{
//			if (fread(rowPtr, 1, rowSize, file) != rowSize)
			if ((!ReadFile(hFile, rowPtr, rowSize, &dwBytesRead, NULL)) ||
				(dwBytesRead != rowSize))
			{
				free(data);	data = NULL;
				if (colorMap) free(colorMap);
				colorMap = NULL;
				CloseHandle(hFile);
				main_console->Print("Texture::LoadTGA(%s): couldnt read texture row\n", filename);
				return false;
			}
			rowPtr += rowSize;
		}
	}

	if (colorMap) free(colorMap);
	colorMap = NULL;

	CloseHandle (hFile);

	if (border) flags |= TF_BORDER;

	return ConvertData(data, flags);
}

unsigned char *Texture::LoadJPEG(const char *fn, bool border) {
#ifdef USE_JPEG
	struct jpeg_decompress_struct cinfo;
	FILE *pFile;

	// Open a file pointer to the jpeg file and check if it was found and opened 
	if((pFile = fopen(fn, "rb")) == NULL) 
	{
		// Display an error message saying the file was not found, then return NULL
		Error("Unable to load JPG File!");
		return NULL;
	}
	
	// Create an error handler
	jpeg_error_mgr jerr;

	// Have our compression info object point to the error handler address
	cinfo.err = jpeg_std_error(&jerr);
	
	// Initialize the decompression object
	jpeg_create_decompress(&cinfo);
	
	// Specify the data source (Our file pointer)	
	jpeg_stdio_src(&cinfo, pFile);

	unsigned char *data = NULL;
	
	// Decode the jpeg file and fill in the image data structure to pass back
	{
		// Read in the header of the jpeg file
		jpeg_read_header(&cinfo, TRUE);
		
		// Start to decompress the jpeg file with our compression info
		jpeg_start_decompress(&cinfo);

		type = GL_TEXTURE_2D;

		// Get the image dimensions and channels to read in the pixel data
		switch (cinfo.num_components) {
		case 3:
			bytes_per_pixel = GL_RGB;
			break;
		case 4:
			bytes_per_pixel = GL_RGBA;
			break;
		default:
			main_console->Print("Texture::LoadJPEG(): got an invalid num components: %d\n", cinfo.num_components);
			return NULL;
		}

		width = cinfo.image_width;
		height = cinfo.image_height;

		// Get the row span in bytes for each row
		int rowSpan = cinfo.image_width * cinfo.num_components;
		
		// Allocate memory for the pixel buffer
		data = (unsigned char*)malloc(sizeof(unsigned char) * rowSpan * height);

		// Create an array of row pointers
		unsigned char** rowPtr = new unsigned char*[height];

		for (int i = 0; i < (int)height; i++)
			rowPtr[i] = &data[i * rowSpan];

		// Now comes the juice of our work, here we extract all the pixel data
		int rowsRead = 0;
		while (cinfo.output_scanline < cinfo.output_height) 
		{
			// Read in the current row of pixels and increase the rowsRead count
			rowsRead += jpeg_read_scanlines(&cinfo, &rowPtr[rowsRead], cinfo.output_height - rowsRead);
		}
		
		// Delete the temporary row pointers
		delete [] rowPtr;

		// Finish decompressing the data
		jpeg_finish_decompress(&cinfo);
	}
	
	// This releases all the stored memory for reading and decoding the jpeg
	jpeg_destroy_decompress(&cinfo);
	
	// Close the file pointer that opened the file
	fclose(pFile);

	// Return the jpeg data (remember, you must free this data after you are done)
	return ConvertData(data, 0/*flags*/);
#else //USE_JPEG
	return false;
#endif //USE_JPEG
}

// ********** CUBE MAP TEXTURE ********** 
bool Texture::CreateCubeMap(const char *fn[7], bool mipmap, int requested_format)
{
	int side;

	//clear current contents
	Destroy();

	//need HW cube mapping from here on out
	if (!found_GL_ARB_texture_cube_map) return false;

	//make sure all texture names are present
	for (side = 0; side < 7; side++)
		if (!fn[side]) return false;

	//and create the new stuff
	int nameSize = strlen(fn[6]);
	memcpy(title, fn[6], nameSize > sizeof(title) ? sizeof(title) : nameSize);

// --- SET OPENGL VARS --- 
	glEnable(GL_TEXTURE);
	glEnable(GL_TEXTURE_CUBE_MAP_ARB);

	//this acts independant of the current texture
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	glGenTextures(1, &texture_id);
	glBindTexture(GL_TEXTURE_CUBE_MAP_ARB, texture_id );

	//these are all dependant on the current bound texture
	glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_CUBE_MAP_ARB, GL_TEXTURE_MIN_FILTER, mipmap ? GL_LINEAR_MIPMAP_LINEAR : GL_LINEAR);

	for (side = 0; side < 6; side++)
	{
		unsigned char *data = LoadData(fn[side]);
// --- ALLOCATE AND LOAD --- 
		if (!data)
		{
			Destroy();
			glDisable(GL_TEXTURE_CUBE_MAP_ARB);
			return false;
		}

// --- LOAD TEXTURE --- 
		int format = requested_format;
		if (format == -1)
		{
			if (bytes_per_pixel == 3) format = GL_RGB;
			else if (bytes_per_pixel == 4) format = GL_RGBA;
		}

		gluBuild2DMipmaps (GL_TEXTURE_CUBE_MAP_POSITIVE_X_ARB + side,
			bytes_per_pixel, width, height, format, GL_UNSIGNED_BYTE, data);

// --- FREE --- 
		free(data);
		data = NULL;
	}

	//main_console->Print("sucessfully loaded cubemap texture %s as %d\n", title, texture_id);

	glDisable(GL_TEXTURE_CUBE_MAP_ARB);

	this->type = GL_TEXTURE_CUBE_MAP_ARB;

	return true;
}
/*
Texture *GetTexture(LinkedList *p, char *title)
{
	for (Texture *t = (Texture *)(p->head); t; t = (Texture *)(t->chain_next))
		if (!_stricmp(title, t->title)) break;

	return t;
}
*/