/*

    File: Console.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/

/*
TODO:
cleanup the whole system
dont allow ParseArguments() to modify the cmd[] data
better active/inactive load success/fail handling
make font system a separate module
work independant of windows' virtual key stuff
*/


#ifndef M_FOUNDATION_CONSOLE_H
#define M_FOUNDATION_CONSOLE_H

#define MAX_ARGV	16

/*
The Console Class!
This holds the font, and handles all the IO commands

currently is a mess
*/
#include "texture.h"
#include "cvar.h"
#include "critsec.h"

class M_CVar;

class M_Console {
public:
	M_Console();
	bool Init(int w, int h);

	~M_Console() {Kill();}
	void Kill(void);

	//gathers all keystrokes recorded in the last frame - interprets them
	void PreUpdate(void);

	//fixes whatever damage PreUpdate did to the input headed toward the application layer
	void PostUpdate(void);
	
	//shell for AddString() - interprets the *_format
	void Print(const char *_format, ...);

	//displays the console
	void Display(void);

	//sets whether the console is visible when inactive
	void SetIdleVisible(bool isvis);

	//used via console command - set the console's info (drop time, width, height)
	void SetInfo(int argc, char **argv);

private:

	//issued when Update() records a key being pressed
	bool KeyDown(int key);

	//when KeyDown() records a '~' - toggles console display & input trapping
	void Toggle(void);

	//when KeyDown() records anything else - add a key to the input buffer
	void AddToInput(char key);

	//clear the current input buffer
	void ClearInput(void);

	//adds a string to the output window
	void AddString(char *append_data);

	//displays a console line - called by Display()
	void DisplayLine(char *p, int len);

#define CMD_LENGTH		256
#define PREV_CMD_MAX	32

	int last_prev_cmd;							//used for cycling thru the prev cmd buffer
	int inkey_next;
	char inputcmd[PREV_CMD_MAX][CMD_LENGTH];			//the current cmd being typed
	char textbuffer[8192];		//the current text buffer

	//for locking the console
	CCriticalSection cs;

//this is me being bad.
//we really need a separate font system
public:
	Texture *font;		//texture class of the font used
private:

	//used for toggling the console
	bool isActive;

//modifyable variables
	//used for whether the console is visible when idle
	bool idleVisible;

	//amount of chars to display in the console
	int width, height;

public://no harm in on-the-fly modifications of this variable
	//how far to drop when idle
	int idleDropdown;
private:

	//how long it takes to drop
	double droptime;

	//the type of dropdown display method
	int droptype;

//internally used variables
	//when the console starts to drop
	double dropstart;		//time_t

	//the percentage of the timestep the console is through the dropdown procedure
	float timefrac;

	//////////////// my attempt at C++izing this all ////////////////

public:

};

inline M_Console &operator<<(M_Console &con, const char *str) { con.Print("%s", str); return con; }
inline M_Console &operator<<(M_Console &con, float f) { con.Print("%f", f); return con; }
inline M_Console &operator<<(M_Console &con, double f) { con.Print("%f", f); return con; }
inline M_Console &operator<<(M_Console &con, int f) { con.Print("%d", f); return con; }

#endif