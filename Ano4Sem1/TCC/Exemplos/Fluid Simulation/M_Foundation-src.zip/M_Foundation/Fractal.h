/*

    File: Fractal.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#ifndef M_FOUNDATION_FRACTAL_H
#define M_FOUNDATION_FRACTAL_H

bool Fractal_Create(float *data, float min, float max, int width, int height, int step_size, int filter_level);

bool Blur_Array(float *data, float *blend, int width, int height, int data_step_size, int blend_step_size);

bool Normalize_Array(float *data, int count, int step_size);

bool Scale_Array(float *data, int count, int step_size, float scale);
bool Add_Array(float *data, int count, int step_size, float add);

#endif