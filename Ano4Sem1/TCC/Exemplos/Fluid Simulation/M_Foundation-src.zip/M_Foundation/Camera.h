/*

    File: Camera.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#ifndef M_FOUNDATION_CAMERA_H
#define M_FOUNDATION_CAMERA_H

#include "../m_math3d/geometry.h"
#include "../m_math3d/matrix.h"

class M_Camera {
public:
	//creation
	M_Camera();
	M_Camera(M_Camera *src);	//create a cam from another cam
	bool Init();

	//destruction
	~M_Camera() {Kill();}
	void Kill();

	//OpenGL transformation
public:

#define CAMERA_RESET_PROJECTION		1
#define CAMERA_RESET_ROTATION		2
#define CAMERA_RESET_TRANSLATION	4

	void TransformScene(int flags);

	//the resetting of the frustum
	void CalculateFrustum(void);
	void CalcMouseLine(void);

private:
	void SetProjection(void);
	void SetModelview(int flags);
	//the functions of SetModelview() - rotate, translate, scale (scale used for mirrors)
	void RotateScene(void);
	void TranslateScene(void);

public:
	void Activate(void);
	bool active;

/*
		vars:			influences:
	halfWidth		frustum_plane,frustum_vtx,PROJECTION
	halfHeight		frustum_plane,frustum_vtx,PROJECTION
	adjustRatio		frustum_plane,frustum_vtx,PROJECTION
	znear			frustum_plane,frustum_vtx,PROJECTION
	zfar			frustum_plane,frustum_vtx,PROJECTION
	mirror			frustum_plane,frustum_vtx,PROJECTION
	flip			frustum_plane,frustum_vtx,PROJECTION
	ortho			frustum_plane,frustum_vtx,PROJECTION

	angle			matrix,frustum_plane,frustum_vtx,MODELVIEW
	position		frustum_plane,frustum_vtx,MODELVIEW

	matrix
	frustum_vtx
	frustum_plane
*/

// ********** FRUSTUM SHAPE ********** 
public:

	//true -> orthogonal, false -> frustum
	bool	ortho;

	//the half width and half height at unit distance for frustum view
	//the constant width and height for ortho view
	//why did i choose halfwidth & halfheight?  so setting the values to 1 would cause a 90 degree FOV
	float	halfWidth, halfHeight;	

#define CAMERA_ADJUST_NO		0
#define CAMERA_ADJUST_HEIGHT	1
#define CAMERA_ADJUST_WIDTH		2
	//whether or not to adjust the aspect ratio for non-square display dimensions
	int		adjustRatio;

	//near and far clip planes
	float	znear, zfar;

// ********** FRUSTUM DATA ********** 

//calculated based upon other stats:
	//camera orientation matrix
	matrix_t	matrix;
	
	//created based on znear, zfar, halfWidth, halfHeight, adjustRatio, ortho, position, and angle
	vector_t	frustum_vtx[8];
	
	//six planes of occulsion to define the camear view volume
	plane_t		frustum_plane[6];

// ********** MOUSE INTERFACE ********** 
	//mouse interface - vector from camera location origin to where
	//the mouse cursor would appear in world coordinates - a distance
	//'znear' from the camera position
	//
	//for mouse tracelineing:
	//	in ortho view, traceline
	//		from (mouseVector * znear)
	//		to (mouseVector * znear) + axis[0] * (zfar - znear)
	//	in frustum view, traceline
	//		from (mouseVector * znear)
	//		to (mouseVector * (zfar - znear))

	//containing the mouse cursor worldspace origin and the mouse worldspace direction vector
	//mouseLine.pos = mouse cursor in worldspace
	//mouseLine.dir = mouse direction vector in units of one per camera depth unit
	line_t	mouseLine;

// ********** ORIENTATION ********** 
public:
	vector_t	position;
	quat_t		angle;
	bool		mirror;
	bool		flip;

// ********** TRACKING ********** 
#define CAM_TRACK_NO		0
#define CAM_TRACK_YES		1
#define CAM_TRACK_CHASE		2

public:
	void Update(void);

	vector_t	*trackPosition;
	quat_t		*trackAngle;
	int			trackMethod;
	scalar_t	trackLerpC;		//the LERP coefficient - tracking position
	scalar_t	trackSlerpC;	//the slerp coefficient from the current to the tracking angle
	vector_t	chaseOffsetPos;
	quat_t		chaseOffsetAngle;

};

extern float Camera_DefaultMatrix[16];
extern float Camera_DefaultMatrixInverse[16];

#endif