/*

    File: Chain.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#include <windows.h>	//for NULL definition
#include "chain.h"

Chain::Chain()
{
	chain_parent = NULL;
	chain_prev = NULL;
	chain_next = NULL;
}

Chain::~Chain()
{
	Unlink();		//then unlink it
}

//methods called from links within a chain
//to add them to a parent chain

/*
void Chain::Link(LinkedList *p)
{
	//if a parent already exists then unlink it from its current chain
	if (chain_parent) Unlink();

	chain_parent = p;
	if (!chain_parent) return;

	if (!chain_parent->chain_head) chain_parent->chain_head = this;
	if (chain_parent->chain_tail) chain_parent->chain_tail->chain_next = this;

	chain_prev = chain_parent->chain_tail;
	chain_next = NULL;
	chain_parent->chain_tail = this;
}
*/

#include <assert.h>

//adds link to the specified chain's parent, just after the specified chain
void Chain::LinkBefore(Chain *c)
{
	//unlink it from its current parent (if any)
	if (chain_parent) Unlink();

	assert(c);
	assert(c->chain_parent);

	//set its new parent
	chain_parent = c->chain_parent;
	
	//set the current link prev and next
	chain_prev = c->chain_prev;
	chain_next = c;

	//link all other to this one
	c->chain_prev = this;
	//if there exists a prev link in the chain then set its chain_next to 'this'
	if (chain_prev) chain_prev->chain_next = this;
	//else, 'this' lies at the beginning of the chain - set the parent head to 'this'
	else chain_parent->head = this;
}

//adds link to the specified chain's parent, just after the specified chain
void Chain::LinkAfter(Chain *c)
{
	//unlink it from its current parent (if any)
	if (chain_parent) Unlink();

	assert(c);
	assert(c->chain_parent);

	//set its new parent
	chain_parent = c->chain_parent;
	
	//set the current link prev and next
	chain_prev = c;
	chain_next = c->chain_next;

	//link all other to this one
	c->chain_next = this;
	//if there exists a next link in the chain then set its prev to 'this'
	if (chain_next) chain_next->chain_prev = this;
	//else, 'this' lies at the end of the chain - set the parent tail to 'this'
	else chain_parent->tail = this;
}

void Chain::Unlink(void)
{
	if (!chain_parent) return;
	
	if (this == chain_parent->head) chain_parent->head = chain_next;
	if (this == chain_parent->tail) chain_parent->tail = chain_prev;

	if (chain_prev) chain_prev->chain_next = chain_next;
	if (chain_next) chain_next->chain_prev = chain_prev;

	chain_parent = NULL;
}

LinkedList::LinkedList()
{
	head = tail = NULL;
}

LinkedList::~LinkedList()
{
	UnlinkAll();
}

//methods called by a parent chain
//to remove children
// NOTICE - if this is called not by a link within a chain
//but instead by a child of a certain chain
//then this will unlink all members of that chain linked *AFTER* 'this'
void LinkedList::UnlinkAll(void)
{
	Chain *v, *next;
	for (v = head; v; )
	{
		next = v->chain_next;
		if (v->chain_parent == this) v->Unlink();
		v = next;
	}
	head = tail = NULL;
}

void LinkedList::DeleteAll(void)	//deletes all children of the chain
{
	Chain *v, *next;
	for (v = head; v; )
	{
		next = v->chain_next;
		if (v->chain_parent == this) delete v;
		v = next;
	}
	head = tail = NULL;
}

int LinkedList::Count(void)
{
	int cnt = 0;
	for (Chain *v = head; v; v=v->chain_next) cnt++;
	return cnt;
}

void LinkedList::AddLast(Chain *c)
{
	if (!c) return;

	//if a parent already exists then unlink it from its current chain
	if (c->chain_parent) c->Unlink();
	c->chain_parent = this;

	if (!head) head = c;
	if (tail) tail->chain_next = c;

	c->chain_prev = tail;
	c->chain_next = NULL;
	tail = c;
}

