/*

    File: Const.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#ifndef M_FOUNDATION_CONST_H
#define M_FOUNDATION_CONST_H

#if !defined(M_PI)
#define M_PI            3.14159265358979323846
#endif

#if !defined(M_SQRT_2)
#define M_SQRT_2		1.4142135623730951454746218587388284504410
#endif

#if !defined(M_SQRT_3)
#define M_SQRT_3		1.732050807568877193176604123436845839024
#endif

#if !defined(DEGREE_TO_RADIAN)
#define DEGREE_TO_RADIAN	0.017453292519943295474371680597869271878
#endif

#if !defined(RADIAN_TO_DEGREE)
#define RADIAN_TO_DEGREE	(1.0/DEGREE_TO_RADIAN)
#endif

#if !defined(NULL)
#define NULL 0
#endif

extern double Inf;
extern float fInf;		//located in main.cpp for now

#include "../m_math3d/vector.h"
#include "../m_math3d/quat.h"
#include "../m_math3d/matrix.h"
#include "../m_math3d/geometry.h"

extern vector_t vectorZero;
extern vector_t vectorBaseAxis[3];
extern quat_t	quatIdentity;
extern quat_t	quatZero;
extern matrix_t matrixIdentity;
extern matrix_t matrixZero;
extern box_t	boxZero;
extern box_t	boxNull;		//contains infinite bounds in opposite directions.  perfect for stretching

void Calc_Constants(void);

#endif
