/*

    File: Chain.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#ifndef M_FOUNDATION_CHAIN_H
#define M_FOUNDATION_CHAIN_H

class LinkedList;

/*
  one class to contain the header/tail of the link
  another class to contain the prev/next pointers, as well as the pointer to the data
*/

class Chain {

public:
	Chain();				//constructor : nulls all pointers
	~Chain();				//destructor - unlinks all chains

//	void Link(LinkedList *p);	//adds the link to the end of the linked list
	void LinkBefore(Chain *c);	//adds link to the specified chain's parent, just before the specified chain;
	void LinkAfter(Chain *c);	//adds link to the specified chain's parent, just after the specified chain
	void Unlink(void);		//and removes the link from the current parent chain

	Chain	*chain_prev;		//points to the prev node of the link within the chain
	Chain	*chain_next;		//points to the next node in the chain

	//pointer to the chain parent (which contains the head/tail of the chain)
	LinkedList	*chain_parent;
};

class LinkedList {
public:
	LinkedList();
	~LinkedList();

	void UnlinkAll(void);	//unlinks all children of the chain
	void DeleteAll(void);	//deletes all children of the chain

	void AddLast(Chain *c);

	Chain *operator[](int i)
	{
		Chain *r = head;
		for (;i > 0 && r; i--) r = r->chain_next;
		return r;
	}

	int Count(void);

	Chain *head;				//points to the head of the linked list
	Chain *tail;				//points to the tail of the chain
};

#endif