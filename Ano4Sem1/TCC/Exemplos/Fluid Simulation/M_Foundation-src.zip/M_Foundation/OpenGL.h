/*

    File: OpenGL.h

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
#if !defined(M_FOUNDATION_OPENGL_H)
#define M_FOUNDATION_OPENGL_H

#include <windows.h>
#include <gl/gl.h>
#include "glext.h"

//not in my glext.h

typedef void *(APIENTRY * PFNWGLALLOCATEMEMORYNV) (GLsizei size, GLfloat readFrequency, GLfloat writeFrequency, GLfloat priority);
typedef void (APIENTRY * PFNWGLFREEMEMORYNV) (GLvoid *pointer);

//GL_ARB_texture_env_combine constants

#define GL_COMBINE_ARB			0x8570
#define GL_COMBINE_RGB_ARB		0x8571
#define GL_COMBINE_ALPHA_ARB	0x8572
#define GL_CONSTANT_ARB			0x8576
#define GL_PRIMARY_COLOR_ARB	0x8577
#define GL_PREVIOUS_ARB			0x8578
#define GL_SOURCE0_RGB_ARB		0x8580
#define GL_SOURCE1_RGB_ARB		0x8581
#define GL_SOURCE0_ALPHA_ARB	0x8588
#define GL_SOURCE1_ALPHA_ARB	0x8589
#define GL_OPERAND0_RGB_ARB		0x8590
#define GL_OPERAND1_RGB_ARB		0x8591
#define GL_OPERAND0_ALPHA_ARB	0x8598
#define GL_OPERAND1_ALPHA_ARB	0x8599
#define GL_DOT3_RGB_ARB			0x86AE
#define GL_DOT3_RGBA_ARB		0x86AF

extern bool								found_GL_ARB_texture_env_combine;

extern bool								found_GL_ARB_texture_cube_map;

extern bool								found_GL_ARB_multitexture;
extern PFNGLMULTITEXCOORD2FARBPROC		glMultiTexCoord2fARB;
extern PFNGLMULTITEXCOORD2FVARBPROC		glMultiTexCoord2fvARB;
extern PFNGLMULTITEXCOORD3FARBPROC		glMultiTexCoord3fARB;
extern PFNGLMULTITEXCOORD3FVARBPROC		glMultiTexCoord3fvARB;
extern PFNGLACTIVETEXTUREARBPROC		glActiveTextureARB;
extern PFNGLCLIENTACTIVETEXTUREARBPROC	glClientActiveTextureARB;

extern bool								found_GL_EXT_draw_range_elements;
extern PFNGLDRAWRANGEELEMENTSPROC		glDrawRangeElements;

extern bool								found_GL_EXT_compiled_vertex_array;
extern PFNGLLOCKARRAYSEXTPROC			glLockArraysEXT;
extern PFNGLUNLOCKARRAYSEXTPROC			glUnlockArraysEXT;

extern bool								found_GL_EXT_point_parameters;
extern PFNGLPOINTPARAMETERFEXTPROC		glPointParameterfEXT;
extern PFNGLPOINTPARAMETERFVEXTPROC		glPointParameterfvEXT;

extern bool								found_GL_EXT_separate_specular_color;

extern bool								found_GL_EXT_fog_coord;
extern PFNGLFOGCOORDFEXTPROC			glFogCoordfEXT;
extern PFNGLFOGCOORDFVEXTPROC			glFogCoordfvEXT;
extern PFNGLFOGCOORDDEXTPROC			glFogCoorddEXT;
extern PFNGLFOGCOORDDVEXTPROC			glFogCoorddvEXT;
extern PFNGLFOGCOORDPOINTEREXTPROC		glFogCoordPointerEXT;

extern bool								found_GL_NV_texgen_reflection;
extern bool								found_GL_NV_light_max_exponent;
extern bool								found_GL_NV_texgen_emboss;

extern bool								found_GL_NV_vertex_array_range;
extern PFNGLFLUSHVERTEXARRAYRANGENVPROC	glFlushVertexArrayRangeNV;
extern PFNGLVERTEXARRAYRANGENVPROC		glVertexArrayRangeNV;
extern PFNWGLALLOCATEMEMORYNV			wglAllocateMemoryNV;
extern PFNWGLFREEMEMORYNV				wglFreeMemoryNV;


void Init_OpenGL(void);

bool OpenGL_LoadExtension(
	const char *ext_name,
	const char **func_name,
	int func_count,
	void **func_ptr);

#endif