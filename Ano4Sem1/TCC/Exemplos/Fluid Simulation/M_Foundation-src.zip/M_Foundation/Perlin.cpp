/*

    File: Perlin.cpp

    Copyright (C) 2000-2007 Christopher Moore (christopher.e.moore@gmail.com)
	  
    This software is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
  
    You should have received a copy of the GNU General Public License along
    with this program; if not, write the Free Software Foundation, Inc., 51
    Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

*/
//NOTICE - unify this with fractal.cpp & make an array manipulation module

#include <math.h>
#include "perlin.h"
#include "random.h"
#include "const.h"

static int perlin_detail = 1;
static int perlin_seed = 0;

static float Noise1(int x, int y)
{
    int n = x + y * 57 + perlin_seed;
    n = (n<<13) ^ n;
    return ( (float)( (n * (n * n * 15731 + 789221) + 1376312589) & 0x7FFFFFFF) / (float)0x7FFFFFFF);
}

static int Perlin_DefaultSeedFunc(int x, int y)
{
	return (x + y * 57);
}

static float Interpolate(float v1, float v2, float frac)
{
//	return v1 * (1 - frac) + v2 * frac;

	float f = (1.f - (float)cos(frac * M_PI)) * 0.5f;
	return v1 * (1.f - f) + v2 * f;
}

static float Noise(int x, int y)
{
	return Noise1(x,y);
}

static float SmoothedNoise(int x, int y)
{
	int xn = (x + 1) % perlin_detail;
	int yn = (y + 1) % perlin_detail;
	int xm = (x + perlin_detail - 1) % perlin_detail;
	int ym = (y + perlin_detail - 1) % perlin_detail;

	float corners = ( Noise(xm,ym)+Noise(xn,ym)+Noise(xm,yn)+Noise(xn,yn) ) * 0.0625f; //1/16
    float sides   = ( Noise(xm, y)+Noise(xn, y)+Noise(x, ym)+Noise(x, yn) ) * 0.125f;  //1/8
    float center  =  Noise(x, y) * 0.25f;	//1/4
    return corners + sides + center;
}

static float InterpolatedNoise(float x, float y)
{
	int xi = (int)x;
	int xn = (xi + 1) % perlin_detail;
	float xf = x - (float)xi;

	int yi = (int)y;
	int yn = (yi + 1) % perlin_detail;
	float yf = y - (float)yi;

	float v0 = SmoothedNoise(xi,yi);
	float v1 = SmoothedNoise(xn,yi);
	float v2 = SmoothedNoise(xi,yn);
	float v3 = SmoothedNoise(xn,yn);

	float i1 = Interpolate(v0, v1, xf);
	float i2 = Interpolate(v2, v3, xf);

	return Interpolate(i1, i2, yf);
}

bool PerlinNoise(const perlin_noise_t *p)
{
	int l,i,j;
	float u,v;
	char *ptr;
	float *f;

	perlin_seed = p->seed;

	ptr = (char *)p->ptr;
	for (j = 0; j < p->height; j++)
	{
		v = (float)j / (float)p->height;
		for (i = 0; i < p->width; i++)
		{
			u = (float)i / (float)p->width;

			f = (float *)ptr;
			(*f) = 0;
			for (l = 0; l <= p->level_end; l++)
			{
				perlin_detail = 1 << (l + p->level_start);

				float frequency = (float)perlin_detail;//(float)pow(2.0, (double)l);
				float amplitude = (float)pow(p->persistance, -(double)l);
				(*f) += InterpolatedNoise(u * frequency, v * frequency) * amplitude;
			}

			ptr += p->inc;
		}
	}

	return true;
}
